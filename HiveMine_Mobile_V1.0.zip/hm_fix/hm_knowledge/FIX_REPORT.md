# HiveMine AI Fix Report

Date: 2026-11-07 (follow-up hardening pass)

## Fixed in the earlier pass

1. **Emergency STOP dispatch**: status-read failure no longer prevents a STOP attempt.
2. **Authorization boundary**: START/RECOVER pass through `AutomationController`; STOP remains the emergency path.
3. **Recovery verification**: RECOVER completion requires a newer recovery generation, running state, and recovery no longer in progress.
4. **Natural-language negation**: common negations are recognized and explicit STOP has precedence.
5. **Live AI command center**: overlay Plan/Apply path uses the live `AiManagerService` and authorized controller.
6. **Configuration adapter**: supported AI settings map to HiveMine Mobile's real `Config`/SharedPreferences.

## Additional fixes in this pass

7. **Continuous runtime feedback**
   - `MacroAccessibilityService` now runs a dedicated one-second AI runtime ticker.
   - The ticker is independent of the macro gesture handler, so `stopMacro()` cannot accidentally cancel monitoring.
   - `AiControlHub.refreshRuntime()` feeds authoritative `MacroStatus` into the bridge, `ScreenState`, command transition log, and persistent event history.
   - AI chat START/STOP and dashboard START/RECOVER/STOP now use the same request bridge.

8. **Live screen telemetry**
   - The existing Android screenshot polling loop publishes the latest screenshot-derived bag percentage and scene classification through `AiMacroPort`/`MacroStatus`.
   - `ScreenState` receives current bag/scene telemetry and reports whether screen telemetry is being observed.
   - The existing macro stuck/self-correction routines remain in place. A one-second watchdog detects both a screenshot pipeline that never returns its first usable frame and one that stops returning frames for more than 15 seconds.
   - On Android 11+, scene monitoring continues even without a configured bag coordinate, so the screenshot pipeline can still be validated.

9. **STOP/recovery reporting accuracy**
   - A STOP dispatch exception now returns `STOP_DISPATCH_FAILED`, rather than falsely reporting that STOP was sent.
   - Recover is refused when the macro is connected but idle, matching `MacroAccessibilityService.rejoinNow()` behavior.
   - The bridge keeps bounded request history and does not evict active requests.

10. **Settings safety**
    - AI configuration proposals are validated before writing.
    - `Config.save()` now commits the full configuration in one SharedPreferences transaction and returns its success result.
    - AI settings are read back and verified before the Manager reports success.
    - Unsupported keys are rejected before writing; failed commits or failed read-back trigger an attempt to restore the previous complete configuration.
    - A combined STOP still proceeds even if a settings write fails, while START is blocked.
    - The AI-control toggle is only reflected in controller state after its preference write succeeds and reads back correctly; a failed write attempts to restore the previous preference/controller value.

11. **Persistent Android operational history**
    - Added `HiveMineAiMemoryDb`, a SQLite-backed event history for command lifecycle, connection changes, plans, and settings outcomes.
    - Recent events are restored when the AI Manager state is recreated.
    - Raw prompts and screenshots are not stored in this event table; retention is capped at 2,000 rows.

12. **Phase status honesty**
    - Phase ledgers now distinguish `SOURCE_PRESENT`, `JVM_VERIFIED`, `ANDROID_INTEGRATED`, `DEVICE_VERIFIED`, and `RELEASE_VERIFIED`.
    - Broad phase ranges are no longer labelled as fully implemented based only on source presence.

## Verification completed

- `bash tests/run.sh`: **897 passed, 0 failed**.
- `bash tests/run-ai.sh`: **40 passed, 0 failed; 19 passed, 0 failed; 23 passed, 0 failed**.
- Tests include runtime state reconciliation, bridge START/STOP confirmation, screenshot watchdog timing (including no first frame), config read-back, SQLite event round-trip, manager history restore, disabled-control refusal, and STOP dispatch failure reporting.

## Remaining limitations — not falsely marked fixed

- **Android APK/lint/device validation remains blocked**: Gradle 8.9 is not cached, outbound access to `services.gradle.org` failed with `UnknownHostException`, and no Android SDK/device was available in this environment. No APK is claimed as built.
- **Full specialist orchestration is not complete**: the live AI Manager still centers on `BssIntentParser` + `BssPlanBuilder` and the authorized macro bridge. The `ManagerCoordinator`, task scheduler, and specialist catalog exist, but capability selection → task assignment → specialist analysis → execution result is not yet a complete Android runtime pipeline.
- **VisionAI specialist is not directly fed full pixel frames**: the Android path now exposes real `AutoSense`/`BagReader` screenshot-derived telemetry. That is not equivalent to connecting every `VisionAI` signature analyzer to full frame data.
- **Learning persistence is partial**: SQLite persists operational events and command outcomes, not the complete `ManagerMemory` decision model, specialist performance history, or learned policy updates. Database read errors are surfaced to the manager's memory-health status rather than treated as an empty successful history.
- **Release security/device acceptance remains open**: physical-device checks, lint, APK builds, permission/privacy/license review, and signing still need completion.

The current result is a better-wired and more testable source package, not a verified production APK.
