# HiveMine Mobile — Macro Bug Fixes V8

## Fixed
- Bag-full conversion now requires two consecutive qualifying telemetry readings, preventing one-frame OCR/vision spikes from sending the player to the hive.
- Bag threshold hysteresis resets immediately when the reading drops below the configured threshold.
- Conversion completion now requires two consecutive empty-bag readings plus a minimum conversion dwell, preventing premature departure while Roblox is still finishing conversion.
- Camera swipe cancellation is no longer treated as a successful turn. The macro retries once and then stops safely if the gesture is cancelled twice, avoiding continued walking with an unknown camera heading.
- Gesture completion clears the cancellation streak so normal successful movement is unaffected.
- New run state explicitly resets the macro gesture cancellation state and bag-threshold state.

## Validation
- Pure Java route/pattern sources compile successfully with `javac`.
- Full Android build remains blocked by the environment's inability to download Gradle 8.9 from services.gradle.org.
