# Integration Guide — HiveMine AI in HiveMine Mobile 1.8.0

## Project layout

This archive is already the combined application: Android app module `:app` and Java library module `:ai-core`. HiveMine Mobile continues to execute gestures and farming actions; HiveMine AI submits authorized requests and consumes status observations.

## Runtime boundary

The AI control path is:

```text
AiManagerService / overlay UI
    -> AndroidMacroCommunicationBridge
    -> AutomationController
    -> AiMacroPort
    -> MacroAccessibilityService
    -> periodic MacroStatus observation
    -> bridge completion + ScreenState refresh
```

The macro status is authoritative. AI state is a view of the latest observed status and must not be treated as authoritative when disconnected or stale.

## Authorization and emergency control

- START and RECOVER are accepted only when AI control is enabled by the user and the macro is connected; RECOVER also requires a running macro.
- STOP is the emergency path and is forwarded even when AI control is disabled.
- A STOP request is not the same as confirmed stopped state. The bridge marks it complete only after a later status observation reports the macro is no longer running.
- Do not call the underlying macro start/recover methods directly from AI features; use the controller/bridge authorization path.

## Settings and event history

Supported AI settings are validated, committed to Android preferences, and read back before the manager reports success. Operational summaries are stored in the bounded `hivemine_ai_memory.db` SQLite event table. This database is event history, not a learned policy model or full replacement for the core `ManagerMemory` abstractions.

## Verification

Run:

```bash
bash tests/run.sh
bash tests/run-ai.sh
./gradlew :app:lintDebug
./gradlew :app:assembleDebug
```

Then complete `DEVICE_TEST_MATRIX.md`, including AI control off/on, START confirmation, emergency STOP confirmation, RECOVER behavior, accessibility disconnection, screenshot loss, service teardown/reconnect, and persisted settings/events. A successful JVM harness does not establish Android build or device correctness.
