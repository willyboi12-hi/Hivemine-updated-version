# HiveMine AI — combined HiveMine Mobile project

HiveMine AI is the management and decision layer included in the HiveMine Mobile Android application. HiveMine Mobile remains the macro execution engine; HiveMine AI requests actions through the authorized app-side controller and observes macro status.

## Version and modules

- HiveMine Mobile Android app: **1.8.0** (`:app`)
- HiveMine AI core: **2.00** (`:ai-core`, Java library)
- Application id: `com.hiveminemobile`
- AI package: `com.hiveminemobile.ai`

## Test

```bash
bash tests/run.sh
bash tests/run-ai.sh
```

The suites run JVM logic and app-wiring checks with test doubles. They do not replace Gradle Android compilation, APK installation, or physical-device validation.

## Runtime integration

The Android integration provides an authorized macro adapter, a periodic status poll for command completion, telemetry synchronization, configuration commit/read-back, and bounded SQLite operational event history. AI control must be enabled by the user before the AI can start or recover the macro. Emergency STOP remains available regardless of that switch.

## Evidence and limitations

Read `PHASE_LEDGER.md` and `documentation/PHASE_LEDGER.md` for the evidence status of phase groups. Read the combined repository's `PRODUCTION_READINESS.md` for build and release gates.

The Android Gradle build, lint, APK generation, and physical-device tests have not been completed in the current environment. Generic VisionAI analysis, learned-policy persistence, and full specialist-fleet task orchestration remain incomplete; existing HiveMine screen recognition telemetry and operational event history should not be represented as those full capabilities.
