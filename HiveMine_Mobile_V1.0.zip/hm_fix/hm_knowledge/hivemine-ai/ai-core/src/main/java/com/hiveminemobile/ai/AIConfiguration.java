package com.hiveminemobile.ai;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Immutable, Android-independent configuration for the HiveMine AI foundation.
 * Values are intentionally stored as strings so the core can be tested on a plain JVM.
 */
public final class AIConfiguration {
    private final Map<String, String> values;

    private AIConfiguration(Map<String, String> values) {
        this.values = Collections.unmodifiableMap(new LinkedHashMap<>(values));
    }

    public static AIConfiguration empty() {
        return new AIConfiguration(Collections.<String, String>emptyMap());
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getString(String key, String fallback) {
        String value = values.get(key);
        return value == null ? fallback : value;
    }

    public boolean getBoolean(String key, boolean fallback) {
        String value = values.get(key);
        if (value == null) return fallback;
        if ("true".equalsIgnoreCase(value.trim())) return true;
        if ("false".equalsIgnoreCase(value.trim())) return false;
        return fallback;
    }

    public int getInt(String key, int fallback) {
        String value = values.get(key);
        if (value == null) return fallback;
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    public boolean contains(String key) {
        return values.containsKey(key);
    }

    public Map<String, String> asMap() {
        return values;
    }

    public static final class Builder {
        private final Map<String, String> values = new LinkedHashMap<>();

        public Builder put(String key, String value) {
            if (key == null || key.trim().isEmpty()) {
                throw new IllegalArgumentException("Configuration key must not be blank");
            }
            if (value == null) {
                throw new IllegalArgumentException("Configuration value must not be null");
            }
            values.put(key.trim(), value);
            return this;
        }

        public Builder putBoolean(String key, boolean value) {
            return put(key, Boolean.toString(value));
        }

        public Builder putInt(String key, int value) {
            return put(key, Integer.toString(value));
        }

        public AIConfiguration build() {
            return new AIConfiguration(values);
        }
    }
}
