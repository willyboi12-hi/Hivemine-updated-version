package com.hiveminemobile.ai;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Lifecycle owner for the independent AI foundation.
 * It deliberately has no Android UI, AccessibilityService, or Roblox dependency.
 */
public final class AIEngine {
    public enum State {
        NEW, INITIALIZING, INITIALIZED, RUNNING, SHUTTING_DOWN, STOPPED, FAILED
    }

    private final AIConfiguration configuration;
    private final AIRegistry registry;
    private final AIErrorHandler errorHandler;
    private final List<AIInterface> initializedModules = new ArrayList<>();
    private State state = State.NEW;

    public AIEngine(AIConfiguration configuration, AIRegistry registry, AIErrorHandler errorHandler) {
        if (configuration == null) throw new IllegalArgumentException("configuration must not be null");
        if (registry == null) throw new IllegalArgumentException("registry must not be null");
        if (errorHandler == null) throw new IllegalArgumentException("errorHandler must not be null");
        this.configuration = configuration;
        this.registry = registry;
        this.errorHandler = errorHandler;
    }

    /** Register modules before initialization so startup order is deterministic. */
    public synchronized void register(AIInterface module) {
        requireState(State.NEW, "Modules can only be registered before initialization");
        registry.register(module);
    }

    /** Initializes all registered modules; startup is rolled back if any module fails. */
    public synchronized void initialize() throws AIException {
        requireState(State.NEW, "Engine can only be initialized once");
        state = State.INITIALIZING;
        List<AIInterface> attempted = new ArrayList<>();
        for (AIInterface module : registry.getAll()) {
            attempted.add(module);
            try {
                module.onInitialize(configuration);
                initializedModules.add(module);
            } catch (Exception failure) {
                errorHandler.report(module.getId(), "initialize", AIErrorHandler.Severity.CRITICAL, failure);
                rollback(attempted);
                state = State.FAILED;
                throw new AIException("AI module initialization failed: " + module.getId(),
                    module.getId(), "initialize", failure);
            }
        }
        state = State.INITIALIZED;
    }

    /** Marks the initialized foundation available to its host application. */
    public synchronized void start() {
        requireState(State.INITIALIZED, "Engine must be initialized before start");
        state = State.RUNNING;
    }

    /** Stops all initialized modules in reverse startup order. */
    public synchronized void shutdown() {
        if (state == State.STOPPED || state == State.SHUTTING_DOWN) return;
        state = State.SHUTTING_DOWN;
        for (int i = initializedModules.size() - 1; i >= 0; i--) {
            AIInterface module = initializedModules.get(i);
            try {
                module.onShutdown();
            } catch (Exception failure) {
                errorHandler.report(module.getId(), "shutdown", AIErrorHandler.Severity.ERROR, failure);
            }
        }
        initializedModules.clear();
        state = State.STOPPED;
    }

    public synchronized State getState() {
        return state;
    }

    public synchronized boolean isRunning() {
        return state == State.RUNNING;
    }

    public AIErrorHandler getErrorHandler() {
        return errorHandler;
    }

    public synchronized List<String> getInitializedModuleIds() {
        List<String> ids = new ArrayList<>();
        for (AIInterface module : initializedModules) ids.add(module.getId());
        return Collections.unmodifiableList(ids);
    }

    private void rollback(List<AIInterface> attempted) {
        for (int i = attempted.size() - 1; i >= 0; i--) {
            AIInterface module = attempted.get(i);
            try {
                // Also call shutdown on the module whose initialization failed;
                // it may have allocated a resource before reporting the failure.
                module.onShutdown();
            } catch (Exception cleanupFailure) {
                errorHandler.report(module.getId(), "rollback-shutdown",
                    AIErrorHandler.Severity.ERROR, cleanupFailure);
            }
        }
        initializedModules.clear();
    }

    private void requireState(State expected, String message) {
        if (state != expected) throw new IllegalStateException(message + " (state=" + state + ")");
    }
}
