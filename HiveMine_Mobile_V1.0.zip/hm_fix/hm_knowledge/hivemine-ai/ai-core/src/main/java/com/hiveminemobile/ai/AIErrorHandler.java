package com.hiveminemobile.ai;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Small bounded error journal that does not depend on Android logging APIs. */
public final class AIErrorHandler {
    public enum Severity { WARNING, ERROR, CRITICAL }

    public interface Listener {
        void onError(AIError error);
    }

    public static final class AIError {
        private final String componentId;
        private final String operation;
        private final Severity severity;
        private final String message;
        private final long timestampMillis;

        private AIError(String componentId, String operation, Severity severity,
                        String message, long timestampMillis) {
            this.componentId = componentId;
            this.operation = operation;
            this.severity = severity;
            this.message = message;
            this.timestampMillis = timestampMillis;
        }

        public String getComponentId() { return componentId; }
        public String getOperation() { return operation; }
        public Severity getSeverity() { return severity; }
        public String getMessage() { return message; }
        public long getTimestampMillis() { return timestampMillis; }
    }

    private final int maxHistory;
    private final ArrayDeque<AIError> history = new ArrayDeque<>();
    private final Listener listener;

    public AIErrorHandler() {
        this(100, null);
    }

    public AIErrorHandler(int maxHistory, Listener listener) {
        if (maxHistory < 1) throw new IllegalArgumentException("maxHistory must be at least 1");
        this.maxHistory = maxHistory;
        this.listener = listener;
    }

    public AIError report(String componentId, String operation, Severity severity, Throwable cause) {
        String message = cause == null ? "Unknown error" : cause.getMessage();
        if (message == null || message.trim().isEmpty()) {
            message = cause == null ? "Unknown error" : cause.getClass().getSimpleName();
        }
        AIError error = new AIError(
            clean(componentId, "hivemine-ai"),
            clean(operation, "unknown"),
            severity == null ? Severity.ERROR : severity,
            message,
            System.currentTimeMillis()
        );
        synchronized (history) {
            while (history.size() >= maxHistory) history.removeFirst();
            history.addLast(error);
        }
        if (listener != null) {
            try {
                listener.onError(error);
            } catch (RuntimeException ignored) {
                // A reporting callback must never crash the AI lifecycle.
            }
        }
        return error;
    }

    public List<AIError> getHistory() {
        synchronized (history) {
            return Collections.unmodifiableList(new ArrayList<>(history));
        }
    }

    public void clearHistory() {
        synchronized (history) {
            history.clear();
        }
    }

    private static String clean(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }
}
