package com.hiveminemobile.ai;

/** Checked failure raised by the AI foundation lifecycle. */
public final class AIException extends Exception {
    private final String componentId;
    private final String operation;

    public AIException(String message, String componentId, String operation, Throwable cause) {
        super(message, cause);
        this.componentId = componentId == null ? "hivemine-ai" : componentId;
        this.operation = operation == null ? "unknown" : operation;
    }

    public String getComponentId() {
        return componentId;
    }

    public String getOperation() {
        return operation;
    }
}
