package com.hiveminemobile.ai;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/** Thread-safe registry for independent AI modules. */
public final class AIRegistry {
    private static final Pattern VALID_ID = Pattern.compile("[a-z][a-z0-9._-]{0,63}");
    private final Map<String, AIInterface> modules = new LinkedHashMap<>();

    public synchronized void register(AIInterface module) {
        validate(module);
        String id = module.getId().trim();
        if (modules.containsKey(id)) {
            throw new IllegalArgumentException("An AI module with id '" + id + "' is already registered");
        }
        modules.put(id, module);
    }

    public synchronized AIInterface get(String id) {
        return id == null ? null : modules.get(id.trim());
    }

    public synchronized boolean unregister(String id) {
        return id != null && modules.remove(id.trim()) != null;
    }

    public synchronized int size() {
        return modules.size();
    }

    public synchronized List<AIInterface> getAll() {
        return Collections.unmodifiableList(new ArrayList<>(modules.values()));
    }

    private static void validate(AIInterface module) {
        if (module == null) throw new IllegalArgumentException("AI module must not be null");
        String id = module.getId();
        if (id == null || !id.equals(id.trim()) || !VALID_ID.matcher(id).matches()) {
            throw new IllegalArgumentException("AI module id is invalid");
        }
        String version = module.getVersion();
        if (version == null || version.trim().isEmpty()) {
            throw new IllegalArgumentException("AI module version must not be blank");
        }
        Set<String> capabilities = module.getCapabilities();
        if (capabilities == null) {
            throw new IllegalArgumentException("AI module capabilities must not be null");
        }
        for (String capability : capabilities) {
            if (capability == null || capability.trim().isEmpty()) {
                throw new IllegalArgumentException("AI module capabilities must not contain blank values");
            }
        }
    }
}
