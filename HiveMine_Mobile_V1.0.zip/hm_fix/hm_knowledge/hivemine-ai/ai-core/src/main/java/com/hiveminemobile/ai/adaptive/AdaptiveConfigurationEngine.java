package com.hiveminemobile.ai.adaptive;

import java.util.*;

/**
 * Phase 082: proposes configuration changes. Nothing changes until the user approves a proposal.
 * Every applied change is stored, so it can be rolled back. User preferences always win.
 */
public final class AdaptiveConfigurationEngine {

    public static final class Proposal {
        public final String id, key, value;
        Proposal(String id, String key, String value) { this.id = id; this.key = key; this.value = value; }
    }

    private final Map<String, String> active;
    private final Deque<Map<String, String>> history = new ArrayDeque<>();
    private final Map<String, Proposal> pending = new LinkedHashMap<>();
    private final Set<String> adjustable;
    private final Set<String> userLocked;
    private int nextId = 1;

    public AdaptiveConfigurationEngine(Map<String, String> initial, Set<String> adjustable, Set<String> userLocked) {
        this.active = new TreeMap<>(initial);
        this.adjustable = new HashSet<>(adjustable);
        this.userLocked = new HashSet<>(userLocked);
    }

    /** Suggestions are {key, value} pairs. Conflicting suggestions for one key are all refused. */
    public List<Proposal> propose(List<String[]> suggestions) {
        Map<String, Integer> count = new HashMap<>();
        for (String[] s : suggestions) if (s != null && s.length == 2) count.merge(s[0], 1, Integer::sum);
        List<Proposal> out = new ArrayList<>();
        for (String[] s : suggestions) {
            if (s == null || s.length != 2 || blank(s[0]) || s[1] == null) continue;
            if (!adjustable.contains(s[0]) || userLocked.contains(s[0])) continue;
            if (s[1].equals(active.get(s[0]))) continue;
            if (count.get(s[0]) > 1) continue;
            Proposal p = new Proposal("P" + nextId++, s[0], s[1]);
            pending.put(p.id, p);
            out.add(p);
        }
        return out;
    }

    public boolean approve(String id) {
        Proposal p = pending.remove(id);
        if (p == null) return false;
        history.push(new TreeMap<>(active));
        active.put(p.key, p.value);
        return true;
    }

    public boolean rollback() {
        if (history.isEmpty()) return false;
        active.clear();
        active.putAll(history.pop());
        return true;
    }

    /** Keys whose value differs between the active configuration and the other one. */
    public Map<String, String[]> diff(Map<String, String> other) {
        Map<String, String[]> out = new TreeMap<>();
        Set<String> keys = new TreeSet<>(active.keySet());
        keys.addAll(other.keySet());
        for (String k : keys) {
            String a = active.get(k), b = other.get(k);
            if (a == null ? b != null : !a.equals(b)) out.put(k, new String[]{a, b});
        }
        return out;
    }

    public Map<String, String> active() { return Collections.unmodifiableMap(active); }
    public int historyDepth() { return history.size(); }
    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
