package com.hiveminemobile.ai.android;

import java.util.*;

/**
 * Phase 090: keeps the AI's saved profile in step with the macro's configuration store.
 * Before writing, it backs up the current macro settings. If the macro settings changed outside the AI since
 * the last sync, it reports a conflict and writes nothing.
 */
public final class AndroidConfigurationSyncManager {
    /** Implemented by the Android app. */
    public interface Store { Map<String, String> read(); void write(Map<String, String> settings); }

    public enum Result { SYNCED, CONFLICT, NO_CHANGE, FAILED }

    private final Store store;
    private final List<Map<String, String>> backups = new ArrayList<>();
    private Map<String, String> lastSynced = new TreeMap<>();

    public AndroidConfigurationSyncManager(Store store) { this.store = store; }

    public synchronized Result sync(Map<String, String> aiProfile) {
        Map<String, String> current;
        try { current = new TreeMap<>(store.read()); } catch (RuntimeException e) { return Result.FAILED; }
        if (!current.equals(lastSynced) && !lastSynced.isEmpty()) return Result.CONFLICT;
        Map<String, String> target = new TreeMap<>(aiProfile);
        if (target.equals(current)) { lastSynced = target; return Result.NO_CHANGE; }
        backups.add(current);
        try { store.write(target); } catch (RuntimeException e) { backups.remove(backups.size() - 1); return Result.FAILED; }
        lastSynced = target;
        return Result.SYNCED;
    }

    public synchronized boolean restorePrevious() {
        if (backups.isEmpty()) return false;
        Map<String, String> prev = backups.remove(backups.size() - 1);
        try { store.write(prev); } catch (RuntimeException e) { return false; }
        lastSynced = new TreeMap<>(prev);
        return true;
    }

    public synchronized Map<String, String[]> differences(Map<String, String> aiProfile) {
        Map<String, String> current = new TreeMap<>(store.read());
        Map<String, String[]> out = new TreeMap<>();
        Set<String> keys = new TreeSet<>(current.keySet()); keys.addAll(aiProfile.keySet());
        for (String k : keys) {
            String a = aiProfile.get(k), b = current.get(k);
            if (a == null ? b != null : !a.equals(b)) out.put(k, new String[]{a, b});
        }
        return out;
    }

    public synchronized int backupCount() { return backups.size(); }
}
