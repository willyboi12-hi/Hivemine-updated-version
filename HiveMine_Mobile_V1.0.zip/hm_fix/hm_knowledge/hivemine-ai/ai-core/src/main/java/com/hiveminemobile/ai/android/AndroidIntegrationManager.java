package com.hiveminemobile.ai.android;

import java.util.*;

/**
 * Phase 085: records the status of each Android-side component the AI depends on. A component that has
 * not reported is UNKNOWN, and UNKNOWN is never treated as available.
 */
public final class AndroidIntegrationManager {
    public enum Status { AVAILABLE, UNAVAILABLE, UNKNOWN }

    public static final List<String> REQUIRED = Collections.unmodifiableList(
        Arrays.asList("macro-port", "accessibility-service", "configuration-storage"));

    private final Map<String, Status> components = new TreeMap<>();

    public synchronized boolean register(String name, Status status) {
        if (blank(name) || status == null || components.containsKey(name)) return false;
        components.put(name, status);
        return true;
    }

    public synchronized void update(String name, Status status) {
        if (components.containsKey(name) && status != null) components.put(name, status);
    }

    public synchronized Status statusOf(String name) {
        Status s = components.get(name);
        return s == null ? Status.UNKNOWN : s;
    }

    public synchronized List<String> missing() {
        List<String> out = new ArrayList<>();
        for (String r : REQUIRED) if (statusOf(r) != Status.AVAILABLE) out.add(r);
        return out;
    }

    public synchronized boolean canInitialize() { return missing().isEmpty(); }

    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
