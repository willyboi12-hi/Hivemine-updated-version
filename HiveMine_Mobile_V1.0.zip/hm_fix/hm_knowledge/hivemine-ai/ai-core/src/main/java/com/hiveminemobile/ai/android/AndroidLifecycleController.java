package com.hiveminemobile.ai.android;

import java.util.*;

/** Phase 086: starts and stops the AI with the app. Duplicate starts are refused, and state can be restored. */
public final class AndroidLifecycleController {
    public enum State { STOPPED, RUNNING }

    private final AndroidIntegrationManager integration;
    private State state = State.STOPPED;
    private boolean interrupted;
    private Map<String, String> saved = new TreeMap<>();

    public AndroidLifecycleController(AndroidIntegrationManager integration) {
        if (integration == null) throw new IllegalArgumentException("integration must not be null");
        this.integration = integration;
    }

    public synchronized boolean start() {
        if (state == State.RUNNING) return false;
        if (!integration.canInitialize()) return false;
        state = State.RUNNING;
        interrupted = false;
        return true;
    }

    public synchronized boolean stop() {
        if (state == State.STOPPED) return false;
        state = State.STOPPED;
        return true;
    }

    /** The app was interrupted (for example, a call came in). The AI stops and remembers it was interrupted. */
    public synchronized void interrupt() {
        if (state == State.RUNNING) { stop(); interrupted = true; }
    }

    public synchronized void persist(Map<String, String> state) { saved = new TreeMap<>(state); }

    /** Returns the saved state only if the AI can start again. Otherwise returns an empty map. */
    public synchronized Map<String, String> restoreAfterRestart() {
        return integration.canInitialize() ? Collections.unmodifiableMap(new TreeMap<>(saved)) : Collections.<String, String>emptyMap();
    }

    public synchronized State state() { return state; }
    public synchronized boolean wasInterrupted() { return interrupted; }
}
