package com.hiveminemobile.ai.android;

import java.util.*;

/**
 * Phase 088: passes screenshots to Vision AI only when screen observation is allowed and the image is valid.
 * Images come from an adapter, so this code does not touch Android.
 */
public final class ScreenObservationManager {
    /** Implemented by the Android app. Returns PNG bytes, or null when no screen is available. */
    public interface CaptureAdapter { byte[] capture(); }

    public enum Result { OBSERVED, NOT_PERMITTED, NO_IMAGE, INVALID_IMAGE, FAILED }

    public static final class Observation {
        public final long atMillis; public final int bytes;
        Observation(long at, int n) { atMillis = at; bytes = n; }
    }

    private static final byte[] PNG_SIGNATURE = {(byte) 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A};

    private final AndroidPermissionManager permissions;
    private final CaptureAdapter adapter;
    private final int maxBytes, capacity;
    private final Deque<Observation> buffer = new ArrayDeque<>();

    public ScreenObservationManager(AndroidPermissionManager permissions, CaptureAdapter adapter, int maxBytes, int capacity) {
        if (maxBytes < PNG_SIGNATURE.length || capacity < 1) throw new IllegalArgumentException("bad limits");
        this.permissions = permissions;
        this.adapter = adapter;
        this.maxBytes = maxBytes;
        this.capacity = capacity;
    }

    public synchronized Result observe(long nowMillis) {
        if (!permissions.featureEnabled("screen-observation")) return Result.NOT_PERMITTED;
        byte[] img;
        try { img = adapter.capture(); } catch (RuntimeException e) { return Result.FAILED; }
        if (img == null) return Result.NO_IMAGE;
        if (!isValidPng(img)) return Result.INVALID_IMAGE;
        while (buffer.size() >= capacity) buffer.removeFirst();
        buffer.addLast(new Observation(nowMillis, img.length));
        return Result.OBSERVED;
    }

    public synchronized List<Observation> observations() { return Collections.unmodifiableList(new ArrayList<>(buffer)); }

    static boolean isValidPng(byte[] img) {
        if (img.length < PNG_SIGNATURE.length) return false;
        for (int i = 0; i < PNG_SIGNATURE.length; i++) if (img[i] != PNG_SIGNATURE[i]) return false;
        return true;
    }
}
