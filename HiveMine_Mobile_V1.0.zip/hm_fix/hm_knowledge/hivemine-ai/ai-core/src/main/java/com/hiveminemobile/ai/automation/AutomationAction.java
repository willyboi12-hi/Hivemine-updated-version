package com.hiveminemobile.ai.automation;

/** Phase 063 — Atomic automation action requested of MacroPort via the controller. */
public enum AutomationAction {
    NONE,
    START,
    STOP,
    RECOVER,
    CONVERT
}
