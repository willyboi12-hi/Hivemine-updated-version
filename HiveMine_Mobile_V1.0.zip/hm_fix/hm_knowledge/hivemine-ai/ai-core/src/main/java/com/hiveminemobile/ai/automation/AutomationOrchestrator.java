package com.hiveminemobile.ai.automation;

import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;

/**
 * Phase 069 — Wires session, scheduler, planner, queue, recovery, safety, and MacroPort control.
 * Tick-driven: callers invoke {@link #tick(long)} with a clock. Never touches Android.
 *
 * Safety: stop is always available. Start/recover require user-enabled AI control on the controller.
 */
public final class AutomationOrchestrator {
    private final AutomationController controller;
    private final MacroPort port;
    private final AutomationScheduler scheduler;
    private final ActionPlanner planner = new ActionPlanner();
    private final CommandQueue queue = new CommandQueue(8);
    private final RecoveryPolicy recoveryPolicy;
    private final SafetyInterlock safety;
    private final AutomationStateMachine fsm = new AutomationStateMachine();
    private final AutomationMetrics metrics = new AutomationMetrics();

    private AutomationSession session;
    private ActionPlanner.Goal goal = ActionPlanner.Goal.IDLE;
    private boolean disconnectedHint;

    public AutomationOrchestrator(AutomationController controller, MacroPort port,
                                  long tickIntervalMs, long maxSessionMs,
                                  int maxRecoveries, int maxConsecutiveFailures) {
        if (controller == null || port == null) throw new IllegalArgumentException("null deps");
        this.controller = controller;
        this.port = port;
        this.scheduler = new AutomationScheduler(tickIntervalMs);
        this.recoveryPolicy = new RecoveryPolicy(maxRecoveries);
        this.safety = new SafetyInterlock(maxSessionMs, maxConsecutiveFailures);
    }

    public AutomationState state() { return fsm.state(); }
    public AutomationMetrics metrics() { return metrics; }
    public AutomationSession session() { return session; }
    public SafetyInterlock safety() { return safety; }
    public ActionPlanner.Goal goal() { return goal; }

    /** User/AI sets the desired goal. Does not immediately call the macro. */
    public synchronized void setGoal(ActionPlanner.Goal goal) {
        this.goal = goal == null ? ActionPlanner.Goal.IDLE : goal;
    }

    public synchronized void setDisconnectedHint(boolean disconnected) {
        this.disconnectedHint = disconnected;
    }

    /** Arm a new session. Requires AI control enabled for non-IDLE goals later. */
    public synchronized boolean arm(String sessionId, long nowMs) {
        if (fsm.state() != AutomationState.IDLE && fsm.state() != AutomationState.FAULT) return false;
        safety.reset();
        recoveryPolicy.resetSession();
        metrics.reset();
        scheduler.reset();
        queue.clear();
        session = new AutomationSession(sessionId, nowMs);
        fsm.arm();
        return true;
    }

    /** Emergency stop path — always attempts macro stop. */
    public synchronized void emergencyStop(long nowMs, String reason) {
        queue.clear();
        queue.enqueue(AutomationAction.STOP);
        drainQueue();
        fsm.beginStop();
        if (session != null) session.markEnded(nowMs, reason == null ? "emergency-stop" : reason);
        fsm.toIdle();
    }

    /**
     * Advances automation by at most one scheduled tick.
     * @return true if a tick ran
     */
    public synchronized boolean tick(long nowMs) {
        if (!scheduler.due(nowMs)) return false;
        scheduler.markTick(nowMs);
        metrics.tick();

        if (safety.isTripped()) {
            metrics.fault();
            fsm.fault();
            queue.clear();
            queue.enqueue(AutomationAction.STOP);
            drainQueue();
            if (session != null) session.markEnded(nowMs, safety.tripReason());
            return true;
        }

        if (session != null && session.phase() == AutomationSession.Phase.ACTIVE) {
            safety.checkSessionDuration(session.activeDurationMs(nowMs));
            if (safety.isTripped()) {
                metrics.fault();
                fsm.fault();
                queue.enqueue(AutomationAction.STOP);
                drainQueue();
                session.markEnded(nowMs, safety.tripReason());
                return true;
            }
        }

        MacroStatus status = port.readStatus();

        // Recovery preference. A stopped macro cannot perform a rejoin: the Android
        // implementation intentionally rejects rejoin while not running. In that state
        // RECOVER_THEN_FARM falls through to FARM so the authorized START path can recover
        // the session instead of issuing a guaranteed REFUSED_NOT_RUNNING request.
        if (recoveryPolicy.shouldRecover(status, disconnectedHint)) {
            if (fsm.state() == AutomationState.ARMED || fsm.state() == AutomationState.RUNNING) {
                fsm.beginRecover();
            }
            queue.enqueue(AutomationAction.RECOVER);
            recoveryPolicy.recordRecoveryAttempt();
            if (goal == ActionPlanner.Goal.RECOVER_THEN_FARM) goal = ActionPlanner.Goal.FARM;
            disconnectedHint = false;
        } else if (goal == ActionPlanner.Goal.RECOVER_THEN_FARM
                && status != null && status.isConnected() && !status.isRunning()) {
            goal = ActionPlanner.Goal.FARM;
        }

        AutomationAction planned = planner.plan(goal, status, safety.isTripped());
        if (planned == AutomationAction.START && session != null
                && session.phase() == AutomationSession.Phase.CREATED) {
            session.markActive(nowMs);
            fsm.startRunning();
        }
        if (planned == AutomationAction.STOP) {
            fsm.beginStop();
        }
        queue.enqueue(planned);
        drainQueue();

        // If goal is idle and not running, settle
        status = port.readStatus();
        if (goal == ActionPlanner.Goal.IDLE && status != null && !status.isRunning()) {
            if (session != null && session.phase() == AutomationSession.Phase.ACTIVE) {
                session.markEnded(nowMs, "goal-idle");
            }
            if (fsm.state() == AutomationState.STOPPING || fsm.state() == AutomationState.RUNNING) {
                fsm.toIdle();
            }
        }
        return true;
    }

    private void drainQueue() {
        AutomationAction action;
        while ((action = queue.poll()) != AutomationAction.NONE) {
            AutomationController.Decision d;
            switch (action) {
                case START:
                    d = controller.requestStart();
                    if (d == AutomationController.Decision.START_REQUESTED) {
                        metrics.startRequested();
                        safety.recordSuccess();
                    } else {
                        metrics.refused();
                        safety.recordFailure(d.name());
                    }
                    break;
                case STOP:
                    d = controller.requestStop();
                    if (d == AutomationController.Decision.STOP_REQUESTED
                            || d == AutomationController.Decision.REFUSED_NOT_CONNECTED) {
                        metrics.stopRequested();
                        safety.recordSuccess();
                    } else {
                        metrics.refused();
                    }
                    break;
                case RECOVER:
                    d = controller.requestRecover();
                    if (d == AutomationController.Decision.RECOVER_REQUESTED) {
                        metrics.recoverRequested();
                        safety.recordSuccess();
                    } else {
                        metrics.refused();
                        safety.recordFailure(d.name());
                    }
                    break;
                case CONVERT:
                    d = controller.requestConvert();
                    if (d == AutomationController.Decision.CONVERT_REQUESTED) metrics.startRequested();
                    else metrics.refused();
                    break;
                default:
                    break;
            }
        }
    }
}
