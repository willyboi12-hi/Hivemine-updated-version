package com.hiveminemobile.ai.automation;

/**
 * Phase 062 — Deterministic tick scheduler for the automation loop.
 * Callers drive time; this class only decides when a tick is due.
 */
public final class AutomationScheduler {
    private final long intervalMs;
    private long lastTickMs = -1;
    private long tickCount;

    public AutomationScheduler(long intervalMs) {
        if (intervalMs < 50) throw new IllegalArgumentException("intervalMs must be >= 50");
        this.intervalMs = intervalMs;
    }

    public long intervalMs() { return intervalMs; }
    public long tickCount() { return tickCount; }
    public long lastTickMs() { return lastTickMs; }

    /** Returns true when enough time has passed for the next tick. */
    public boolean due(long nowMs) {
        if (lastTickMs < 0) return true;
        return nowMs - lastTickMs >= intervalMs;
    }

    /** Records a tick at nowMs. Returns the new tick index (1-based count). */
    public long markTick(long nowMs) {
        lastTickMs = nowMs;
        tickCount++;
        return tickCount;
    }

    public void reset() {
        lastTickMs = -1;
        tickCount = 0;
    }
}
