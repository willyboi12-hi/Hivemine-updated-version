package com.hiveminemobile.ai.automation;

/** Phase 067 — High-level automation lifecycle states. */
public enum AutomationState {
    IDLE,
    ARMED,
    RUNNING,
    RECOVERING,
    STOPPING,
    FAULT
}
