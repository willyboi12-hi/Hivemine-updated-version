package com.hiveminemobile.ai.automation;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Phase 064 — Serializes automation actions so start/stop/recover never overlap in logic.
 */
public final class CommandQueue {
    private final ArrayDeque<AutomationAction> queue = new ArrayDeque<AutomationAction>();
    private final int limit;

    public CommandQueue(int limit) {
        if (limit < 1) throw new IllegalArgumentException("limit >= 1");
        this.limit = limit;
    }

    public synchronized boolean enqueue(AutomationAction action) {
        if (action == null || action == AutomationAction.NONE) return false;
        // Collapse consecutive duplicates
        if (!queue.isEmpty() && queue.peekLast() == action) return false;
        // Stop preempts everything
        if (action == AutomationAction.STOP) {
            queue.clear();
            queue.addLast(action);
            return true;
        }
        if (queue.size() >= limit) return false;
        queue.addLast(action);
        return true;
    }

    public synchronized AutomationAction poll() {
        return queue.isEmpty() ? AutomationAction.NONE : queue.removeFirst();
    }

    public synchronized int size() { return queue.size(); }

    public synchronized void clear() { queue.clear(); }

    public synchronized List<AutomationAction> snapshot() {
        return Collections.unmodifiableList(new ArrayList<AutomationAction>(queue));
    }
}
