package com.hiveminemobile.ai.bss;

import java.util.Locale;

/** Bee Swarm Simulator field knowledge used by the planner.
 *  Field color is a property of the normal field, while flower counts can vary by server.
 */
public final class BssFields {
    public static final String[] NAMES = {
        "Bamboo", "Blue Flower", "Cactus", "Clover", "Coconut", "Dandelion",
        "Mountain Top", "Mushroom", "Pepper", "Pineapple", "Pine Tree", "Pumpkin",
        "Rose", "Spider", "Strawberry", "Stump", "Sunflower"
    };

    public enum Color { RED, BLUE, WHITE, MIXED }

    private BssFields() {}

    public static boolean isKnown(String name) { return canonical(name) != null; }

    public static String canonical(String name) {
        if (name == null) return null;
        String q = normalize(name);
        for (String n : NAMES) if (normalize(n).equals(q)) return n;
        // Natural-language aliases used by players.
        if (q.equals("pine tree forest")) return "Pine Tree";
        if (q.equals("pineapple patch")) return "Pineapple";
        if (q.equals("pumpkin patch")) return "Pumpkin";
        if (q.equals("pepper patch")) return "Pepper";
        if (q.equals("mountain top field")) return "Mountain Top";
        if (q.equals("coconut field")) return "Coconut";
        if (q.equals("strawberry field")) return "Strawberry";
        if (q.equals("spider field")) return "Spider";
        if (q.equals("stump field")) return "Stump";
        if (q.equals("blue flower field")) return "Blue Flower";
        if (q.equals("sunflower field")) return "Sunflower";
        if (q.equals("dandelion field")) return "Dandelion";
        if (q.equals("mushroom field")) return "Mushroom";
        if (q.equals("clover field")) return "Clover";
        if (q.equals("bamboo field")) return "Bamboo";
        if (q.equals("cactus field")) return "Cactus";
        if (q.equals("rose field")) return "Rose";
        for (String n : NAMES) {
            String nn = normalize(n);
            if (nn.contains(q) || q.contains(nn)) return n;
        }
        return null;
    }

    /** Natural field color classification. Mixed means the field contains multiple colors. */
    public static Color colorOf(String name) {
        String f = canonical(name);
        if (f == null) return null;
        if (f.equals("Spider") || f.equals("Dandelion") || f.equals("Sunflower") ||
            f.equals("Mushroom") || f.equals("Clover") || f.equals("Strawberry")) return Color.WHITE;
        if (f.equals("Blue Flower") || f.equals("Bamboo") || f.equals("Pine Tree") ||
            f.equals("Stump") || f.equals("Pineapple") || f.equals("Coconut")) return Color.BLUE;
        if (f.equals("Cactus") || f.equals("Rose") || f.equals("Pepper")) return Color.RED;
        if (f.equals("Mountain Top")) return Color.MIXED;
        return Color.MIXED;
    }

    public static boolean matchesColor(String field, String requestedColor) {
        if (requestedColor == null) return false;
        Color c = colorOf(field);
        if (c == null) return false;
        String q = requestedColor.toLowerCase(Locale.US);
        return (q.contains("white") && c == Color.WHITE) ||
               (q.contains("blue") && c == Color.BLUE) ||
               (q.contains("red") && c == Color.RED);
    }

    private static String normalize(String s) {
        return s.trim().toLowerCase(Locale.US).replaceAll("\\s+", " ");
    }
}
