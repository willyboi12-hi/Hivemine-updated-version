package com.hiveminemobile.ai.bss;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Rule-based NL understanding for BSS macro commands. No fake LLM. */
public final class BssIntentParser {
    public static final class Intent {
        public String field; // canonical or null
        public boolean startMacro;
        public boolean stopMacro;
        public boolean enableQuestSmart;
        public boolean convertWhenFull;
        public boolean wantFarmPreset;
        public boolean wantQuestPreset;
        public String materialGoal; // glue, gummies, tokens, etc
        public final List<String> notes = new ArrayList<String>();
        public final List<String> unsupported = new ArrayList<String>();
    }

    public Intent parse(String text) {
        Intent i = new Intent();
        if (text == null || text.trim().isEmpty()) {
            i.notes.add("empty request");
            return i;
        }
        String t = text.toLowerCase(Locale.US);

        // Prefer fields mentioned in an affirmative clause. This prevents requests such as
        // "don't farm Pine Tree, farm Sunflower" from selecting the negated field.
        for (String f : BssFields.NAMES) {
            String lower = f.toLowerCase(Locale.US);
            int at = t.indexOf(lower);
            while (at >= 0) {
                if (isAffirmedOccurrence(t, at, lower.length())) {
                    i.field = f;
                    break;
                }
                at = t.indexOf(lower, at + lower.length());
            }
            if (i.field != null) break;
        }
        if (i.field == null) {
            // common shorthand
            i.field = affirmedShorthandField(t);
        }

        boolean stop = containsAffirmed(t, "stop");
        boolean start = containsAffirmed(t, "start") || containsAffirmed(t, "farm") || containsAffirmed(t, "grind")
                || containsAffirmed(t, "collect") || containsAffirmed(t, "go farm");
        boolean quest = containsAffirmed(t, "quest") || containsAffirmed(t, "quests");
        boolean convert = containsAffirmed(t, "convert") || containsAffirmed(t, "backpack") || containsAffirmed(t, "bag full")
                || containsAffirmed(t, "hive is full") || containsAffirmed(t, "hive full");
        i.stopMacro = stop;
        i.startMacro = start && !stop;
        if (quest) { i.enableQuestSmart = true; i.wantQuestPreset = true; }
        if (convert) i.convertWhenFull = true;
        if (containsAffirmedAny(t, "glue", "gumm", "enzyme", "wax", "oil", "extract", "glitter",
                "token", "treat", "ticket", "seed", "strawberr", "blueberry", "material", "craft")) {
            i.materialGoal = extractMaterialGoal(t);
            i.notes.add("material-farm goal detected");
        }
        if (containsAffirmed(t, "loot") && i.materialGoal == null) {
            i.materialGoal = extractMaterialGoal(t);
        }
        if (t.contains("buy") || t.contains("shop") || t.contains("sparkette")) {
            i.unsupported.add("Shop purchases are not controlled by HiveMine Mobile config.");
        }
        if (i.field != null) i.notes.add("field=" + i.field);
        if (i.wantQuestPreset) i.notes.add("quest-smart on");
        if (i.convertWhenFull) i.notes.add("convert-when-full");
        return i;
    }

    /** Extracts the actual material token instead of passing the entire user sentence downstream. */
    private static String extractMaterialGoal(String text) {
        String[] materials = {
            "royal jelly", "tropical drinks", "micro converters", "micro-converters",
            "red extract", "blue extract", "sunflower seeds", "moon charms",
            "pineapple tokens", "star jellies", "gingerbread bears", "cloud vials",
            "coconut clogs", "coconut canisters", "caustic wax", "swirled wax",
            "soft wax", "hard wax", "gumdrops", "strawberries", "blueberries",
            "pineapple", "coconut", "stingers", "tickets", "glue", "enzymes",
            "oil", "glitter", "treats", "seeds", "token", "wax", "extract",
            "material", "craft"
        };
        for (String material : materials) if (containsAffirmed(text, material)) return material;
        // Handle natural plurals/stems while still respecting negation.
        if (containsAffirmed(text, "gumm")) return "gumdrops";
        if (containsAffirmed(text, "enzyme")) return "enzymes";
        if (containsAffirmed(text, "strawberr")) return "strawberries";
        if (containsAffirmed(text, "blueberr")) return "blueberries";
        if (containsAffirmed(text, "pineapple")) return "pineapple";
        return "material";
    }

    private static String affirmedShorthandField(String text) {
        String[][] fields = {
            {"pine", "Pine Tree"}, {"sunflower", "Sunflower"}, {"clover", "Clover"},
            {"spider", "Spider"}, {"bamboo", "Bamboo"}, {"strawberry", "Strawberry"},
            {"mushroom", "Mushroom"}, {"blue flower", "Blue Flower"},
            {"blueflower", "Blue Flower"}, {"mountain", "Mountain Top"}
        };
        for (String[] field : fields) {
            int at = text.indexOf(field[0]);
            while (at >= 0) {
                if (isAffirmedOccurrence(text, at, field[0].length())) return field[1];
                at = text.indexOf(field[0], at + field[0].length());
            }
        }
        return null;
    }

    private static boolean isAffirmedOccurrence(String text, int at, int length) {
        int segmentStart = 0;
        for (int j = at - 1; j >= 0; j--) {
            char ch = text.charAt(j);
            if (ch == '.' || ch == ',' || ch == ';' || ch == '!' || ch == '?') {
                segmentStart = j + 1;
                break;
            }
        }
        String before = text.substring(segmentStart, at).trim();
        int and = before.lastIndexOf(" and");
        int but = before.lastIndexOf(" but");
        int split = Math.max(and, but);
        if (split >= 0) before = before.substring(split + 4).trim();
        return !before.matches(".*(?:\\b(?:don't|do not|never|avoid|without|no need to)\\b).*");
    }

    private static boolean containsAffirmedAny(String text, String... keywords) {
        for (String keyword : keywords) if (containsAffirmed(text, keyword)) return true;
        return false;
    }

    /** Returns true only when the keyword occurs in an affirmative clause. */
    private static boolean containsAffirmed(String text, String keyword) {
        if (text == null || keyword == null || keyword.trim().isEmpty()) return false;
        int from = 0;
        while (from < text.length()) {
            int at = indexOfWholePhrase(text, keyword, from);
            if (at < 0) return false;
            String before = commandSegmentBefore(text, at);
            if (!isNegated(before)) return true;
            from = at + keyword.length();
        }
        return false;
    }

    private static String commandSegmentBefore(String text, int at) {
        int start = clauseStart(text, at);
        int and = text.lastIndexOf(" and ", at);
        int but = text.lastIndexOf(" but ", at);
        if (and >= start) start = and + 5;
        if (but >= start) start = but + 5;
        return text.substring(start, at).trim();
    }

    private static int indexOfWholePhrase(String text, String phrase, int from) {
        int at = text.indexOf(phrase, from);
        while (at >= 0) {
            int end = at + phrase.length();
            boolean left = at == 0 || !Character.isLetterOrDigit(text.charAt(at - 1));
            boolean right = end >= text.length() || !Character.isLetterOrDigit(text.charAt(end));
            if (left && right) return at;
            at = text.indexOf(phrase, at + 1);
        }
        return -1;
    }

    private static int clauseStart(String text, int at) {
        for (int j = at - 1; j >= 0; j--) {
            char ch = text.charAt(j);
            if (ch == '.' || ch == ',' || ch == ';' || ch == '!' || ch == '?' || ch == ':') return j + 1;
        }
        return 0;
    }

    private static String clauseAround(String text, int at) {
        int start = clauseStart(text, at);
        int end = text.length();
        for (int j = at; j < text.length(); j++) {
            char ch = text.charAt(j);
            if (ch == '.' || ch == ',' || ch == ';' || ch == '!' || ch == '?' || ch == ':') { end = j; break; }
        }
        return text.substring(start, end).trim();
    }

    private static boolean isNegated(String beforeOrClause) {
        String s = beforeOrClause == null ? "" : beforeOrClause.toLowerCase(Locale.US).trim();
        if (s.isEmpty()) return false;
        // Negation must be close to the command, rather than anywhere earlier in the sentence.
        String[] words = s.split("\\s+");
        int from = Math.max(0, words.length - 7);
        StringBuilder tail = new StringBuilder();
        for (int i = from; i < words.length; i++) { if (tail.length() > 0) tail.append(' '); tail.append(words[i]); }
        String t = tail.toString();
        return t.matches(".*\\b(?:don't|do not|doesn't|does not|never|avoid|without|no|not|cannot|can't)\\b.*")
                || t.matches(".*\\b(no need to)\\b.*");
    }

}
