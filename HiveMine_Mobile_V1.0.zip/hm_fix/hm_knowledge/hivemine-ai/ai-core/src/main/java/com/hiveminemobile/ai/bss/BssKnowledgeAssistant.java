package com.hiveminemobile.ai.bss;

import java.util.Locale;

/**
 * Local Bee Swarm Simulator knowledge layer.
 * Important: it distinguishes stable game mechanics from recommendations that depend on
 * hive state, quest state, buffs and server-generated flower layouts.
 */
public final class BssKnowledgeAssistant {
    public String answer(String question) {
        if (question == null || question.trim().isEmpty()) return "Ask me anything about Bee Swarm Simulator.";
        String q = question.toLowerCase(Locale.US).trim();
        if (!looksLikeQuestion(q)) return null;

        if (has(q, "best bee", "which bee", "what bee should", "bee should i get"))
            return "There is no universal best bee. The right recommendation depends on hive color, gifted-bee collection, star-amulet passive, progression and current goal. I will not recommend a bee from color alone.";
        if (has(q, "gifted bee", "gifted bees"))
            return "Gifted bees matter because gifted bonuses are permanent while that gifted type is in the hive. HiveMine should account for gifted-type diversity and your progression target instead of blindly rerolling bees.";
        if (has(q, "royal jelly"))
            return "Royal Jelly rerolls a bee. It is a progression resource, so HiveMine should not spend it automatically unless the user has explicitly authorized that strategy.";
        if (has(q, "star amulet"))
            return "Star Amulets are progression-defining because the passive matters, not just the displayed pollen. Compare the passive, color synergy and current hive before choosing one.";
        if (has(q, "mask", "best mask"))
            return "Mask choice is progression- and hive-dependent. Gummy, Diamond and Demon are not interchangeable generic upgrades; compare the mask passive, color, conversion and the user's actual hive before recommending a switch.";
        if (has(q, "white pollen"))
            return "White pollen comes from white flowers. The normal white-family fields are Sunflower, Dandelion, Mushroom, Clover, Strawberry and Spider; Spider is uniquely all-white. For a specific quest, prefer the required field over a generic color recommendation.";
        if (has(q, "pollen", "pollen per hour", "make more honey"))
            return "Honey/hour is a loop, not one stat: field suitability + pollen multipliers + buffs + capacity + conversion + movement efficiency + uptime. HiveMine should optimize those from telemetry instead of assuming one field is always best.";
        if (has(q, "convert", "backpack", "bag full"))
            return "Pollen normally becomes honey at the hive or through conversion effects. A high bag percentage should trigger the configured return/conversion behavior; instant conversion changes effective capacity, so bag percentage alone is not a complete efficiency model.";
        if (has(q, "quest", "quests"))
            return "Quest optimization should split objectives into field pollen, color pollen, tokens, mobs and special actions. Combine compatible objectives into one route, then return to turn in when the quest is actually complete. Do not mark a quest complete from a stale or unreadable OCR line.";
        if (has(q, "field", "where should i farm", "farm where"))
            return "Field choice should follow the active objective. For a field-specific quest, that field gets priority; for a color-pollen objective, choose a field of the required color; otherwise use hive color, buffs, capacity, nectar and observed pollen rate. Flower layouts are server-generated, so a static 'best field' claim is unsafe.";
        if (has(q, "blue hive"))
            return "Blue hive strategy centers on blue pollen and its conversion/capacity synergy. Pine Tree, Bamboo, Blue Flower, Stump, Pineapple and Coconut are blue-family fields, but the best choice depends on the exact objective and buffs.";
        if (has(q, "red hive"))
            return "Red-family fields include Cactus, Rose and Pepper. Red hive optimization should also consider attack, conversion, buffs and the actual target—not simply stay in Pepper forever.";
        if (has(q, "white hive"))
            return "White-family fields include Sunflower, Dandelion, Mushroom, Clover, Strawberry and Spider. Spider is uniquely all-white; field choice still depends on the objective and current buffs.";
        if (has(q, "glue"))
            return "Glue is craftable from 50 Gumdrops + 10 Royal Jelly. It can also drop from mobs and certain activities; field farming can help indirectly, but HiveMine should not falsely claim that simply standing in one field guarantees Glue. Direct field-related Glue sources include rare drops in Dandelion, Pumpkin and Stump and rare pollen/leaf drops in Pineapple, Spider and Pumpkin.";
        if (has(q, "gumdrop", "gumdrops"))
            return "Gumdrops are not a single-field material. Sources include mobs, planters, Puffshrooms, sprouts, meteors and other activities. HiveMine should use the active objective and available source rather than routing every Gumdrop request to Spider.";
        if (has(q, "seed", "sunflower seed"))
            return "Sunflower Seeds are an inventory material, not the same thing as Sunflower-field pollen. Farming Sunflower can make sense for a field quest, but the AI must distinguish a 'collect pollen from Sunflower' objective from a 'get Sunflower Seeds' material objective.";
        if (has(q, "extract"))
            return "Red Extract and Blue Extract are not simply field-pollen rewards. Their acquisition is activity- and inventory-dependent, so HiveMine should not promise a single field as a guaranteed source.";
        if (has(q, "coconut"))
            return "Coconut is both a field and an inventory item. A request to farm the Coconut Field is different from a request to obtain Coconut items; HiveMine should preserve that distinction.";
        if (has(q, "nectar"))
            return "Nectar comes from planters and is tied to fields. The AI should track the useful nectar types and expiration instead of treating nectar as a generic permanent buff.";
        if (has(q, "sprinkler"))
            return "Sprinklers affect flower collection and regrowth. The AI should use the strongest available sprinkler and avoid claiming a sprinkler is equivalent to a pollen multiplier or field buff.";
        if (has(q, "boost", "field boost"))
            return "Field boosts multiply the value of farming, but the AI should only spend or plan around them when it can see the relevant buff state. Do not assume a boost is active because the user once activated it.";
        if (has(q, "micro-converter", "micro converter"))
            return "Micro-Converters are emergency conversion tools. They can be valuable when capacity would otherwise interrupt a strong run, but they should be treated as a limited resource rather than the default conversion method.";
        if (has(q, "vicious"))
            return "Vicious Bee is a combat/progression target. The AI should track stinger availability and actual spawn information rather than inventing a spawn timer.";
        if (has(q, "windy bee", "windy"))
            return "Windy Bee progression involves the Wind Shrine, donations, favor and actual spawn opportunities. HiveMine should not claim a deterministic spawn schedule when it cannot observe one.";
        if (has(q, "ticket", "tickets"))
            return "Tickets are a limited currency. Spending should follow the user's progression goal; HiveMine should never invent a ticket shop price or assume a purchase is optimal without current game data.";
        if (has(q, "overnight", "all night", "phone overnight"))
            return "Overnight automation can be interrupted by Android, Roblox, network or accessibility behavior and can create heat/battery load. HiveMine should report the actual observed session state rather than claiming guaranteed overnight completion.";
        if (has(q, "what can you do", "what do you know", "help me"))
            return "I can reason about fields, pollen, quests, bees, hive colors, masks, amulets, materials, conversion and macro strategy. When a fact is patch-sensitive or unavailable to HiveMine's live telemetry, I will label it as uncertain instead of inventing it.";
        return "I can answer stable Bee Swarm mechanics and combine them with HiveMine's live telemetry. For patch-sensitive numbers, event content or facts I cannot verify, I will say so instead of guessing.";
    }

    private static boolean looksLikeQuestion(String q) {
        return q.contains("?") || has(q, "what", "why", "how", "which", "where", "when", "who", "should i", "can i", "do i", "is ", "are ", "tell me", "help");
    }

    private static boolean has(String q, String... terms) {
        for (String term : terms) if (q.contains(term)) return true;
        return false;
    }
}
