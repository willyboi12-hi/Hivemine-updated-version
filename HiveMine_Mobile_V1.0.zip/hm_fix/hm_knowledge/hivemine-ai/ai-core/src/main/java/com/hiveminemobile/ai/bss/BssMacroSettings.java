package com.hiveminemobile.ai.bss;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Supported HiveMine Mobile Config keys only (from Config.java). No invented settings.
 */
public final class BssMacroSettings {
    private final LinkedHashMap<String, String> values = new LinkedHashMap<String, String>();

    public BssMacroSettings() {
        // safe defaults aligned with macro
        values.put("field", "Pine Tree");
        values.put("pattern", "Snake");
        values.put("size", "M");
        values.put("walkFirst", "true");
        values.put("returnToField", "true");
        values.put("questSmart", "true");
        values.put("humanMode", "true");
        values.put("humanLevel", "1");
        values.put("moveSpeed", "48");
        values.put("fullAction", "2"); // Convert at hive
        values.put("fullPercent", "90");
        values.put("aiControlEnabled", "false");
        values.put("runMinutes", "0");
    }

    public String get(String key) { return values.get(key); }
    public void set(String key, String value) {
        if (key != null && values.containsKey(key)) values.put(key, value);
    }
    public boolean supports(String key) { return values.containsKey(key); }
    public Map<String, String> snapshot() { return new LinkedHashMap<String, String>(values); }

    public void applyPreset(String preset) {
        if (preset == null) return;
        String p = preset.toLowerCase();
        if (p.contains("farm")) {
            set("walkFirst", "true"); set("returnToField", "true"); set("questSmart", "false");
            set("fullAction", "2"); set("fullPercent", "90");
        } else if (p.contains("quest")) {
            set("questSmart", "true"); set("walkFirst", "true"); set("returnToField", "true");
        } else if (p.contains("loot") || p.contains("collect")) {
            set("questSmart", "false"); set("returnToField", "true");
        } else if (p.contains("balance")) {
            set("questSmart", "true"); set("walkFirst", "true"); set("returnToField", "true");
            set("fullPercent", "85"); set("humanMode", "true");
        }
    }
}
