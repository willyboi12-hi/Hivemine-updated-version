package com.hiveminemobile.ai.bss;

import java.util.ArrayList;
import java.util.List;

/** Builds a transparent plan from an Intent against supported settings only. */
public final class BssPlanBuilder {
    public static final class Step {
        public final String action;
        public final String detail;
        public final boolean supported;
        public Step(String action, String detail, boolean supported) {
            this.action = action; this.detail = detail; this.supported = supported;
        }
    }

    public static final class Plan {
        public final List<Step> steps = new ArrayList<Step>();
        public final List<String> configChanges = new ArrayList<String>();
    }

    public Plan build(BssIntentParser.Intent intent, BssMacroSettings settings) {
        Plan p = new Plan();
        if (intent == null) return p;
        if (intent.field != null && settings.supports("field")) {
            p.steps.add(new Step("SET_FIELD", intent.field, true));
            p.configChanges.add("field=" + intent.field);
        }
        if (intent.enableQuestSmart) {
            p.steps.add(new Step("SET_QUEST_SMART", "true", true));
            p.configChanges.add("questSmart=true");
        }
        if (intent.convertWhenFull) {
            p.steps.add(new Step("SET_FULL_ACTION", "Convert at hive", true));
            p.steps.add(new Step("SET_FULL_PERCENT", "90", true));
            p.configChanges.add("fullAction=2");
            p.configChanges.add("fullPercent=90");
        }
        if (intent.wantFarmPreset) {
            p.steps.add(new Step("PRESET", "Farming Mode", true));
        }
        if (intent.wantQuestPreset) {
            p.steps.add(new Step("PRESET", "Quest Mode", true));
        }
        for (String u : intent.unsupported) {
            p.steps.add(new Step("UNSUPPORTED", u, false));
        }
        if (intent.stopMacro) {
            p.steps.add(new Step("STOP_MACRO", "request stop", true));
        } else if (intent.startMacro) {
            p.steps.add(new Step("START_MACRO", "requires aiControlEnabled + confirmation", true));
        }
        return p;
    }

    public void applySupported(Plan plan, BssMacroSettings settings) {
        if (plan == null || settings == null) return;
        for (String c : plan.configChanges) {
            int eq = c.indexOf('=');
            if (eq <= 0) continue;
            String k = c.substring(0, eq);
            String v = c.substring(eq + 1);
            if (settings.supports(k)) settings.set(k, v);
        }
        for (Step s : plan.steps) {
            if ("PRESET".equals(s.action)) settings.applyPreset(s.detail);
        }
    }
}
