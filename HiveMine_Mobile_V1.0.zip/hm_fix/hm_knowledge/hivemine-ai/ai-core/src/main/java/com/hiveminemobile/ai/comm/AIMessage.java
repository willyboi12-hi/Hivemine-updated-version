package com.hiveminemobile.ai.comm;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Immutable message between AI modules. Payloads are plain text key/value pairs, so a message
 * can describe an observation or a status but cannot carry code or commands.
 */
public final class AIMessage {
    public static final int MAX_PAYLOAD_ENTRIES = 16;
    public static final int MAX_PAYLOAD_TEXT = 512;

    private final long sequence;
    private final String sender;
    private final String recipient;
    private final String type;
    private final Map<String, String> payload;
    private final long sentAtMillis;

    AIMessage(long sequence, String sender, String recipient, String type,
              Map<String, String> payload, long sentAtMillis) {
        this.sequence = sequence;
        this.sender = sender;
        this.recipient = recipient;
        this.type = type;
        this.payload = Collections.unmodifiableMap(new LinkedHashMap<>(payload));
        this.sentAtMillis = sentAtMillis;
    }

    public long getSequence() { return sequence; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getType() { return type; }
    public Map<String, String> getPayload() { return payload; }
    public long getSentAtMillis() { return sentAtMillis; }

    /** Returns null when the payload is acceptable, otherwise the reason it is not. */
    static String payloadProblem(Map<String, String> payload) {
        if (payload.size() > MAX_PAYLOAD_ENTRIES) return "Payload has too many entries";
        for (Map.Entry<String, String> entry : payload.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            if (key == null || key.trim().isEmpty() || key.length() > MAX_PAYLOAD_TEXT) {
                return "Payload key is blank or too long";
            }
            if (value == null || value.length() > MAX_PAYLOAD_TEXT) {
                return "Payload value is missing or too long";
            }
        }
        return null;
    }
}
