package com.hiveminemobile.ai.compat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Phase 097: checks the project's Android configuration by reading its real files. It runs on the JVM,
 * so it cannot prove the build works. Missing Android SDK is reported as a BLOCKER, not hidden.
 */
public final class AndroidCompatibilityValidator {
    public enum Level { PASS, WARN, BLOCKER }

    public static final class Finding {
        public final Level level; public final String area, message;
        Finding(Level l, String a, String m) { level = l; area = a; message = m; }
        @Override public String toString() { return level + " [" + area + "] " + message; }
    }

    public static final class Report {
        public final List<Finding> findings;
        Report(List<Finding> f) { findings = Collections.unmodifiableList(f); }
        public int count(Level l) { int n = 0; for (Finding f : findings) if (f.level == l) n++; return n; }
        public String toMarkdown() {
            StringBuilder b = new StringBuilder("# Android compatibility report\n\n");
            for (Finding f : findings) b.append("- ").append(f).append('\n');
            b.append("\nBlockers: ").append(count(Level.BLOCKER)).append(", warnings: ").append(count(Level.WARN)).append('\n');
            return b.toString();
        }
    }

    static final Map<String, String> MIN_GRADLE_FOR_AGP = new HashMap<>();
    static { MIN_GRADLE_FOR_AGP.put("8.7", "8.9"); }

    /** Runs every check against the project at root. env and javaSpecVersion are passed in so tests can control them. */
    public Report validate(Path root, Map<String, String> env, String javaSpecVersion) {
        List<Finding> f = new ArrayList<>();
        String app = read(root.resolve("app/build.gradle"));
        String top = read(root.resolve("build.gradle"));
        String wrapper = read(root.resolve("gradle/wrapper/gradle-wrapper.properties"));
        if (app == null) f.add(new Finding(Level.BLOCKER, "gradle", "app/build.gradle is missing"));
        else checkGradle(app, top == null ? "" : top, wrapper == null ? "" : wrapper, f);
        checkDependencies(app == null ? "" : app, f);
        checkManifest(root, app == null ? "" : app, f);
        checkResources(root, f);
        checkDeprecatedApis(root, f);
        checkEnvironment(env, javaSpecVersion, app == null ? "" : app, f);
        return new Report(f);
    }

    static void checkGradle(String app, String top, String wrapper, List<Finding> f) {
        Integer compile = intOf(app, "compileSdk\\s+(\\d+)"), target = intOf(app, "targetSdk\\s+(\\d+)"), min = intOf(app, "minSdk\\s+(\\d+)");
        if (compile == null) f.add(new Finding(Level.BLOCKER, "sdk", "compileSdk is not declared"));
        if (target == null) f.add(new Finding(Level.BLOCKER, "sdk", "targetSdk is not declared"));
        if (min == null) f.add(new Finding(Level.BLOCKER, "sdk", "minSdk is not declared"));
        if (compile != null && target != null && compile < target)
            f.add(new Finding(Level.BLOCKER, "sdk", "compileSdk " + compile + " is below targetSdk " + target));
        if (min != null && target != null && min > target)
            f.add(new Finding(Level.BLOCKER, "sdk", "minSdk " + min + " is above targetSdk " + target));
        if (target != null && target < 31)
            f.add(new Finding(Level.WARN, "sdk", "targetSdk " + target + " is below 31; components need explicit android:exported"));
        if (min != null && min < 26)
            f.add(new Finding(Level.WARN, "sdk", "minSdk " + min + " is below 26; overlay types used by the app need API 26"));
        String agp = match(top + app, "com\\.android\\.application'?\\s*(?:version\\s*'?)([\\d.]+)");
        if (agp == null) f.add(new Finding(Level.BLOCKER, "gradle", "Android Gradle Plugin version not found"));
        String gradle = match(wrapper, "gradle-([\\d.]+)-bin");
        if (gradle == null) f.add(new Finding(Level.BLOCKER, "gradle", "gradle-wrapper.properties has no Gradle distribution"));
        if (agp != null && gradle != null) {
            String key = agp.startsWith("8.7") ? "8.7" : null;
            if (key == null) f.add(new Finding(Level.WARN, "gradle", "AGP " + agp + " has no pairing rule in this validator; check Google's table"));
            else if (compareVersions(gradle, MIN_GRADLE_FOR_AGP.get(key)) < 0)
                f.add(new Finding(Level.BLOCKER, "gradle", "AGP " + agp + " needs Gradle " + MIN_GRADLE_FOR_AGP.get(key) + "+, wrapper has " + gradle));
            else f.add(new Finding(Level.PASS, "gradle", "AGP " + agp + " and Gradle " + gradle + " are compatible"));
        }
    }

    static void checkDependencies(String app, List<Finding> f) {
        for (String line : app.split("\n")) {
            String t = line.trim();
            if (!(t.startsWith("implementation") || t.startsWith("api") || t.startsWith("testImplementation"))) continue;
            if (t.contains("project(")) continue;
            if (t.contains("+") || t.contains("latest.")) f.add(new Finding(Level.WARN, "dependencies", "dynamic version: " + t));
        }
    }

    static void checkManifest(Path root, String app, List<Finding> f) {
        String m = read(root.resolve("app/src/main/AndroidManifest.xml"));
        if (m == null) { f.add(new Finding(Level.BLOCKER, "manifest", "AndroidManifest.xml is missing")); return; }
        Integer target = intOf(app, "targetSdk\\s+(\\d+)");
        if (target != null && target >= 31) {
            java.util.regex.Matcher mt = java.util.regex.Pattern.compile("<(activity|service|receiver)\\b[^>]*>").matcher(m);
            while (mt.find()) {
                String tag = mt.group();
                if (!tag.contains("android:exported"))
                    f.add(new Finding(Level.BLOCKER, "manifest", "component without android:exported: " + tag.replaceAll("\\s+", " ")));
            }
        }
        if (m.contains("AccessibilityService") && !m.contains("android.permission.BIND_ACCESSIBILITY_SERVICE"))
            f.add(new Finding(Level.WARN, "manifest", "accessibility service has no BIND_ACCESSIBILITY_SERVICE permission"));
    }

    static void checkResources(Path root, List<Finding> f) {
        Set<String> defined = new HashSet<>();
        Set<String> referenced = new TreeSet<>();
        try {
            Path res = root.resolve("app/src/main/res");
            if (!Files.isDirectory(res)) return;
            Files.walk(res).filter(p -> p.toString().endsWith(".xml")).forEach(p -> {
                String s = read(p);
                if (s == null) return;
                java.util.regex.Matcher d = java.util.regex.Pattern.compile("<string name=\"([^\"]+)\"").matcher(s);
                while (d.find()) defined.add(d.group(1));
                java.util.regex.Matcher r = java.util.regex.Pattern.compile("@string/([A-Za-z0-9_]+)").matcher(s);
                while (r.find()) referenced.add(r.group(1));
            });
        } catch (IOException e) {
            f.add(new Finding(Level.WARN, "resources", "could not scan resources: " + e.getMessage()));
            return;
        }
        for (String r : referenced) if (!defined.contains(r))
            f.add(new Finding(Level.BLOCKER, "resources", "@string/" + r + " is referenced but not defined"));
        if (referenced.isEmpty()) f.add(new Finding(Level.PASS, "resources", "no string references to check"));
        else f.add(new Finding(Level.PASS, "resources", referenced.size() + " string references checked"));
    }

    static final String[] DEPRECATED = {"getRunningTasks(", "new AsyncTask", "startActivityForResult(", "onActivityResult("};

    static void checkDeprecatedApis(Path root, List<Finding> f) {
        try {
            Path src = root.resolve("app/src/main/java");
            if (!Files.isDirectory(src)) return;
            Files.walk(src).filter(p -> p.toString().endsWith(".java")).forEach(p -> {
                String s = read(p);
                if (s == null) return;
                for (String d : DEPRECATED) if (s.contains(d))
                    f.add(new Finding(Level.WARN, "api", p.getFileName() + " uses " + d.trim() + ", which is deprecated"));
            });
        } catch (IOException e) {
            f.add(new Finding(Level.WARN, "api", "could not scan sources: " + e.getMessage()));
        }
    }

    static void checkEnvironment(Map<String, String> env, String javaSpec, String app, List<Finding> f) {
        String sdk = env.get("ANDROID_HOME");
        if (sdk == null || sdk.trim().isEmpty()) {
            f.add(new Finding(Level.BLOCKER, "environment", "ANDROID_HOME is not set: the Android SDK is not installed here, so the APK cannot be built or verified"));
        } else if (!Files.isDirectory(Paths.get(sdk, "platforms"))) {
            f.add(new Finding(Level.BLOCKER, "environment", "ANDROID_HOME has no platforms directory: " + sdk));
        }
        Integer src = intOf(app, "VERSION_(\\d+)");
        if (src != null && javaSpec != null) {
            double have = parseJava(javaSpec);
            if (have < src) f.add(new Finding(Level.BLOCKER, "java", "project compiles with Java " + src + " but JDK is " + javaSpec));
            else f.add(new Finding(Level.PASS, "java", "JDK " + javaSpec + " covers the project's Java " + src));
        }
    }

    static double parseJava(String v) {
        try { return Double.parseDouble(v.trim()); } catch (NumberFormatException e) { return 0; }
    }

    static String read(Path p) {
        try { return new String(Files.readAllBytes(p), StandardCharsets.UTF_8); } catch (IOException | RuntimeException e) { return null; }
    }

    static Integer intOf(String s, String regex) {
        String m = match(s, regex);
        return m == null ? null : Integer.valueOf(m);
    }

    static String match(String s, String regex) {
        if (s == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(regex).matcher(s);
        return m.find() ? m.group(1) : null;
    }

    static int compareVersions(String a, String b) {
        String[] x = a.split("\\."), y = b.split("\\.");
        for (int i = 0; i < Math.max(x.length, y.length); i++) {
            int p = i < x.length ? Integer.parseInt(x[i]) : 0, q = i < y.length ? Integer.parseInt(y[i]) : 0;
            if (p != q) return Integer.compare(p, q);
        }
        return 0;
    }
}
