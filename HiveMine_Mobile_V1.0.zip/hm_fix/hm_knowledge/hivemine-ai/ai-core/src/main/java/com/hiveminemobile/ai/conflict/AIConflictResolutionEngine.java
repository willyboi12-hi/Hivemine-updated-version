package com.hiveminemobile.ai.conflict;

import java.util.*;

/**
 * Phase 094: finds conflicting configuration requests before anything runs, and applies only resolved values.
 * Two systems can never both write the same key. An unresolved conflict is rejected, and nothing is applied for it.
 */
public final class AIConflictResolutionEngine {
    /** Manager AI's arbitration. Returns one of the requested values, or null to decline. */
    public interface Arbiter { String arbitrate(String key, List<ConfigRequest> requests); }

    private final ConfigurationConflictAnalyzer analyzer = new ConfigurationConflictAnalyzer();
    private final ConflictPriorityResolver resolver = new ConflictPriorityResolver();
    private final List<ConflictResolutionRecord> records = new ArrayList<>();

    /** Conflicts found in the requests. A non-empty result means execution must not start yet. */
    public List<ConfigurationConflictAnalyzer.Conflict> checkBeforeExecution(List<ConfigRequest> requests) {
        return analyzer.analyze(requests);
    }

    /** Returns the values that may be applied. Rejected keys are absent from the map. */
    public synchronized Map<String, String> resolve(List<ConfigRequest> requests, Map<String, String> userPreferences,
                                                    Arbiter arbiter, Set<String> dependencyBlockedKeys, long now) {
        Map<String, String> apply = new TreeMap<>();
        Set<String> blocked = dependencyBlockedKeys == null ? Collections.<String>emptySet() : dependencyBlockedKeys;
        Set<String> conflicting = new HashSet<>();
        for (ConfigurationConflictAnalyzer.Conflict c : analyzer.analyze(requests)) {
            conflicting.add(c.key);
            ConflictPriorityResolver.Verdict v = resolver.resolve(c, userPreferences, blocked.contains(c.key));
            if (v.decision == ConflictResolutionRecord.Decision.MANAGER_ARBITRATION) {
                String chosen = arbiter == null ? null : arbiter.arbitrate(c.key, c.requests);
                if (chosen != null && allRequested(c.requests, chosen)) {
                    apply.put(c.key, chosen);
                    records.add(new ConflictResolutionRecord(c.key, v.decision, chosen, "MANAGER", now));
                } else {
                    records.add(new ConflictResolutionRecord(c.key, ConflictResolutionRecord.Decision.REJECTED, null, "NONE", now));
                }
            } else if (v.decision == ConflictResolutionRecord.Decision.USER_PREFERENCE) {
                apply.put(c.key, v.value);
                records.add(new ConflictResolutionRecord(c.key, v.decision, v.value, "USER", now));
            } else {
                records.add(new ConflictResolutionRecord(c.key, v.decision, null, "NONE", now));
            }
        }
        for (ConfigRequest r : requests) {
            if (r == null || r.key == null || conflicting.contains(r.key)) continue;
            apply.put(r.key, r.value);
        }
        return apply;
    }

    public synchronized List<ConflictResolutionRecord> records() { return Collections.unmodifiableList(new ArrayList<>(records)); }

    private static boolean allRequested(List<ConfigRequest> reqs, String value) {
        for (ConfigRequest r : reqs) if (value.equals(r.value)) return true;
        return false;
    }
}
