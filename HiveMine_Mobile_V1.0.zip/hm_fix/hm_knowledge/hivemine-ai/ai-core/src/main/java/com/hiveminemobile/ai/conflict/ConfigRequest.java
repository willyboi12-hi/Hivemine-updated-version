package com.hiveminemobile.ai.conflict;

/** Phase 094: one system's request to set a configuration key. */
public final class ConfigRequest {
    public final String system, key, value;
    public ConfigRequest(String system, String key, String value) { this.system = system; this.key = key; this.value = value; }
}
