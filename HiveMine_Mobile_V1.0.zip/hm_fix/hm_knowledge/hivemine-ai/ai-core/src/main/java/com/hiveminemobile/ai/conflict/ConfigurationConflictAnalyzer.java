package com.hiveminemobile.ai.conflict;

import java.util.*;

/** Phase 094: finds configuration keys that two or more systems want to set to different values. */
public final class ConfigurationConflictAnalyzer {
    public static final class Conflict {
        public final String key;
        public final List<ConfigRequest> requests;
        Conflict(String key, List<ConfigRequest> r) { this.key = key; requests = Collections.unmodifiableList(r); }
    }

    public List<Conflict> analyze(List<ConfigRequest> requests) {
        Map<String, List<ConfigRequest>> byKey = new TreeMap<>();
        for (ConfigRequest r : requests) if (r != null && r.key != null) byKey.computeIfAbsent(r.key, k -> new ArrayList<>()).add(r);
        List<Conflict> out = new ArrayList<>();
        for (Map.Entry<String, List<ConfigRequest>> e : byKey.entrySet()) {
            Set<String> values = new HashSet<>();
            for (ConfigRequest r : e.getValue()) values.add(r.value);
            if (values.size() > 1) out.add(new Conflict(e.getKey(), e.getValue()));
        }
        return out;
    }
}
