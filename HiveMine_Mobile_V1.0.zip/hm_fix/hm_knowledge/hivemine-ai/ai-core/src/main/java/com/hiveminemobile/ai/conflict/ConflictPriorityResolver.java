package com.hiveminemobile.ai.conflict;

import java.util.*;

/**
 * Phase 094: user settings come first and cannot be overridden by any system. Otherwise the conflict goes to Manager AI.
 * A conflict that touches a dependency is rejected rather than guessed.
 */
public final class ConflictPriorityResolver {
    public static final class Verdict {
        public final ConflictResolutionRecord.Decision decision;
        public final String value; // null unless decided
        Verdict(ConflictResolutionRecord.Decision d, String v) { decision = d; value = v; }
    }

    public Verdict resolve(ConfigurationConflictAnalyzer.Conflict c, Map<String, String> userPreferences, boolean dependencyBlocked) {
        String pref = userPreferences == null ? null : userPreferences.get(c.key);
        if (pref != null) return new Verdict(ConflictResolutionRecord.Decision.USER_PREFERENCE, pref);
        if (dependencyBlocked) return new Verdict(ConflictResolutionRecord.Decision.REJECTED, null);
        return new Verdict(ConflictResolutionRecord.Decision.MANAGER_ARBITRATION, null);
    }
}
