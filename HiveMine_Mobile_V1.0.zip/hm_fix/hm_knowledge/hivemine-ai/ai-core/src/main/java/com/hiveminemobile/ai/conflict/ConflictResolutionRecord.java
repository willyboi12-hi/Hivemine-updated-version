package com.hiveminemobile.ai.conflict;

/** Phase 094: the resolution that was selected for one conflict, and who selected it. */
public final class ConflictResolutionRecord {
    public enum Decision { USER_PREFERENCE, MANAGER_ARBITRATION, REJECTED }

    public final String key;
    public final Decision decision;
    public final String value;      // null when rejected
    public final String decidedBy;  // "USER", "MANAGER", or "NONE"
    public final long atMillis;

    public ConflictResolutionRecord(String key, Decision d, String value, String decidedBy, long at) {
        this.key = key; this.decision = d; this.value = value; this.decidedBy = decidedBy; this.atMillis = at;
    }
}
