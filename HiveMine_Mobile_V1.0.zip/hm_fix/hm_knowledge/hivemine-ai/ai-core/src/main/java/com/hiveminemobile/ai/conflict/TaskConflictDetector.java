package com.hiveminemobile.ai.conflict;

import java.util.*;

/** Phase 094: two different systems that need the same exclusive resource at once conflict. */
public final class TaskConflictDetector {
    public static final class TaskClaim {
        public final String system, resource, taskId;
        public TaskClaim(String system, String resource, String taskId) { this.system = system; this.resource = resource; this.taskId = taskId; }
    }

    public List<String> detect(List<TaskClaim> claims) {
        Map<String, Set<String>> systemsByResource = new TreeMap<>();
        for (TaskClaim c : claims) if (c != null && c.resource != null) systemsByResource.computeIfAbsent(c.resource, k -> new TreeSet<>()).add(c.system);
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, Set<String>> e : systemsByResource.entrySet())
            if (e.getValue().size() > 1) out.add(e.getKey() + " claimed by " + e.getValue());
        return out;
    }
}
