package com.hiveminemobile.ai.control;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Enforces the authorization rule for AI control of the macro. The AI may start or recover only
 * after the user has enabled AI control. Stop is always forwarded, because it is the emergency path.
 * Every result is a request outcome, not a confirmed action: callers must verify with readStatus().
 */
public final class AutomationController {
    public enum Decision {
        START_REQUESTED, RECOVER_REQUESTED, CONVERT_REQUESTED, STOP_REQUESTED, STOP_DISPATCH_FAILED,
        REFUSED_NOT_ENABLED, REFUSED_NOT_CONNECTED, REFUSED_ALREADY_RUNNING, REFUSED_NOT_RUNNING
    }

    private static final int AUDIT_LIMIT = 100;

    private final MacroPort port;
    private final ArrayDeque<String> audit = new ArrayDeque<>();
    private boolean aiControlEnabled;

    public AutomationController(MacroPort port) {
        if (port == null) throw new IllegalArgumentException("port must not be null");
        this.port = port;
    }

    /** Called only from the user's own settings. The AI core never calls this. */
    public synchronized void setAiControlEnabled(boolean enabled) {
        aiControlEnabled = enabled;
        log("AI control " + (enabled ? "enabled" : "disabled") + " by user");
    }

    public synchronized boolean isAiControlEnabled() {
        return aiControlEnabled;
    }

    /** Current macro state, exposed so higher-level bridges cannot bypass authorization. */
    public synchronized MacroStatus readStatus() {
        try {
            return port.readStatus();
        } catch (RuntimeException e) {
            return MacroStatus.disconnected("Macro status unavailable: " + e.getClass().getSimpleName());
        }
    }

    public synchronized Decision requestStart() {
        if (!aiControlEnabled) return record(Decision.REFUSED_NOT_ENABLED, "start");
        MacroStatus status = readStatus();
        if (!status.isConnected()) return record(Decision.REFUSED_NOT_CONNECTED, "start");
        if (status.isRunning()) return record(Decision.REFUSED_ALREADY_RUNNING, "start");
        port.start();
        return record(Decision.START_REQUESTED, "start");
    }

    public synchronized Decision requestRecover() {
        if (!aiControlEnabled) return record(Decision.REFUSED_NOT_ENABLED, "recover");
        MacroStatus status = readStatus();
        if (!status.isConnected()) return record(Decision.REFUSED_NOT_CONNECTED, "recover");
        if (!status.isRunning()) return record(Decision.REFUSED_NOT_RUNNING, "recover");
        port.recover();
        return record(Decision.RECOVER_REQUESTED, "recover");
    }

    /** Requests conversion without changing the user's farm authorization state. */
    public synchronized Decision requestConvert() {
        if (!aiControlEnabled) return record(Decision.REFUSED_NOT_ENABLED, "convert");
        MacroStatus status = readStatus();
        if (!status.isConnected()) return record(Decision.REFUSED_NOT_CONNECTED, "convert");
        if (!status.isRunning()) return record(Decision.REFUSED_NOT_RUNNING, "convert");
        try {
            port.convertNow();
            return record(Decision.CONVERT_REQUESTED, "convert");
        } catch (RuntimeException e) {
            return record(Decision.STOP_DISPATCH_FAILED, "convert dispatch failed: " + e.getClass().getSimpleName());
        }
    }

    /** Always forwarded, even when AI control is disabled. */
    public synchronized Decision requestStop() {
        // STOP is the emergency path. A status-read failure must never prevent
        // the actual stop request from reaching the macro.
        boolean connected = false;
        boolean statusKnown = true;
        try {
            connected = port.readStatus().isConnected();
        } catch (RuntimeException e) {
            statusKnown = false;
        }
        try {
            port.stop();
        } catch (RuntimeException e) {
            return record(Decision.STOP_DISPATCH_FAILED, "stop dispatch failed: " + e.getClass().getSimpleName());
        }
        if (statusKnown && !connected) return record(Decision.REFUSED_NOT_CONNECTED, "stop");
        return record(Decision.STOP_REQUESTED, "stop");
    }

    public synchronized List<String> getAuditTrail() {
        return Collections.unmodifiableList(new ArrayList<>(audit));
    }

    private Decision record(Decision decision, String action) {
        while (audit.size() >= AUDIT_LIMIT) audit.removeFirst();
        audit.addLast(decision.name() + " for " + action);
        return decision;
    }

    private void log(String entry) {
        while (audit.size() >= AUDIT_LIMIT) audit.removeFirst();
        audit.addLast(entry);
    }
}
