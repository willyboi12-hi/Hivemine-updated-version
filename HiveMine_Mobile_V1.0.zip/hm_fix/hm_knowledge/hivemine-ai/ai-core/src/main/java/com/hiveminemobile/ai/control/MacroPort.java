package com.hiveminemobile.ai.control;

/**
 * The only surface through which HiveMineAI touches HiveMine Mobile's macro. HiveMine Mobile supplies the
 * implementation at merge time; the AI core never calls Android or the macro directly.
 */
public interface MacroPort {
    /** Requests that the macro start now. Returning does not mean it has started; check readStatus(). */
    void start();

    /** Requests that the macro stop. Must always be honored, whatever the AI's state. */
    void stop();

    /** Requests a rejoin of the Roblox server. */
    void recover();

    /** Requests an immediate conversion at the hive. Returning does not mean conversion completed; check readStatus(). */
    default void convertNow() {}

    /** Reads what the macro reports about itself. */
    MacroStatus readStatus();
}
