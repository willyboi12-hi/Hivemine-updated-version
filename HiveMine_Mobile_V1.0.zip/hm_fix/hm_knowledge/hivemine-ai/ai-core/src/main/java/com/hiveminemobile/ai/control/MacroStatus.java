package com.hiveminemobile.ai.control;

/** What the macro reports at one moment. Immutable and sourced from the live Android macro service. */
public final class MacroStatus {
    private final boolean connected;
    private final boolean running;
    private final String note;
    private final long recoveryGeneration;
    private final boolean recoveryInProgress;
    private final int bagPercent;
    private final String scene;
    private final long observedAtMillis;

    private MacroStatus(boolean connected, boolean running, String note, long recoveryGeneration,
                        boolean recoveryInProgress, int bagPercent, String scene, long observedAtMillis) {
        this.connected = connected;
        this.running = running;
        this.note = note == null ? "" : note;
        this.recoveryGeneration = recoveryGeneration;
        this.recoveryInProgress = recoveryInProgress;
        this.bagPercent = bagPercent < 0 || bagPercent > 100 ? -1 : bagPercent;
        this.scene = scene == null ? "UNKNOWN" : scene;
        this.observedAtMillis = Math.max(0L, observedAtMillis);
    }

    /** The macro service is not bound, so nothing can be sent to it. */
    public static MacroStatus disconnected(String note) {
        return new MacroStatus(false, false, note, 0L, false, -1, "UNKNOWN", 0L);
    }

    public static MacroStatus connected(boolean running, String note) {
        return new MacroStatus(true, running, note, 0L, false, -1, "UNKNOWN", 0L);
    }

    /** Optional monotonic counter used to verify a recovery attempt actually began. */
    public static MacroStatus connected(boolean running, String note, long recoveryGeneration) {
        return new MacroStatus(true, running, note, recoveryGeneration, false, -1, "UNKNOWN", 0L);
    }

    public static MacroStatus connected(boolean running, String note, long recoveryGeneration, boolean recoveryInProgress) {
        return new MacroStatus(true, running, note, recoveryGeneration, recoveryInProgress, -1, "UNKNOWN", 0L);
    }

    /** Live telemetry from the same screenshot polling loop that reads bag and scene state. */
    public static MacroStatus connected(boolean running, String note, long recoveryGeneration,
                                        boolean recoveryInProgress, int bagPercent, String scene,
                                        long observedAtMillis) {
        return new MacroStatus(true, running, note, recoveryGeneration, recoveryInProgress,
            bagPercent, scene, observedAtMillis);
    }

    public long getRecoveryGeneration() { return recoveryGeneration; }
    public boolean isRecoveryInProgress() { return recoveryInProgress; }
    public int getBagPercent() { return bagPercent; }
    public String getScene() { return scene; }
    public long getObservedAtMillis() { return observedAtMillis; }
    public boolean isConnected() { return connected; }
    public boolean isRunning() { return running; }
    public String getNote() { return note; }
}
