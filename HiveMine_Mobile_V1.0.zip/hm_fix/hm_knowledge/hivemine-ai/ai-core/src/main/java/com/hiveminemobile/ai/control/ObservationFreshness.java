package com.hiveminemobile.ai.control;

/** Pure time-window check shared by the Android screenshot watchdog and JVM tests. */
public final class ObservationFreshness {
    private ObservationFreshness() {}

    /**
     * Returns true when observations were expected but no usable frame has arrived within maxAgeMs.
     * lastObservedAtMs may be zero when the screenshot pipeline has never returned a valid frame;
     * monitoringStartedAtMs then provides the baseline. All timestamps must use the same monotonic
     * clock (Android uses SystemClock.uptimeMillis()).
     */
    public static boolean isStale(long lastObservedAtMs, long monitoringStartedAtMs,
                                  long nowMs, long maxAgeMs) {
        if (maxAgeMs < 0L || nowMs < 0L) return false;
        long baseline = lastObservedAtMs > 0L ? lastObservedAtMs : monitoringStartedAtMs;
        return baseline > 0L && nowMs >= baseline && nowMs - baseline > maxAgeMs;
    }
}
