package com.hiveminemobile.ai.crosssystem;

import java.util.*;

/**
 * Phase 093: validated, traceable messages between specialist systems and Manager AI.
 * Each message is delivered once. Failures and timeouts are sent to the failure listener, so Manager AI hears about them.
 */
public final class CrossSystemCommunicationManager {
    public enum SendResult { SENT, MALFORMED, UNKNOWN_DESTINATION, DUPLICATE_ID, UNKNOWN_REQUEST }
    public enum DeliveryResult { DELIVERED, DUPLICATE_PROCESSED, NO_HANDLER, UNKNOWN_MESSAGE, HANDLER_FAILED }

    public interface Handler { void handle(CrossSystemMessage m); }
    public interface FailureListener { void onFailure(String messageId, String reason); }

    private final Map<String, Handler> handlers = new TreeMap<>();
    private final Map<String, CrossSystemMessage> messages = new HashMap<>();
    private final Set<String> processed = new HashSet<>();
    private final MessageValidationEngine validator = new MessageValidationEngine();
    private final MessageDeliveryTracker tracker;
    private final SystemCommunicationLogger log = new SystemCommunicationLogger();
    private final FailureListener failures;

    public CrossSystemCommunicationManager(long timeoutMillis, FailureListener failures) {
        this.tracker = new MessageDeliveryTracker(timeoutMillis);
        this.failures = failures;
    }

    /** Destinations are the systems that can receive messages, including "manager". */
    public synchronized boolean register(String destination, Handler h) {
        if (destination == null || destination.trim().isEmpty() || h == null || handlers.containsKey(destination.trim())) return false;
        handlers.put(destination.trim(), h);
        return true;
    }

    public synchronized SendResult send(CrossSystemMessage m, long now) {
        MessageValidationEngine.Result v = validator.validate(m, handlers.keySet());
        if (v == MessageValidationEngine.Result.MALFORMED) { log.log(now, "REFUSED malformed"); return SendResult.MALFORMED; }
        if (v == MessageValidationEngine.Result.UNKNOWN_DESTINATION) { log.log(now, "REFUSED unknown destination " + m.to); return SendResult.UNKNOWN_DESTINATION; }
        if (messages.containsKey(m.id)) { log.log(now, "REFUSED duplicate id " + m.id); return SendResult.DUPLICATE_ID; }
        if ("RESPONSE".equals(m.type) && !messages.containsKey(m.requestId)) return SendResult.UNKNOWN_REQUEST;
        messages.put(m.id, m);
        tracker.track(m.id, now);
        log.log(now, "SENT " + m.id + " " + m.type + " " + m.from + "->" + m.to + (m.requestId == null ? "" : " re " + m.requestId));
        return SendResult.SENT;
    }

    /** send() queues the message. deliver() hands it to the handler. A message not delivered before its timeout is reported. */
    public synchronized DeliveryResult deliver(String id, long now) {
        CrossSystemMessage m = messages.get(id);
        if (m == null) return DeliveryResult.UNKNOWN_MESSAGE;
        if (processed.contains(id)) return DeliveryResult.DUPLICATE_PROCESSED;
        Handler h = handlers.get(m.to);
        if (h == null) return DeliveryResult.NO_HANDLER;
        tracker.set(id, MessageDeliveryTracker.State.DELIVERED);
        try {
            h.handle(m);
            processed.add(id);
            tracker.set(id, MessageDeliveryTracker.State.PROCESSED);
            log.log(now, "PROCESSED " + id);
            return DeliveryResult.DELIVERED;
        } catch (RuntimeException e) {
            tracker.set(id, MessageDeliveryTracker.State.FAILED);
            log.log(now, "FAILED " + id + " " + e.getMessage());
            notifyFailure(id, "handler failed: " + e.getMessage());
            return DeliveryResult.HANDLER_FAILED;
        }
    }

    /** Call regularly. Messages that never finished are reported to Manager AI as timeouts. */
    public synchronized List<String> tick(long now) {
        List<String> timedOut = tracker.expire(now);
        for (String id : timedOut) {
            log.log(now, "TIMED_OUT " + id);
            notifyFailure(id, "timed out");
        }
        return timedOut;
    }

    public synchronized MessageDeliveryTracker.State stateOf(String id) { return tracker.state(id); }
    public synchronized List<String> logEntries() { return log.entries(); }

    private void notifyFailure(String id, String reason) {
        if (failures != null) failures.onFailure(id, reason);
    }
}
