package com.hiveminemobile.ai.crosssystem;

/** Phase 093: the standard internal message. type is REQUEST, RESPONSE, or NOTIFICATION. */
public final class CrossSystemMessage {
    public final String id, requestId, from, to, type, payload;
    public final long createdAtMillis;

    public CrossSystemMessage(String id, String requestId, String from, String to, String type, String payload, long at) {
        this.id = id; this.requestId = requestId; this.from = from; this.to = to;
        this.type = type; this.payload = payload; this.createdAtMillis = at;
    }
}
