package com.hiveminemobile.ai.crosssystem;

import java.util.*;

/** Phase 093: where each message is in its delivery. Timed-out messages are reported, not forgotten. */
public final class MessageDeliveryTracker {
    public enum State { SENT, DELIVERED, PROCESSED, TIMED_OUT, FAILED }

    private static final class Entry { State state; final long deadline; Entry(State s, long d) { state = s; deadline = d; } }

    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final long timeoutMillis;

    public MessageDeliveryTracker(long timeoutMillis) {
        if (timeoutMillis <= 0) throw new IllegalArgumentException("timeout must be positive");
        this.timeoutMillis = timeoutMillis;
    }

    public synchronized void track(String id, long now) { entries.put(id, new Entry(State.SENT, now + timeoutMillis)); }

    public synchronized void set(String id, State s) {
        Entry e = entries.get(id);
        if (e != null && e.state != State.PROCESSED && e.state != State.TIMED_OUT && e.state != State.FAILED) e.state = s;
    }

    /** Marks overdue messages that never finished. Returns their ids. */
    public synchronized List<String> expire(long now) {
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, Entry> me : entries.entrySet()) {
            Entry e = me.getValue();
            if ((e.state == State.SENT || e.state == State.DELIVERED) && now > e.deadline) {
                e.state = State.TIMED_OUT;
                out.add(me.getKey());
            }
        }
        return out;
    }

    public synchronized State state(String id) { Entry e = entries.get(id); return e == null ? null : e.state; }
    public synchronized boolean known(String id) { return entries.containsKey(id); }
}
