package com.hiveminemobile.ai.crosssystem;

import java.util.*;

/** Phase 093: checks each message before it is sent. Malformed or misrouted messages are refused. */
public final class MessageValidationEngine {
    public enum Result { VALID, MALFORMED, UNKNOWN_DESTINATION }

    private static final Set<String> TYPES = new HashSet<>(Arrays.asList("REQUEST", "RESPONSE", "NOTIFICATION"));

    public Result validate(CrossSystemMessage m, Set<String> knownDestinations) {
        if (m == null || blank(m.id) || blank(m.from) || blank(m.to) || m.payload == null) return Result.MALFORMED;
        if (!TYPES.contains(m.type)) return Result.MALFORMED;
        if (m.from.trim().equals(m.to.trim())) return Result.MALFORMED;
        if ("RESPONSE".equals(m.type) && blank(m.requestId)) return Result.MALFORMED;
        if (!knownDestinations.contains(m.to.trim())) return Result.UNKNOWN_DESTINATION;
        return Result.VALID;
    }

    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
