package com.hiveminemobile.ai.crosssystem;

import java.util.*;

/** Phase 093: a bounded communication log, for tracing a request through its response. */
public final class SystemCommunicationLogger {
    private static final int MAX = 1000;
    private final Deque<String> entries = new ArrayDeque<>();

    public synchronized void log(long now, String what) {
        entries.addLast(now + " " + what);
        while (entries.size() > MAX) entries.removeFirst();
    }

    public synchronized List<String> entries() { return new ArrayList<>(entries); }
}
