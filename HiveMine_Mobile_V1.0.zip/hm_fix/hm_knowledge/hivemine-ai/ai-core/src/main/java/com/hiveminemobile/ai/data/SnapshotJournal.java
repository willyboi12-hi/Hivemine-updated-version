package com.hiveminemobile.ai.data;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/** Append-only journal of named snapshots. */
public final class SnapshotJournal {
    public static final class Entry {
        public final long atMs; public final String name; public final String payload;
        public Entry(long atMs, String name, String payload) {
            this.atMs = atMs; this.name = name == null ? "" : name; this.payload = payload == null ? "" : payload;
        }
    }
    private final ArrayList<Entry> entries = new ArrayList<Entry>();
    private final int limit;
    public SnapshotJournal(int limit) { this.limit = Math.max(1, limit); }
    public synchronized void append(long atMs, String name, String payload) {
        entries.add(new Entry(atMs, name, payload));
        while (entries.size() > limit) entries.remove(0);
    }
    public synchronized List<Entry> list() { return Collections.unmodifiableList(new ArrayList<Entry>(entries)); }
    public synchronized int size() { return entries.size(); }
}
