package com.hiveminemobile.ai.decision;

import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.manager.intel.SpecialistVote;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Adaptive supervisor used by HiveMine's manager loop.
 * It is deliberately deterministic: decisions are based on observations, trends,
 * specialist votes and recent outcomes rather than hidden/random behaviour.
 *
 * It adds four capabilities to the base decision engine:
 *  - trend awareness (what is getting better/worse, not just current values)
 *  - confidence/uncertainty penalties for stale or contradictory observations
 *  - action hysteresis and goal cooldowns to prevent oscillation
 *  - lightweight outcome learning from successful/failed decisions
 */
public final class AdaptivePolicyBrain {
    public static final class Observation {
        public double bagFill;
        public double pollenRate;
        public double honeyRate;
        public double risk;
        public boolean bagFull;
        public boolean questComplete;
        public boolean disconnected;
        public boolean faulted;
        public boolean userWantsFarm;
        public boolean observationFresh = true;
        public long ageMs;
    }

    public static final class Decision {
        public final ManagerGoal goal;
        public final double confidence;
        public final String reason;
        public final List<String> evidence;

        Decision(ManagerGoal goal, double confidence, String reason, List<String> evidence) {
            this.goal = goal;
            this.confidence = confidence;
            this.reason = reason;
            this.evidence = evidence;
        }
    }

    private final ArrayDeque<Observation> history = new ArrayDeque<Observation>();
    private final EnumMap<ManagerGoal, Double> learnedBias = new EnumMap<ManagerGoal, Double>(ManagerGoal.class);
    private ManagerGoal lastGoal = ManagerGoal.STANDBY;
    private int sameGoalTicks;
    private long lastDecisionMs;

    public AdaptivePolicyBrain() {
        for (ManagerGoal g : ManagerGoal.values()) learnedBias.put(g, 0.0);
    }

    public synchronized Decision decide(Observation o, List<SpecialistVote> votes, long nowMs) {
        if (o == null) o = new Observation();
        remember(o);

        // Safety always wins and never gets suppressed by learning/hysteresis.
        if (o.faulted) return commit(ManagerGoal.SHUTDOWN, 1.0, "Safety fault detected", "fault", nowMs);
        if (o.disconnected) return commit(ManagerGoal.RECOVER_SESSION, 0.99, "Connection lost; recovery is safest", "disconnected", nowMs);

        EnumMap<ManagerGoal, Double> score = new EnumMap<ManagerGoal, Double>(ManagerGoal.class);
        for (ManagerGoal g : ManagerGoal.values()) score.put(g, learnedBias.get(g));
        ArrayList<String> evidence = new ArrayList<String>();

        double bagTrend = trendBagFill();
        double pollenTrend = trendPollen();
        double efficiency = clamp(o.pollenRate + 0.35 * o.honeyRate, 0, 1);

        if (o.questComplete) { add(score, ManagerGoal.TURN_IN_QUEST, 6.0); evidence.add("quest ready"); }
        if (o.bagFull || o.bagFill >= 0.92) { add(score, ManagerGoal.CONVERT_HONEY, 7.0); evidence.add("bag nearly full"); }
        else if (o.bagFill >= 0.75) add(score, ManagerGoal.CONVERT_HONEY, 2.0 + bagTrend * 2.0);

        if (o.userWantsFarm) {
            add(score, ManagerGoal.FARM_POLLEN, 3.0 + efficiency * 2.0);
            evidence.add("farming requested");
        }
        if (pollenTrend < -0.15 && o.bagFill < 0.8) {
            add(score, ManagerGoal.FARM_POLLEN, 1.5);
            evidence.add("pollen rate falling");
        }
        if (o.risk > 0.70) { add(score, ManagerGoal.STANDBY, 4.0 * o.risk); evidence.add("risk elevated"); }
        if (!o.observationFresh || o.ageMs > 3000) {
            // Uncertainty should make the AI more conservative, not cause random actions.
            add(score, ManagerGoal.STANDBY, 2.0);
            evidence.add("observation stale");
        }

        if (votes != null) {
            for (SpecialistVote v : votes) {
                if (v == null || v.goal == null) continue;
                double confidence = clamp(v.confidence, 0, 1);
                add(score, v.goal, confidence * 2.5);
                if (confidence >= 0.75) evidence.add(v.specialistId + " agrees");
            }
        }

        ManagerGoal best = ManagerGoal.STANDBY;
        double bestScore = Double.NEGATIVE_INFINITY;
        double second = Double.NEGATIVE_INFINITY;
        for (Map.Entry<ManagerGoal, Double> e : score.entrySet()) {
            double s = e.getValue();
            if (s > bestScore) { second = bestScore; bestScore = s; best = e.getKey(); }
            else if (s > second) second = s;
        }

        // Prevent rapid FARM <-> STANDBY oscillation unless the evidence is materially stronger.
        if (best != lastGoal && sameGoalTicks < 2 && !isUrgent(best)) {
            double previous = score.get(lastGoal) == null ? 0 : score.get(lastGoal);
            if (bestScore < previous + 1.5) best = lastGoal;
        }

        double confidence = clamp(0.5 + (bestScore - Math.max(0, second)) * 0.08, 0, 1);
        if (!o.observationFresh) confidence *= 0.65;
        String reason = evidence.isEmpty() ? "best available policy score" : evidence.get(0);
        return commit(best, confidence, reason, evidence.toArray(new String[evidence.size()]), nowMs);
    }

    /** Feed the result of a completed action back into the policy. */
    public synchronized void recordOutcome(ManagerGoal goal, boolean improved) {
        if (goal == null) return;
        double current = learnedBias.get(goal);
        double delta = improved ? 0.08 : -0.06;
        learnedBias.put(goal, clamp(current + delta, -1.0, 1.0));
    }

    public synchronized ManagerGoal lastGoal() { return lastGoal; }
    public synchronized int stabilityTicks() { return sameGoalTicks; }
    public synchronized double learnedBias(ManagerGoal goal) { return learnedBias.get(goal); }

    private Decision commit(ManagerGoal goal, double confidence, String reason, String evidence, long nowMs) {
        return commit(goal, confidence, reason, new String[]{evidence}, nowMs);
    }

    private Decision commit(ManagerGoal goal, double confidence, String reason, String[] evidence, long nowMs) {
        if (goal == lastGoal) sameGoalTicks++; else sameGoalTicks = 0;
        lastGoal = goal;
        lastDecisionMs = nowMs;
        ArrayList<String> list = new ArrayList<String>();
        for (String s : evidence) if (s != null && !s.isEmpty()) list.add(s);
        return new Decision(goal, confidence, reason, list);
    }

    private void remember(Observation o) {
        history.addLast(copy(o));
        while (history.size() > 12) history.removeFirst();
    }

    private double trendBagFill() {
        if (history.size() < 2) return 0;
        Observation first = history.peekFirst(), last = history.peekLast();
        return last.bagFill - first.bagFill;
    }

    private double trendPollen() {
        if (history.size() < 2) return 0;
        Observation first = history.peekFirst(), last = history.peekLast();
        return last.pollenRate - first.pollenRate;
    }

    private static Observation copy(Observation o) {
        Observation n = new Observation();
        n.bagFill = o.bagFill; n.pollenRate = o.pollenRate; n.honeyRate = o.honeyRate;
        n.risk = o.risk; n.bagFull = o.bagFull; n.questComplete = o.questComplete;
        n.disconnected = o.disconnected; n.faulted = o.faulted; n.userWantsFarm = o.userWantsFarm;
        n.observationFresh = o.observationFresh; n.ageMs = o.ageMs;
        return n;
    }

    private static boolean isUrgent(ManagerGoal g) {
        return g == ManagerGoal.SHUTDOWN || g == ManagerGoal.RECOVER_SESSION
                || g == ManagerGoal.CONVERT_HONEY || g == ManagerGoal.TURN_IN_QUEST;
    }

    private static void add(EnumMap<ManagerGoal, Double> score, ManagerGoal goal, double amount) {
        score.put(goal, score.get(goal) + amount);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
