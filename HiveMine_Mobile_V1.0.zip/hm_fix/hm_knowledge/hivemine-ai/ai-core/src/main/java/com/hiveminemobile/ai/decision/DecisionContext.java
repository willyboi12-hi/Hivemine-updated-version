package com.hiveminemobile.ai.decision;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
/** Snapshot of a decision for history. */
public final class DecisionContext {
    public final long atMs;
    public final ManagerGoal goal;
    public final String reason;
    public DecisionContext(long atMs, ManagerGoal goal, String reason) {
        this.atMs = atMs;
        this.goal = goal == null ? ManagerGoal.STANDBY : goal;
        this.reason = reason == null ? "" : reason;
    }
}
