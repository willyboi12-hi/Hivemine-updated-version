package com.hiveminemobile.ai.decision;
import com.hiveminemobile.ai.manager.ManagerDecisionCoordinator;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.manager.intel.ManagerPolicyEngine;
import com.hiveminemobile.ai.manager.intel.SpecialistVote;
import java.util.ArrayList;
import java.util.List;
/** Global decision engine facade. */
public final class DecisionEngine {
    private final ManagerDecisionCoordinator coordinator;
    private final ArrayList<String> explanations = new ArrayList<String>();
    public DecisionEngine(ManagerDecisionCoordinator coordinator) {
        this.coordinator = coordinator == null
                ? new ManagerDecisionCoordinator(null) : coordinator;
    }
    public ManagerGoal decide(ManagerPolicyEngine.WorldFlags flags, List<SpecialistVote> votes) {
        ManagerGoal g = coordinator.decide(flags, votes);
        explanations.add("chose " + g);
        while (explanations.size() > 50) explanations.remove(0);
        return g;
    }
    public List<String> explanations() { return new ArrayList<String>(explanations); }
}
