package com.hiveminemobile.ai.decision;

import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.manager.intel.SpecialistVote;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Higher-intelligence decision engine: weighted multi-factor scoring,
 * hysteresis (sticky goal), and explanation traces.
 */
public final class PowerDecisionEngine {
    public static final class Factors {
        public boolean bagFull;
        public boolean questComplete;
        public boolean disconnected;
        public boolean faulted;
        public boolean userWantsFarm;
        public double pollenRate;      // 0..1 normalized
        public double bagFill;         // 0..1
        public double risk;            // 0..1 higher = more risk
    }

    private ManagerGoal sticky = ManagerGoal.STANDBY;
    private int stickyTicks;
    private final ArrayList<String> trace = new ArrayList<String>();

    public ManagerGoal decide(Factors f, List<SpecialistVote> votes) {
        if (f == null) f = new Factors();
        EnumMap<ManagerGoal, Double> score = new EnumMap<ManagerGoal, Double>(ManagerGoal.class);
        for (ManagerGoal g : ManagerGoal.values()) score.put(g, 0.0);

        // Hard safety
        if (f.faulted) {
            sticky = ManagerGoal.SHUTDOWN;
            stickyTicks = 0;
            trace("fault -> SHUTDOWN");
            return sticky;
        }
        if (f.disconnected) {
            sticky = ManagerGoal.RECOVER_SESSION;
            stickyTicks = 3;
            trace("disconnect -> RECOVER");
            return sticky;
        }

        // Base policy weights
        if (f.questComplete) add(score, ManagerGoal.TURN_IN_QUEST, 4.0);
        if (f.bagFull || f.bagFill >= 0.92) add(score, ManagerGoal.CONVERT_HONEY, 3.5);
        if (f.userWantsFarm) add(score, ManagerGoal.FARM_POLLEN, 2.0 + f.pollenRate);
        if (f.bagFill >= 0.75 && f.bagFill < 0.92) add(score, ManagerGoal.CONVERT_HONEY, 1.2);
        if (f.risk > 0.7) add(score, ManagerGoal.STANDBY, 2.5);

        // Specialist votes
        if (votes != null) {
            for (SpecialistVote v : votes) {
                if (v == null) continue;
                double w = v.confidence;
                // Safety/Recovery specialists amplified
                if ("safety".equalsIgnoreCase(v.specialistId)) w *= 1.5;
                if ("recovery".equalsIgnoreCase(v.specialistId) || "Safety".equals(v.specialistId)) w *= 1.4;
                add(score, v.goal, w);
            }
        }

        ManagerGoal best = ManagerGoal.STANDBY;
        double bestScore = -1;
        for (Map.Entry<ManagerGoal, Double> e : score.entrySet()) {
            if (e.getValue() > bestScore) {
                bestScore = e.getValue();
                best = e.getKey();
            }
        }

        // Critical goals bypass hysteresis
        if (best == ManagerGoal.SHUTDOWN || best == ManagerGoal.RECOVER_SESSION
                || best == ManagerGoal.TURN_IN_QUEST || best == ManagerGoal.CONVERT_HONEY) {
            sticky = best;
            stickyTicks = 1;
            trace("critical choose " + best + " score=" + bestScore);
            return best;
        }

        // Hysteresis: keep sticky goal for a few ticks unless big swing
        if (stickyTicks > 0 && sticky != ManagerGoal.SHUTDOWN) {
            double stickyScore = score.get(sticky) == null ? 0 : score.get(sticky);
            if (bestScore < stickyScore + 1.25) {
                stickyTicks--;
                trace("hysteresis keep " + sticky + " ticksLeft=" + stickyTicks);
                return sticky;
            }
        }
        sticky = best;
        stickyTicks = (best == ManagerGoal.FARM_POLLEN) ? 2 : 1;
        trace("choose " + best + " score=" + bestScore);
        return best;
    }

    private static void add(EnumMap<ManagerGoal, Double> score, ManagerGoal g, double v) {
        Double cur = score.get(g);
        score.put(g, (cur == null ? 0.0 : cur) + v);
    }

    private void trace(String s) {
        trace.add(s);
        while (trace.size() > 80) trace.remove(0);
    }

    public List<String> trace() { return new ArrayList<String>(trace); }
    public ManagerGoal sticky() { return sticky; }
}
