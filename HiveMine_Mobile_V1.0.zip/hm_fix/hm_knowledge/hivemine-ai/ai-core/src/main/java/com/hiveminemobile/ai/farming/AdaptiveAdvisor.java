package com.hiveminemobile.ai.farming;

import java.util.List;
import java.util.Map;

/**
 * Phase 059. Recommends a strategy change only with evidence. Each strategy needs a minimum number of
 * verified results, and a candidate must beat the current strategy by a required margin before the
 * advisor suggests a switch. Otherwise it keeps the current strategy.
 */
public final class AdaptiveAdvisor {
    public enum Action { KEEP, SWITCH, NEEDS_EVIDENCE }

    public static final class Recommendation {
        private final Action action;
        private final String target;
        private final String reason;

        public Recommendation(Action action, String target, String reason) {
            this.action = action;
            this.target = target;
            this.reason = reason;
        }

        public Action getAction() { return action; }
        /** Strategy to switch to, or null. */
        public String getTarget() { return target; }
        public String getReason() { return reason; }
    }

    private final int minimumRuns;
    private final double requiredMargin;

    public AdaptiveAdvisor(int minimumRuns, double requiredMargin) {
        if (minimumRuns < 1) throw new IllegalArgumentException("minimumRuns must be at least 1");
        if (!(requiredMargin >= 0.0)) throw new IllegalArgumentException("requiredMargin must not be negative");
        this.minimumRuns = minimumRuns;
        this.requiredMargin = requiredMargin;
    }

    /** verifiedResults maps each strategy to its verified outcome values (higher is better). */
    public Recommendation advise(String current, Map<String, List<Double>> verifiedResults) {
        List<Double> own = verifiedResults.get(current);
        if (own == null || own.size() < minimumRuns) {
            return new Recommendation(Action.NEEDS_EVIDENCE, null, "current strategy has fewer than " + minimumRuns + " verified runs");
        }
        double currentMean = mean(own);
        String bestName = null;
        double bestMean = Double.NEGATIVE_INFINITY;
        for (Map.Entry<String, List<Double>> entry : verifiedResults.entrySet()) {
            if (entry.getKey().equals(current) || entry.getValue().size() < minimumRuns) continue;
            double candidate = mean(entry.getValue());
            if (candidate > bestMean || (candidate == bestMean && bestName != null && entry.getKey().compareTo(bestName) < 0)) {
                bestMean = candidate;
                bestName = entry.getKey();
            }
        }
        if (bestName == null) {
            return new Recommendation(Action.NEEDS_EVIDENCE, null, "no alternative strategy has enough verified runs");
        }
        if (bestMean >= currentMean * (1.0 + requiredMargin)) {
            return new Recommendation(Action.SWITCH, bestName, bestName + " averages " + bestMean + " against " + currentMean);
        }
        return new Recommendation(Action.KEEP, null, "no alternative beats " + current + " by the required margin");
    }

    private static double mean(List<Double> values) {
        double sum = 0.0;
        for (double value : values) sum += value;
        return sum / values.size();
    }
}
