package com.hiveminemobile.ai.farming;

import java.util.List;

/**
 * Phase 060. Writes the farming report as Markdown. Each section is optional: a section given as
 * null is shown as "not available", so a partial report never looks complete.
 */
public final class FarmingReport {
    public String build(String title, List<StrategyComparer.Ranked> strategies, List<FieldPerformance.Ranked> fields,
                        PollenTracker.Summary pollen, HoneyAnalysis.Summary honey,
                        FarmingSimulation.Result simulation, AdaptiveAdvisor.Recommendation advice) {
        if (title == null || title.trim().isEmpty()) throw new IllegalArgumentException("title must not be blank");
        StringBuilder out = new StringBuilder();
        out.append("# ").append(title.trim()).append("\n\n");

        out.append("## Strategies (honey per hour)\n\n");
        if (strategies == null) out.append("Not available.\n");
        else for (StrategyComparer.Ranked r : strategies) out.append(String.format("- %s: %.1f\n", r.getName(), r.getHoneyPerHour()));

        out.append("\n## Fields (pollen per minute)\n\n");
        if (fields == null) out.append("Not available.\n");
        else if (fields.isEmpty()) out.append("No field has enough sessions yet.\n");
        else for (FieldPerformance.Ranked r : fields) out.append(String.format("- %s: %.2f (%d sessions)\n", r.getField(), r.getPollenPerMinute(), r.getSessions()));

        out.append("\n## Pollen\n\n");
        if (pollen == null) out.append("Not available.\n");
        else {
            out.append(String.format("- Rate: %.2f per minute\n", pollen.getRatePerMinute()));
            out.append("- Latest reading: ").append(pollen.getLatestPercent()).append("%\n");
            out.append("- Conversions seen: ").append(pollen.getConversions()).append('\n');
            out.append("- Minutes to full: ").append(pollen.getMinutesToFull() == null ? "unknown" : String.format("%.1f", pollen.getMinutesToFull())).append('\n');
        }

        out.append("\n## Honey\n\n");
        if (honey == null) out.append("Not available.\n");
        else out.append(String.format("- Per hour: %.1f, net change: %d, decreases: %d\n", honey.getHoneyPerHour(), honey.getNetChange(), honey.getDecreases()));

        out.append("\n## Simulation\n\n");
        if (simulation == null) out.append("Not available.\n");
        else out.append(String.format("- Best: %s at %.1f units per hour, margin %.1f\n", simulation.getBestStrategy(), simulation.getBestUnitsPerHour(), simulation.getMarginOverNext()));

        out.append("\n## Recommendation\n\n");
        if (advice == null) out.append("Not available.\n");
        else out.append(advice.getAction()).append(": ").append(advice.getReason()).append('\n');
        return out.toString();
    }
}
