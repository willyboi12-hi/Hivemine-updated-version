package com.hiveminemobile.ai.farming;

import com.hiveminemobile.ai.modules.SimulationAI;
import java.util.List;

/**
 * Phase 058. Runs candidate farming strategies through SimulationAI's expected-value model across
 * scenarios, and reports the best one with its margin over the next. Nothing here runs in the game.
 */
public final class FarmingSimulation {
    public static final class Result {
        private final String bestStrategy;
        private final double bestUnitsPerHour;
        private final double marginOverNext;
        private final List<SimulationAI.Ranked> ranking;

        Result(String bestStrategy, double bestUnitsPerHour, double marginOverNext, List<SimulationAI.Ranked> ranking) {
            this.bestStrategy = bestStrategy;
            this.bestUnitsPerHour = bestUnitsPerHour;
            this.marginOverNext = marginOverNext;
            this.ranking = ranking;
        }

        public String getBestStrategy() { return bestStrategy; }
        public double getBestUnitsPerHour() { return bestUnitsPerHour; }
        /** Units per hour the best strategy leads by; zero with a single strategy. */
        public double getMarginOverNext() { return marginOverNext; }
        public List<SimulationAI.Ranked> getRanking() { return ranking; }
    }

    private final SimulationAI simulation = new SimulationAI();

    public Result run(List<SimulationAI.Strategy> strategies, List<SimulationAI.Scenario> scenarios) {
        if (strategies.isEmpty()) throw new IllegalArgumentException("at least one strategy is required");
        List<SimulationAI.Ranked> ranking = simulation.compare(strategies, scenarios);
        SimulationAI.Ranked best = ranking.get(0);
        double margin = ranking.size() > 1 ? best.getAverageUnitsPerHour() - ranking.get(1).getAverageUnitsPerHour() : 0.0;
        return new Result(best.getStrategy(), best.getAverageUnitsPerHour(), margin, ranking);
    }
}
