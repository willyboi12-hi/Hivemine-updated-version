package com.hiveminemobile.ai.farming;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Phase 052. Pollen per minute for each field, from recorded sessions. A field needs a minimum number
 * of sessions before it is ranked, so one lucky run cannot decide the ranking.
 */
public final class FieldPerformance {
    public static final class Session {
        private final String field;
        private final double minutes;
        private final double pollenGained;

        public Session(String field, double minutes, double pollenGained) {
            if (field == null || field.trim().isEmpty()) throw new IllegalArgumentException("field must not be blank");
            if (!(minutes > 0.0)) throw new IllegalArgumentException("minutes must be positive");
            if (!(pollenGained >= 0.0)) throw new IllegalArgumentException("pollen gained must not be negative");
            this.field = field;
            this.minutes = minutes;
            this.pollenGained = pollenGained;
        }
    }

    public static final class Ranked {
        private final String field;
        private final double pollenPerMinute;
        private final int sessions;

        public Ranked(String field, double pollenPerMinute, int sessions) {
            this.field = field;
            this.pollenPerMinute = pollenPerMinute;
            this.sessions = sessions;
        }

        public String getField() { return field; }
        public double getPollenPerMinute() { return pollenPerMinute; }
        public int getSessions() { return sessions; }
    }

    private final int minimumSessions;

    public FieldPerformance(int minimumSessions) {
        if (minimumSessions < 1) throw new IllegalArgumentException("minimumSessions must be at least 1");
        this.minimumSessions = minimumSessions;
    }

    public List<Ranked> rank(List<Session> sessions) {
        Map<String, double[]> totals = new LinkedHashMap<>();
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (Session session : sessions) {
            double[] total = totals.get(session.field);
            if (total == null) {
                total = new double[2];
                totals.put(session.field, total);
            }
            total[0] += session.pollenGained;
            total[1] += session.minutes;
            counts.merge(session.field, 1, Integer::sum);
        }
        List<Ranked> ranked = new ArrayList<>();
        for (Map.Entry<String, double[]> entry : totals.entrySet()) {
            int count = counts.get(entry.getKey());
            if (count < minimumSessions) continue;
            double[] total = entry.getValue();
            ranked.add(new Ranked(entry.getKey(), total[0] / total[1], count));
        }
        Collections.sort(ranked, new Comparator<Ranked>() {
            @Override public int compare(Ranked left, Ranked right) {
                int byRate = Double.compare(right.pollenPerMinute, left.pollenPerMinute);
                return byRate != 0 ? byRate : left.field.compareTo(right.field);
            }
        });
        return Collections.unmodifiableList(ranked);
    }
}
