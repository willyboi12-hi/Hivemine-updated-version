package com.hiveminemobile.ai.farming;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 054. Honey gained per hour from timed honey readings. Honey can also be spent, so the summary
 * reports the net change and how many readings went down.
 */
public final class HoneyAnalysis {
    public static final class Point {
        private final long atMillis;
        private final long honey;

        public Point(long atMillis, long honey) {
            if (honey < 0L) throw new IllegalArgumentException("honey must not be negative");
            this.atMillis = atMillis;
            this.honey = honey;
        }
    }

    public static final class Summary {
        private final double honeyPerHour;
        private final long netChange;
        private final int decreases;

        Summary(double honeyPerHour, long netChange, int decreases) {
            this.honeyPerHour = honeyPerHour;
            this.netChange = netChange;
            this.decreases = decreases;
        }

        public double getHoneyPerHour() { return honeyPerHour; }
        public long getNetChange() { return netChange; }
        public int getDecreases() { return decreases; }
    }

    public Summary summarize(List<Point> points) {
        if (points.size() < 2) throw new IllegalArgumentException("at least two readings are needed");
        List<Point> ordered = new ArrayList<>(points);
        Collections.sort(ordered, new Comparator<Point>() {
            @Override public int compare(Point left, Point right) {
                return Long.compare(left.atMillis, right.atMillis);
            }
        });
        int decreases = 0;
        for (int i = 1; i < ordered.size(); i++) {
            if (ordered.get(i).honey < ordered.get(i - 1).honey) decreases++;
        }
        long span = ordered.get(ordered.size() - 1).atMillis - ordered.get(0).atMillis;
        if (span <= 0L) throw new IllegalArgumentException("readings must span a positive time");
        long net = ordered.get(ordered.size() - 1).honey - ordered.get(0).honey;
        return new Summary(net / (span / 3_600_000.0), net, decreases);
    }
}
