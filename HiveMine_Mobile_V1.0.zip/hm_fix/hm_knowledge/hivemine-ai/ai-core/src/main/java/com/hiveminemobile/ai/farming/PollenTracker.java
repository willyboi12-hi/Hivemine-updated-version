package com.hiveminemobile.ai.farming;

import com.hiveminemobile.ai.modules.FarmingAI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 053. Tracks pollen over time using FarmingAI's analysis, then estimates how long the bag needs
 * to reach full from the latest reading at the observed rate.
 */
public final class PollenTracker {
    public static final class Summary {
        private final double ratePerMinute;
        private final int conversions;
        private final long fullMillis;
        private final int latestPercent;
        private final Double minutesToFull;

        Summary(double ratePerMinute, int conversions, long fullMillis, int latestPercent, Double minutesToFull) {
            this.ratePerMinute = ratePerMinute;
            this.conversions = conversions;
            this.fullMillis = fullMillis;
            this.latestPercent = latestPercent;
            this.minutesToFull = minutesToFull;
        }

        public double getRatePerMinute() { return ratePerMinute; }
        public int getConversions() { return conversions; }
        public long getFullMillis() { return fullMillis; }
        public int getLatestPercent() { return latestPercent; }
        /** Null when the rate is zero or there are no readings. */
        public Double getMinutesToFull() { return minutesToFull; }
    }

    public Summary summarize(List<FarmingAI.Sample> samples) {
        if (samples == null || samples.isEmpty()) throw new IllegalArgumentException("no pollen readings");
        List<FarmingAI.Sample> ordered = new ArrayList<>(samples);
        Collections.sort(ordered, new Comparator<FarmingAI.Sample>() {
            @Override public int compare(FarmingAI.Sample left, FarmingAI.Sample right) {
                return Long.compare(left.getAtMillis(), right.getAtMillis());
            }
        });
        FarmingAI.Report report = new FarmingAI().analyze(ordered);
        int latest = ordered.get(ordered.size() - 1).getPollenPercent();
        Double minutes = report.getPollenPerMinute() > 0.0 ? (100 - latest) / report.getPollenPerMinute() : null;
        return new Summary(report.getPollenPerMinute(), report.getConversions(), report.getFullMillis(), latest, minutes);
    }
}
