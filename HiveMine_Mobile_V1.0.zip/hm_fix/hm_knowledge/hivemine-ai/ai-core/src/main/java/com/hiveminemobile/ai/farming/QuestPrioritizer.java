package com.hiveminemobile.ai.farming;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 057. Ranks quest objectives. The score is reward per remaining unit, so quick payoffs rank
 * first, and an objective with a deadline inside 30 minutes is doubled. This is a stated heuristic, not
 * a measured optimum.
 */
public final class QuestPrioritizer {
    private static final int URGENT_MINUTES = 30;

    public static final class Objective {
        private final String name;
        private final int remainingUnits;
        private final double rewardPerUnit;
        private final Integer deadlineMinutes;

        public Objective(String name, int remainingUnits, double rewardPerUnit, Integer deadlineMinutes) {
            if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("name must not be blank");
            if (remainingUnits < 1) throw new IllegalArgumentException("remaining units must be at least 1");
            if (!(rewardPerUnit >= 0.0)) throw new IllegalArgumentException("reward must not be negative");
            this.name = name;
            this.remainingUnits = remainingUnits;
            this.rewardPerUnit = rewardPerUnit;
            this.deadlineMinutes = deadlineMinutes;
        }
    }

    public static final class Ranked {
        private final String name;
        private final double score;

        Ranked(String name, double score) {
            this.name = name;
            this.score = score;
        }

        public String getName() { return name; }
        public double getScore() { return score; }
    }

    public List<Ranked> rank(List<Objective> objectives) {
        List<Ranked> ranked = new ArrayList<>();
        for (Objective objective : objectives) {
            double score = objective.rewardPerUnit / objective.remainingUnits;
            if (objective.deadlineMinutes != null && objective.deadlineMinutes <= URGENT_MINUTES) score *= 2.0;
            ranked.add(new Ranked(objective.name, score));
        }
        Collections.sort(ranked, new Comparator<Ranked>() {
            @Override public int compare(Ranked left, Ranked right) {
                int byScore = Double.compare(right.score, left.score);
                return byScore != 0 ? byScore : left.name.compareTo(right.name);
            }
        });
        return Collections.unmodifiableList(ranked);
    }
}
