package com.hiveminemobile.ai.farming;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.List;

/** Phase 056. Totals the items a planned set of runs needs and reports what is short against inventory. */
public final class ResourcePlanner {
    public static final class PlannedRun {
        private final String name;
        private final Map<String, Integer> costPerRun;
        private final int runs;

        public PlannedRun(String name, Map<String, Integer> costPerRun, int runs) {
            if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("name must not be blank");
            if (runs < 1) throw new IllegalArgumentException("runs must be at least 1");
            for (Map.Entry<String, Integer> entry : costPerRun.entrySet()) {
                if (entry.getValue() == null || entry.getValue() < 0) throw new IllegalArgumentException("cost must not be negative");
            }
            this.name = name;
            this.costPerRun = new TreeMap<>(costPerRun);
            this.runs = runs;
        }
    }

    public static final class Shortfall {
        private final String item;
        private final int needed;
        private final int have;

        Shortfall(String item, int needed, int have) {
            this.item = item;
            this.needed = needed;
            this.have = have;
        }

        public String getItem() { return item; }
        public int getNeeded() { return needed; }
        public int getHave() { return have; }
        public int getShort() { return needed - have; }
    }

    /** Items the plan needs beyond the inventory, sorted by name. Empty when the inventory covers the plan. */
    public List<Shortfall> plan(List<PlannedRun> runs, Map<String, Integer> inventory) {
        Map<String, Integer> needed = new TreeMap<>();
        for (PlannedRun run : runs) {
            for (Map.Entry<String, Integer> cost : run.costPerRun.entrySet()) {
                needed.merge(cost.getKey(), cost.getValue() * run.runs, Integer::sum);
            }
        }
        List<Shortfall> shortfalls = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : needed.entrySet()) {
            int have = inventory.getOrDefault(entry.getKey(), 0);
            if (have < entry.getValue()) shortfalls.add(new Shortfall(entry.getKey(), entry.getValue(), have));
        }
        return Collections.unmodifiableList(shortfalls);
    }
}
