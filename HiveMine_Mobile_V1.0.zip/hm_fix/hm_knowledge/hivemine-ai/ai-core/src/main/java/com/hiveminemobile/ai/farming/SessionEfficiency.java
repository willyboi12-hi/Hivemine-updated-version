package com.hiveminemobile.ai.farming;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 055. Compares sessions by honey per active minute. Idle time (for example waiting on a
 * disconnect) is excluded from the denominator and reported as a share of the session.
 */
public final class SessionEfficiency {
    public static final class Session {
        private final String name;
        private final double minutes;
        private final double honeyGained;
        private final double idleMinutes;

        public Session(String name, double minutes, double honeyGained, double idleMinutes) {
            if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("name must not be blank");
            if (!(minutes > 0.0)) throw new IllegalArgumentException("minutes must be positive");
            if (!(honeyGained >= 0.0)) throw new IllegalArgumentException("honey must not be negative");
            if (!(idleMinutes >= 0.0 && idleMinutes <= minutes)) throw new IllegalArgumentException("idle must be within the session");
            this.name = name;
            this.minutes = minutes;
            this.honeyGained = honeyGained;
            this.idleMinutes = idleMinutes;
        }
    }

    public static final class Ranked {
        private final String name;
        private final double honeyPerActiveMinute;
        private final double idleShare;

        Ranked(String name, double honeyPerActiveMinute, double idleShare) {
            this.name = name;
            this.honeyPerActiveMinute = honeyPerActiveMinute;
            this.idleShare = idleShare;
        }

        public String getName() { return name; }
        public double getHoneyPerActiveMinute() { return honeyPerActiveMinute; }
        public double getIdleShare() { return idleShare; }
    }

    public List<Ranked> rank(List<Session> sessions) {
        List<Ranked> ranked = new ArrayList<>();
        for (Session session : sessions) {
            double active = session.minutes - session.idleMinutes;
            double rate = active > 0.0 ? session.honeyGained / active : 0.0;
            ranked.add(new Ranked(session.name, rate, session.idleMinutes / session.minutes));
        }
        Collections.sort(ranked, new Comparator<Ranked>() {
            @Override public int compare(Ranked left, Ranked right) {
                int byRate = Double.compare(right.honeyPerActiveMinute, left.honeyPerActiveMinute);
                return byRate != 0 ? byRate : left.name.compareTo(right.name);
            }
        });
        return Collections.unmodifiableList(ranked);
    }
}
