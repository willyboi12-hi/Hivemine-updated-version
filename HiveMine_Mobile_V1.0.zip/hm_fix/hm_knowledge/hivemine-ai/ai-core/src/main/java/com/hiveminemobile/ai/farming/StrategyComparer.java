package com.hiveminemobile.ai.farming;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Phase 051. Ranks farming approaches by expected honey per hour: pollen rate times honey per pollen. */
public final class StrategyComparer {
    public static final class Option {
        private final String name;
        private final double pollenPerMinute;
        private final double honeyPerPollen;

        public Option(String name, double pollenPerMinute, double honeyPerPollen) {
            if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("name must not be blank");
            if (!(pollenPerMinute >= 0.0)) throw new IllegalArgumentException("pollen rate must not be negative");
            if (!(honeyPerPollen >= 0.0)) throw new IllegalArgumentException("honey per pollen must not be negative");
            this.name = name;
            this.pollenPerMinute = pollenPerMinute;
            this.honeyPerPollen = honeyPerPollen;
        }
    }

    public static final class Ranked {
        private final String name;
        private final double honeyPerHour;

        public Ranked(String name, double honeyPerHour) {
            this.name = name;
            this.honeyPerHour = honeyPerHour;
        }

        public String getName() { return name; }
        public double getHoneyPerHour() { return honeyPerHour; }
    }

    public List<Ranked> rank(List<Option> options) {
        List<Ranked> ranked = new ArrayList<>();
        for (Option option : options) {
            ranked.add(new Ranked(option.name, option.pollenPerMinute * 60.0 * option.honeyPerPollen));
        }
        Collections.sort(ranked, new Comparator<Ranked>() {
            @Override public int compare(Ranked left, Ranked right) {
                int byValue = Double.compare(right.honeyPerHour, left.honeyPerHour);
                return byValue != 0 ? byValue : left.name.compareTo(right.name);
            }
        });
        return Collections.unmodifiableList(ranked);
    }
}
