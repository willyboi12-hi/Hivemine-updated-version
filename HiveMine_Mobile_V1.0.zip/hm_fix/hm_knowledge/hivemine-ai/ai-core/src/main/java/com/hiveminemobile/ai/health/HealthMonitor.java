package com.hiveminemobile.ai.health;

import com.hiveminemobile.ai.AIErrorHandler;
import com.hiveminemobile.ai.Identifiers;
import com.hiveminemobile.ai.manager.ManagerHealth;
import com.hiveminemobile.ai.specialist.SpecialistRegistry;
import com.hiveminemobile.ai.specialist.SpecialistStatus;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Read-only health evaluation. It reads the manager status, the specialist catalog, heartbeats and
 * the error journal, then reports a level for each component. It never changes module status, so a
 * recovered specialist is judged afresh on every check.
 *
 * Heartbeats are optional: a component is judged on missed heartbeats only after it has sent one.
 */
public final class HealthMonitor {
    public enum Level { HEALTHY, DEGRADED, UNAVAILABLE }

    public static final class ComponentHealth {
        private final String componentId;
        private final Level level;
        private final long lastHeartbeatMillis;
        private final int errorCount;
        private final String detail;

        ComponentHealth(String componentId, Level level, long lastHeartbeatMillis, int errorCount, String detail) {
            this.componentId = componentId;
            this.level = level;
            this.lastHeartbeatMillis = lastHeartbeatMillis;
            this.errorCount = errorCount;
            this.detail = detail;
        }

        public String getComponentId() { return componentId; }
        public Level getLevel() { return level; }
        /** Time of the last heartbeat, or -1 when none has been received. */
        public long getLastHeartbeatMillis() { return lastHeartbeatMillis; }
        public int getErrorCount() { return errorCount; }
        public String getDetail() { return detail; }
    }

    public static final class Report {
        private final Level overall;
        private final List<ComponentHealth> components;
        private final long checkedAtMillis;

        Report(Level overall, List<ComponentHealth> components, long checkedAtMillis) {
            this.overall = overall;
            this.components = components;
            this.checkedAtMillis = checkedAtMillis;
        }

        /** Worst level across the manager and every specialist. */
        public Level getOverall() { return overall; }
        public List<ComponentHealth> getComponents() { return components; }
        public long getCheckedAtMillis() { return checkedAtMillis; }

        public ComponentHealth getComponent(String componentId) {
            for (ComponentHealth component : components) {
                if (component.getComponentId().equals(componentId)) return component;
            }
            return null;
        }
    }

    private final long heartbeatTimeoutMillis;
    private final int errorThreshold;
    private final Map<String, Long> heartbeats = new HashMap<>();

    public HealthMonitor(long heartbeatTimeoutMillis, int errorThreshold) {
        if (heartbeatTimeoutMillis < 1L) throw new IllegalArgumentException("heartbeatTimeoutMillis must be positive");
        if (errorThreshold < 1) throw new IllegalArgumentException("errorThreshold must be at least 1");
        this.heartbeatTimeoutMillis = heartbeatTimeoutMillis;
        this.errorThreshold = errorThreshold;
    }

    public synchronized void heartbeat(String componentId, long nowMillis) {
        if (!Identifiers.isValid(componentId)) throw new IllegalArgumentException("componentId is invalid");
        heartbeats.put(componentId, nowMillis);
    }

    public synchronized void forget(String componentId) {
        heartbeats.remove(componentId);
    }

    public synchronized Report evaluate(ManagerHealth.Status managerStatus, SpecialistRegistry registry,
                                        AIErrorHandler errors, long nowMillis) {
        Level overall = fromManager(managerStatus);
        List<AIErrorHandler.AIError> history = errors.getHistory();
        List<ComponentHealth> components = new ArrayList<>();
        for (String id : registry.getRegisteredIds()) {
            ComponentHealth health = assess(id, registry.getStatus(id), history, nowMillis);
            components.add(health);
            if (health.getLevel().ordinal() > overall.ordinal()) overall = health.getLevel();
        }
        return new Report(overall, Collections.unmodifiableList(components), nowMillis);
    }

    private ComponentHealth assess(String id, SpecialistStatus status,
                                   List<AIErrorHandler.AIError> history, long nowMillis) {
        Long last = heartbeats.get(id);
        long lastBeat = last == null ? -1L : last;
        int errorCount = 0;
        for (AIErrorHandler.AIError error : history) {
            if (id.equals(error.getComponentId())) errorCount++;
        }
        Level level = Level.HEALTHY;
        String detail = "Normal";
        if (status == SpecialistStatus.FAILED || status == SpecialistStatus.UNAVAILABLE) {
            level = Level.UNAVAILABLE;
            detail = "Registry reports " + status;
        } else if (last != null && nowMillis - last > 3 * heartbeatTimeoutMillis) {
            level = Level.UNAVAILABLE;
            detail = "No heartbeat for " + (nowMillis - last) + " ms";
        } else if (status == SpecialistStatus.DEGRADED) {
            level = Level.DEGRADED;
            detail = "Registry reports DEGRADED";
        } else if (last != null && nowMillis - last > heartbeatTimeoutMillis) {
            level = Level.DEGRADED;
            detail = "Heartbeat is late by " + (nowMillis - last - heartbeatTimeoutMillis) + " ms";
        } else if (errorCount >= errorThreshold) {
            level = Level.DEGRADED;
            detail = errorCount + " errors recorded";
        }
        return new ComponentHealth(id, level, lastBeat, errorCount, detail);
    }

    private static Level fromManager(ManagerHealth.Status status) {
        if (status == ManagerHealth.Status.HEALTHY) return Level.HEALTHY;
        if (status == ManagerHealth.Status.DEGRADED) return Level.DEGRADED;
        return Level.UNAVAILABLE;
    }
}
