package com.hiveminemobile.ai.integration;
/** Phase 097 — Pass/fail health for integration surface. */
public final class IntegrationHealthCheck {
    public static final class Result {
        public final boolean ok;
        public final String detail;
        public Result(boolean ok, String detail) {
            this.ok = ok;
            this.detail = detail == null ? "" : detail;
        }
    }
    public Result check(IntegrationManifest manifest, LifecycleIntegrator life) {
        if (manifest == null || life == null) return new Result(false, "null deps");
        if (!manifest.has("automation")) return new Result(false, "missing automation");
        if (!manifest.has("manager-intel")) return new Result(false, "missing manager-intel");
        if (life.phase() == LifecycleIntegrator.Phase.COLD) return new Result(false, "still cold");
        return new Result(true, "ok");
    }
}
