package com.hiveminemobile.ai.learning;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Names the specialist systems Learning AI is connected to, and routes a recommendation to them as data.
 * It never calls those systems or changes their settings.
 */
public final class LearningIntegrationBridge {
    public static final String ANALYTICS = "analytics";
    private static final List<String> TARGETS = Collections.unmodifiableList(
        Arrays.asList("farming", "quest", "configuration", ANALYTICS));

    public List<String> connectedSystems() { return TARGETS; }

    /** Systems that should see this recommendation: analytics always, plus any target named in its capability. */
    public List<String> routeFor(Recommendation r) {
        List<String> out = new ArrayList<>();
        out.add(ANALYTICS);
        String cap = r.getCapability().toLowerCase(Locale.ROOT);
        for (String t : TARGETS) {
            if (!t.equals(ANALYTICS) && cap.contains(t) && !out.contains(t)) out.add(t);
        }
        return out;
    }
}
