package com.hiveminemobile.ai.learning;

/** A proposed configuration improvement. It is only a proposal until the user accepts it elsewhere. */
public final class Recommendation {
    public enum Status { PROPOSED, REJECTED, OUTCOME_RECORDED }

    private final String id;
    private final String capability;
    private final String advice;
    private final int evidence;
    private final double successRate;
    private Status status = Status.PROPOSED;

    Recommendation(String id, String capability, String advice, int evidence, double successRate) {
        this.id = id;
        this.capability = capability;
        this.advice = advice;
        this.evidence = evidence;
        this.successRate = successRate;
    }

    public String getId() { return id; }
    public String getCapability() { return capability; }
    public String getAdvice() { return advice; }
    public int getEvidence() { return evidence; }
    public double getSuccessRate() { return successRate; }
    public Status getStatus() { return status; }

    void setStatus(Status s) { status = s; }
}
