package com.hiveminemobile.ai.loot;

import com.hiveminemobile.ai.bss.BssFields;
import com.hiveminemobile.ai.bss.BssMacroSettings;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Loot / material / blender-recipe farming manager.
 * Configures HiveMine Mobile for ingredient fields. Does not run the in-game Blender.
 */
public final class LootManager {
    private final MaterialKnowledge knowledge = new MaterialKnowledge();
    private CraftMaterial activeGoal = CraftMaterial.UNKNOWN;
    private MaterialKnowledge.SourcePlan activePlan;
    private BlenderCatalog.Recipe activeRecipe;
    private int craftQty = 1;
    private final LinkedHashMap<String, Integer> goals = new LinkedHashMap<String, Integer>();
    private final ArrayList<String> history = new ArrayList<String>();

    public CraftMaterial activeGoal() { return activeGoal; }
    public MaterialKnowledge.SourcePlan activePlan() { return activePlan; }
    public BlenderCatalog.Recipe activeRecipe() { return activeRecipe; }
    public int craftQty() { return craftQty; }
    public Map<String, Integer> goals() { return new LinkedHashMap<String, Integer>(goals); }
    public List<String> history() { return new ArrayList<String>(history); }

    public List<String> recipeNames() { return BlenderCatalog.displayNames(); }

    public void setGoal(String materialName, int targetAmount) {
        // Prefer exact blender recipe
        BlenderCatalog.Recipe recipe = BlenderCatalog.get(materialName);
        if (recipe != null) {
            selectRecipe(recipe.displayName, Math.max(1, targetAmount <= 0 ? 1 : targetAmount));
            return;
        }
        CraftMaterial mat = knowledge.parseMaterial(materialName);
        activeGoal = mat;
        activePlan = knowledge.planFor(mat);
        activeRecipe = null;
        if (targetAmount < 0) targetAmount = 0;
        goals.put(mat.name(), targetAmount);
        history.add("Goal set: " + mat + " target=" + targetAmount + " field=" + activePlan.primaryField);
        trimHist();
    }

    public void selectRecipe(String recipeName, int qty) {
        BlenderCatalog.Recipe r = BlenderCatalog.get(recipeName);
        if (r == null) {
            history.add("Unknown recipe: " + recipeName);
            return;
        }
        craftQty = Math.max(1, qty);
        activeRecipe = r;
        activeGoal = knowledge.parseMaterial(r.displayName);
        // Build plan from recipe farm field
        ArrayList<String> notes = new ArrayList<String>();
        notes.add("Blender recipe: " + r.displayName + " x" + craftQty);
        for (BlenderCatalog.Ingredient i : r.ingredients) {
            notes.add("Need " + (i.amount * craftQty) + "x " + i.name);
        }
        notes.add(r.tip);
        notes.add("Macro farms the field; you craft at the Blender in-game.");
        String field = BssFields.isKnown(r.farmField) ? r.farmField : "Pine Tree";
        List<String> alts = new ArrayList<String>();
        for (String a : r.altFields) if (BssFields.isKnown(a)) alts.add(a);
        activePlan = new MaterialKnowledge.SourcePlan(
                activeGoal == CraftMaterial.UNKNOWN ? CraftMaterial.TOKENS_GENERIC : activeGoal,
                field, alts, "Farm ingredients for " + r.displayName, true, false, notes);
        goals.put(r.displayName, craftQty);
        history.add("Recipe " + r.displayName + " x" + craftQty + " -> farm " + field);
        trimHist();
    }

    public MaterialKnowledge.SourcePlan recommend(String materialName) {
        BlenderCatalog.Recipe r = BlenderCatalog.get(materialName);
        if (r != null) {
            selectRecipe(r.displayName, 1);
            return activePlan;
        }
        return knowledge.planFor(knowledge.parseMaterial(materialName));
    }

    public void applyTo(BssMacroSettings settings) {
        if (settings == null || activePlan == null) return;
        Map<String, String> m = knowledge.toMacroSettings(activePlan);
        // Recipe-specific field always wins
        if (activeRecipe != null && BssFields.isKnown(activeRecipe.farmField)) {
            m.put("field", activeRecipe.farmField);
        }
        for (Map.Entry<String, String> e : m.entrySet()) {
            if (settings.supports(e.getKey())) settings.set(e.getKey(), e.getValue());
        }
        history.add("Applied farm plan field=" + settings.get("field"));
        trimHist();
    }

    public String statusReport() {
        StringBuilder sb = new StringBuilder();
        if (activeRecipe != null) {
            sb.append("Recipe: ").append(activeRecipe.displayName).append(" x").append(craftQty).append('\n');
            sb.append("Ingredients:\n");
            Map<String, Integer> scaled = BlenderCatalog.scaleIngredients(activeRecipe, craftQty);
            for (Map.Entry<String, Integer> e : scaled.entrySet()) {
                sb.append("  - ").append(e.getValue()).append("x ").append(e.getKey()).append('\n');
            }
            sb.append("Tip: ").append(activeRecipe.tip).append('\n');
        }
        sb.append("Active goal: ").append(activeGoal).append('\n');
        if (activePlan != null) {
            sb.append("Primary field: ").append(activePlan.primaryField).append('\n');
            sb.append("Strategy: ").append(activePlan.strategy).append('\n');
            if (!activePlan.altFields.isEmpty()) sb.append("Alt fields: ").append(activePlan.altFields).append('\n');
            for (String n : activePlan.notes) sb.append("Note: ").append(n).append('\n');
        }
        sb.append("Tracked: ").append(goals).append('\n');
        sb.append("Limit: farms ingredients only — craft at Blender yourself.\n");
        return sb.toString();
    }

    private void trimHist() {
        while (history.size() > 100) history.remove(0);
    }
}
