package com.hiveminemobile.ai.loot;

import com.hiveminemobile.ai.bss.BssFields;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * BSS-oriented material sources. Recommendations only use real macro fields from FieldRoutes.
 * Does not invent shop purchase automation.
 */
public final class MaterialKnowledge {

    public static final class SourcePlan {
        public final CraftMaterial material;
        public final String primaryField;
        public final List<String> altFields;
        public final String strategy;
        public final boolean needsTokenFocus;
        public final boolean needsQuestFocus;
        public final List<String> notes;

        public SourcePlan(CraftMaterial material, String primaryField, List<String> altFields,
                          String strategy, boolean needsTokenFocus, boolean needsQuestFocus,
                          List<String> notes) {
            this.material = material;
            this.primaryField = primaryField;
            this.altFields = altFields;
            this.strategy = strategy;
            this.needsTokenFocus = needsTokenFocus;
            this.needsQuestFocus = needsQuestFocus;
            this.notes = notes;
        }
    }

    public CraftMaterial parseMaterial(String text) {
        if (text == null) return CraftMaterial.UNKNOWN;
        String t = text.toLowerCase(Locale.US);
        if (t.contains("glue")) return CraftMaterial.GLUE;
        if (t.contains("gumm")) return CraftMaterial.GUMDROPS;
        if (t.contains("ticket")) return CraftMaterial.TICKETS;
        if (t.contains("treat")) return CraftMaterial.TREATS;
        if (t.contains("sunflower seed") || t.contains("seeds")) return CraftMaterial.SUNFLOWER_SEED;
        if (t.contains("strawberr")) return CraftMaterial.STRAWBERRY;
        if (t.contains("pineapple")) return CraftMaterial.PINEAPPLE;
        if (t.contains("blueberr")) return CraftMaterial.BLUEBERRY;
        if (t.contains("coconut")) return CraftMaterial.COCONUT;
        if (t.contains("enzyme")) return CraftMaterial.ENZYMES;
        if (t.contains("oil")) return CraftMaterial.OIL;
        if (t.contains("extract")) return CraftMaterial.EXTRACTS;
        if (t.contains("glitter")) return CraftMaterial.GLITTER;
        if (t.contains("soft wax")) return CraftMaterial.SOFT_WAX;
        if (t.contains("hard wax")) return CraftMaterial.HARD_WAX;
        if (t.contains("token")) return CraftMaterial.TOKENS_GENERIC;
        if (t.contains("honey")) return CraftMaterial.HONEY;
        return CraftMaterial.UNKNOWN;
    }

    public SourcePlan planFor(CraftMaterial mat) {
        List<String> notes = new ArrayList<String>();
        switch (mat) {
            case GLUE:
                notes.add("Glue is crafted from 50 Gumdrops + 10 Royal Jelly; it is not a normal field-pollen reward.");
                notes.add("Direct field-related Glue drops are rare. Dandelion, Pumpkin and Stump can rarely replace a honey token with Glue; Pineapple, Spider and Pumpkin can also have rare pollen/leaf drops.");
                notes.add("Macro should not claim that one field guarantees Glue or that farming Spider alone is the optimal route.");
                return new SourcePlan(mat, "Stump", list("Dandelion", "Pumpkin", "Spider"),
                        "Use observed direct-drop opportunities; otherwise pursue Gumdrops/Royal Jelly through their actual sources", true, true, notes);
            case GUMDROPS:
            case GUMMY_BEE_EGG_RELATED:
                notes.add("Gumdrops have many sources: mobs, planters, Puffshrooms, sprouts, meteors and special rewards.");
                notes.add("There is no universal Gumdrop field. Choose a field only when it also satisfies another objective or an observed source.");
                return new SourcePlan(mat, "Spider", list("Stump", "Dandelion", "Pumpkin"),
                        "Do not field-lock; combine combat/planter/sprout sources with current quest goals", true, true, notes);
            case SUNFLOWER_SEED:
                return new SourcePlan(mat, "Sunflower", list("Dandelion", "Mushroom"),
                        "Farm Sunflower for seeds/tokens", true, false, notes);
            case STRAWBERRY:
                return new SourcePlan(mat, "Strawberry", list("Pepper", "Rose"),
                        "Farm Strawberry field", true, false, notes);
            case PINEAPPLE:
                return new SourcePlan(mat, "Pineapple", list("Pumpkin", "Pine Tree"),
                        "Farm Pineapple field", true, false, notes);
            case BLUEBERRY:
                return new SourcePlan(mat, "Blue Flower", list("Pine Tree", "Stump"),
                        "Farm Blue Flower", true, false, notes);
            case COCONUT:
                notes.add("Coconut field is jump-heavy on some routes; expect more drift.");
                return new SourcePlan(mat, "Coconut", list("Pepper", "Mountain Top"),
                        "Farm Coconut with caution", true, false, notes);
            case ENZYMES:
            case OIL:
            case EXTRACTS:
            case GLITTER:
            case SOFT_WAX:
            case HARD_WAX:
                notes.add("This material is not safely modeled as a single-field drop. Some are crafted and others have activity/mob/quest sources.");
                notes.add("Use the material-specific inventory/quest telemetry when available; otherwise optimize honey and compatible quest objectives instead of claiming a guaranteed field source.");
                return new SourcePlan(mat, "Pine Tree", list("Spider", "Pepper", "Mountain Top"),
                        "Generic efficiency route only when no verified direct source is visible", true, true, notes);
            case TICKETS:
            case TREATS:
                notes.add("Tickets and Treats are not equivalent to field pollen. Their sources include quests, mobs, dispensers, memory matches and other activities depending on the item.");
                return new SourcePlan(mat, "Clover", list("Sunflower", "Dandelion", "Mushroom"),
                        "Quest-smart + beginner-friendly fields", false, true, notes);
            case TOKENS_GENERIC:
                notes.add("Stay in dense token fields; human-like path helps pass over token spawns.");
                return new SourcePlan(mat, "Spider", list("Pepper", "Pine Tree", "Mountain Top"),
                        "Token-focused field farming", true, false, notes);
            case HONEY:
                return new SourcePlan(mat, "Pine Tree", list("Spider", "Pepper", "Bamboo"),
                        "Max pollen then convert at hive", false, false, notes);
            default:
                notes.add("Material not recognized. Pick a field manually.");
                return new SourcePlan(mat, "Pine Tree", list("Sunflower", "Clover"),
                        "Default farm", false, false, notes);
        }
    }

    private static List<String> list(String... fields) {
        ArrayList<String> out = new ArrayList<String>();
        for (String f : fields) if (BssFields.isKnown(f)) out.add(f);
        return Collections.unmodifiableList(out);
    }

    public Map<String, String> toMacroSettings(SourcePlan plan) {
        LinkedHashMap<String, String> m = new LinkedHashMap<String, String>();
        if (plan == null) return m;
        m.put("field", plan.primaryField);
        m.put("walkFirst", "true");
        m.put("returnToField", "true");
        m.put("fullAction", "2");
        m.put("fullPercent", plan.needsTokenFocus ? "95" : "90");
        m.put("questSmart", plan.needsQuestFocus ? "true" : "false");
        m.put("humanMode", "true");
        // denser gather helps token pickup
        m.put("pattern", plan.needsTokenFocus ? "Snake" : "Snake");
        m.put("size", plan.needsTokenFocus ? "L" : "M");
        return m;
    }
}
