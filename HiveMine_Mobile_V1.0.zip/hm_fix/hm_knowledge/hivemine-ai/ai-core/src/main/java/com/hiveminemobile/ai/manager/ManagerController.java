package com.hiveminemobile.ai.manager;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIEngine;
import com.hiveminemobile.ai.AIErrorHandler;
import com.hiveminemobile.ai.AIException;
import com.hiveminemobile.ai.AIInterface;
import com.hiveminemobile.ai.AIRegistry;
import com.hiveminemobile.ai.specialist.RegistrationResult;
import com.hiveminemobile.ai.specialist.SpecialistMetadata;
import com.hiveminemobile.ai.specialist.SpecialistRegistry;
import com.hiveminemobile.ai.specialist.SpecialistStatus;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * HiveMineManagerAI lifecycle supervisor. Phase 002 coordinates module startup and health only;
 * it intentionally has no game-input, task-execution, or permission-bypass API.
 */
public final class ManagerController {
    private final AIConfiguration configuration;
    private final AIRegistry registry = new AIRegistry();
    private final SpecialistRegistry specialistRegistry = new SpecialistRegistry();
    private final AIErrorHandler errors;
    private final Map<String, Set<String>> dependencies = new LinkedHashMap<>();
    private AIEngine engine;
    private ManagerRuntime runtime;

    public ManagerController(AIConfiguration configuration) {
        this(configuration, new AIErrorHandler());
    }

    public ManagerController(AIConfiguration configuration, AIErrorHandler errors) {
        if (configuration == null) throw new IllegalArgumentException("configuration must not be null");
        if (errors == null) throw new IllegalArgumentException("errors must not be null");
        this.configuration = configuration;
        this.errors = errors;
        long now = System.currentTimeMillis();
        this.runtime = snapshot(ManagerRuntime.State.NEW, now, "Manager created", 0);
    }

    public synchronized void registerSpecialist(AIInterface specialist) {
        registerSpecialist(specialist, Collections.<String>emptySet());
    }

    public synchronized void registerSpecialist(AIInterface specialist, Set<String> requiredDependencies) {
        requireRegistrationWindow();
        if (specialist == null) throw new IllegalArgumentException("specialist must not be null");
        Set<String> copy = new LinkedHashSet<>();
        if (requiredDependencies != null) {
            for (String dependency : requiredDependencies) {
                if (dependency == null || dependency.trim().isEmpty()) {
                    throw new IllegalArgumentException("dependency IDs must not be blank");
                }
                copy.add(dependency.trim());
            }
        }
        SpecialistMetadata metadata = SpecialistMetadata.from(specialist, copy);
        RegistrationResult registration = specialistRegistry.register(specialist, metadata);
        if (!registration.isAccepted()) {
            throw new IllegalArgumentException("Specialist registration rejected: " + registration.getMessage());
        }
        try {
            registry.register(specialist);
        } catch (RuntimeException failure) {
            specialistRegistry.unregister(specialist.getId());
            throw failure;
        }
        dependencies.put(specialist.getId(), Collections.unmodifiableSet(copy));
        runtime = snapshot(ManagerRuntime.State.NEW, System.currentTimeMillis(),
            "Specialist registered: " + specialist.getId(), 0);
    }

    public synchronized void start() throws AIException {
        if (runtime.getState() != ManagerRuntime.State.NEW
                && runtime.getState() != ManagerRuntime.State.STOPPED
                && runtime.getState() != ManagerRuntime.State.FAILED) {
            throw new IllegalStateException("Manager cannot start from " + runtime.getState());
        }
        long now = System.currentTimeMillis();
        runtime = snapshot(ManagerRuntime.State.INITIALIZING, now, "Validating specialists and dependencies", 0);
        try {
            engine = new ManagerInitializer(configuration, registry, dependencies, errors).initialize();
            for (String id : specialistRegistry.getRegisteredIds()) {
                specialistRegistry.updateStatus(id, SpecialistStatus.AVAILABLE);
            }
            runtime = snapshot(ManagerRuntime.State.RUNNING, System.currentTimeMillis(),
                "Manager ready; specialist lifecycle is active", engine.getInitializedModuleIds().size());
        } catch (AIException failure) {
            runtime = snapshot(ManagerRuntime.State.FAILED, System.currentTimeMillis(),
                failure.getMessage(), 0);
            for (String id : specialistRegistry.getRegisteredIds()) {
                specialistRegistry.updateStatus(id, SpecialistStatus.FAILED);
            }
            errors.report(failure.getComponentId(), failure.getOperation(),
                AIErrorHandler.Severity.CRITICAL, failure);
            throw failure;
        } catch (RuntimeException failure) {
            runtime = snapshot(ManagerRuntime.State.FAILED, System.currentTimeMillis(),
                failure.getMessage(), 0);
            errors.report("manager", "start", AIErrorHandler.Severity.CRITICAL, failure);
            throw failure;
        }
    }

    public synchronized void shutdown() {
        if (runtime.getState() == ManagerRuntime.State.STOPPED
                || runtime.getState() == ManagerRuntime.State.NEW) {
            runtime = snapshot(ManagerRuntime.State.STOPPED, System.currentTimeMillis(), "Manager stopped", 0);
            return;
        }
        runtime = snapshot(ManagerRuntime.State.STOPPING, System.currentTimeMillis(), "Stopping specialists", 0);
        if (engine != null) engine.shutdown();
        engine = null;
        for (String id : specialistRegistry.getRegisteredIds()) {
            specialistRegistry.updateStatus(id, SpecialistStatus.UNAVAILABLE);
        }
        runtime = snapshot(ManagerRuntime.State.STOPPED, System.currentTimeMillis(), "Manager stopped", 0);
    }

    public synchronized ManagerRuntime getRuntime() { return runtime; }
    /** Read-only-by-contract specialist catalog used for capability discovery and status. */
    public SpecialistRegistry getSpecialistRegistry() { return specialistRegistry; }
    public synchronized boolean isAvailable() { return runtime.isAvailable(); }
    public synchronized boolean canCoordinate() { return runtime.getState() == ManagerRuntime.State.RUNNING; }
    public synchronized List<String> getRegisteredSpecialistIds() {
        List<String> ids = new ArrayList<>();
        for (AIInterface specialist : registry.getAll()) ids.add(specialist.getId());
        return Collections.unmodifiableList(ids);
    }
    public AIErrorHandler getErrorHandler() { return errors; }

    public synchronized ManagerHealth checkHealth() {
        int registered = registry.size();
        int initialized = engine == null ? 0 : engine.getInitializedModuleIds().size();
        int errorCount = errors.getHistory().size();
        ManagerHealth.Status status;
        if (runtime.getState() == ManagerRuntime.State.RUNNING && initialized == registered) {
            status = errorCount == 0 ? ManagerHealth.Status.HEALTHY : ManagerHealth.Status.DEGRADED;
        } else if (runtime.getState() == ManagerRuntime.State.READY
                || runtime.getState() == ManagerRuntime.State.DEGRADED) {
            status = ManagerHealth.Status.DEGRADED;
        } else {
            status = ManagerHealth.Status.UNAVAILABLE;
        }
        return new ManagerHealth(status, registered, initialized, errorCount,
            runtime.getMessage(), System.currentTimeMillis());
    }

    private void requireRegistrationWindow() {
        ManagerRuntime.State state = runtime.getState();
        if (state != ManagerRuntime.State.NEW && state != ManagerRuntime.State.STOPPED
                && state != ManagerRuntime.State.FAILED) {
            throw new IllegalStateException("Specialists can only be registered while manager is stopped");
        }
    }

    private ManagerRuntime snapshot(ManagerRuntime.State state, long changedAt,
                                    String message, int initialized) {
        long started = state == ManagerRuntime.State.RUNNING ? changedAt : runtime == null
            ? 0L : runtime.getStartedAtMillis();
        return new ManagerRuntime(state, started, changedAt, message, registry.size(), initialized);
    }
}
