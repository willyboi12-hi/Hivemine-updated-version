package com.hiveminemobile.ai.manager;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.manager.intel.ManagerIntelligenceLoop;
import com.hiveminemobile.ai.manager.intel.ManagerPolicyEngine;
import com.hiveminemobile.ai.manager.intel.SpecialistVote;
import java.util.List;
/** Bridges manager cycle to intelligence loop. */
public final class ManagerDecisionCoordinator {
    private final ManagerIntelligenceLoop loop;
    public ManagerDecisionCoordinator(ManagerIntelligenceLoop loop) {
        this.loop = loop == null ? new ManagerIntelligenceLoop(null) : loop;
    }
    public ManagerGoal decide(ManagerPolicyEngine.WorldFlags flags, List<SpecialistVote> votes) {
        return loop.step(flags, votes);
    }
    public ManagerIntelligenceLoop loop() { return loop; }
}
