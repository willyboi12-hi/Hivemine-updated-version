package com.hiveminemobile.ai.manager;
import java.util.ArrayList;
import java.util.List;
/** Classifies and records manager-level failures. */
public final class ManagerFailureCoordinator {
    public enum Kind { TRANSIENT, SPECIALIST, INTEGRATION, FATAL }
    public static final class Failure {
        public final Kind kind; public final String detail; public final long atMs;
        public Failure(Kind kind, String detail, long atMs) {
            this.kind = kind; this.detail = detail == null ? "" : detail; this.atMs = atMs;
        }
    }
    private final ArrayList<Failure> failures = new ArrayList<Failure>();
    public void record(Kind kind, String detail, long atMs) {
        failures.add(new Failure(kind, detail, atMs));
        while (failures.size() > 50) failures.remove(0);
    }
    public int count() { return failures.size(); }
    public List<Failure> recent() { return new ArrayList<Failure>(failures); }
    public boolean hasFatal() {
        for (Failure f : failures) if (f.kind == Kind.FATAL) return true;
        return false;
    }
}
