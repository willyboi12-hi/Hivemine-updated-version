package com.hiveminemobile.ai.manager;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIEngine;
import com.hiveminemobile.ai.AIErrorHandler;
import com.hiveminemobile.ai.AIException;
import com.hiveminemobile.ai.AIInterface;
import com.hiveminemobile.ai.AIRegistry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Builds and starts the module lifecycle in dependency order. */
final class ManagerInitializer {
    private final AIConfiguration configuration;
    private final AIRegistry registry;
    private final Map<String, Set<String>> dependencies;
    private final AIErrorHandler errors;

    ManagerInitializer(AIConfiguration configuration, AIRegistry registry,
                       Map<String, Set<String>> dependencies, AIErrorHandler errors) {
        this.configuration = configuration;
        this.registry = registry;
        this.dependencies = dependencies;
        this.errors = errors;
    }

    AIEngine initialize() throws AIException {
        List<AIInterface> ordered = dependencyOrder();
        AIRegistry orderedRegistry = new AIRegistry();
        for (AIInterface module : ordered) orderedRegistry.register(module);
        AIEngine engine = new AIEngine(configuration, orderedRegistry, errors);
        engine.initialize();
        engine.start();
        return engine;
    }

    private List<AIInterface> dependencyOrder() throws AIException {
        Map<String, Integer> marks = new HashMap<>();
        List<AIInterface> result = new ArrayList<>();
        for (AIInterface module : registry.getAll()) visit(module, marks, result);
        return Collections.unmodifiableList(result);
    }

    private void visit(AIInterface module, Map<String, Integer> marks,
                       List<AIInterface> result) throws AIException {
        String id = module.getId();
        Integer mark = marks.get(id);
        if (mark != null) {
            if (mark == 1) throw new AIException("Circular module dependency at " + id,
                id, "dependency-validation", null);
            return;
        }
        marks.put(id, 1);
        Set<String> required = dependencies.get(id);
        if (required != null) {
            for (String dependencyId : required) {
                AIInterface dependency = registry.get(dependencyId);
                if (dependency == null) {
                    throw new AIException("Missing required module dependency: " + dependencyId,
                        id, "dependency-validation", null);
                }
                visit(dependency, marks, result);
            }
        }
        marks.put(id, 2);
        result.add(module);
    }
}
