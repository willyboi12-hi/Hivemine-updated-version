package com.hiveminemobile.ai.manager;

import com.hiveminemobile.ai.comm.MessageBus;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Routes manager messages onto the shared MessageBus and keeps a short audit. */
public final class ManagerMessageRouter {
    private final MessageBus bus;
    private final ArrayList<String> audit = new ArrayList<String>();

    public ManagerMessageRouter(MessageBus bus) {
        this.bus = bus;
    }

    public MessageBus.Receipt route(String sender, String recipient, String type, Map<String, String> payload) {
        if (bus == null) return MessageBus.Receipt.rejected(MessageBus.Status.REJECTED_NOT_RUNNING, "no bus");
        MessageBus.Receipt r = bus.send(sender, recipient, type, payload, System.currentTimeMillis());
        audit.add((r.isAccepted() ? "OK " : "NO ") + sender + "->" + recipient + " " + type);
        while (audit.size() > 100) audit.remove(0);
        return r;
    }

    public List<String> audit() { return Collections.unmodifiableList(new ArrayList<String>(audit)); }
}
