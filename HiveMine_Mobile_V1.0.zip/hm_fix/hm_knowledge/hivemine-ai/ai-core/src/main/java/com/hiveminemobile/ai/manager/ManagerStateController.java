package com.hiveminemobile.ai.manager;
/** Tracks manager operational state. */
public final class ManagerStateController {
    public enum State { BOOT, READY, ACTIVE, DEGRADED, STOPPED }
    private State state = State.BOOT;
    public State state() { return state; }
    public void ready() { state = State.READY; }
    public void active() { state = State.ACTIVE; }
    public void degraded() { state = State.DEGRADED; }
    public void stop() { state = State.STOPPED; }
}
