package com.hiveminemobile.ai.manager;

import java.util.ArrayList;
import java.util.List;

/** Lightweight manager-side work items (does not depend on Task package-private ctors). */
public final class ManagerTaskScheduler {
    public static final class WorkItem {
        public final String id;
        public final String title;
        public final int priority; // higher first
        public WorkItem(String id, String title, int priority) {
            this.id = id == null ? "" : id;
            this.title = title == null ? "" : title;
            this.priority = priority;
        }
    }

    private final ArrayList<WorkItem> queue = new ArrayList<WorkItem>();

    public synchronized void submit(WorkItem t) {
        if (t == null) return;
        queue.add(t);
    }

    public synchronized WorkItem pollNext() {
        if (queue.isEmpty()) return null;
        int best = 0;
        for (int i = 1; i < queue.size(); i++) {
            if (queue.get(i).priority > queue.get(best).priority) best = i;
        }
        return queue.remove(best);
    }

    public synchronized int size() { return queue.size(); }
    public synchronized void clear() { queue.clear(); }
    public synchronized List<WorkItem> snapshot() { return new ArrayList<WorkItem>(queue); }
}
