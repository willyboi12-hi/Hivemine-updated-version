package com.hiveminemobile.ai.manager.intel;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Phase 073 — Soft-max style fusion: sum confidence by goal, pick winner.
 */
public final class DecisionFusion {
    public static final class Result {
        public final ManagerGoal goal;
        public final double score;
        public final int voteCount;

        public Result(ManagerGoal goal, double score, int voteCount) {
            this.goal = goal;
            this.score = score;
            this.voteCount = voteCount;
        }
    }

    public Result fuse(List<SpecialistVote> votes) {
        EnumMap<ManagerGoal, Double> scores = new EnumMap<ManagerGoal, Double>(ManagerGoal.class);
        EnumMap<ManagerGoal, Integer> counts = new EnumMap<ManagerGoal, Integer>(ManagerGoal.class);
        if (votes != null) {
            for (SpecialistVote v : votes) {
                if (v == null) continue;
                Double s = scores.get(v.goal);
                scores.put(v.goal, (s == null ? 0.0 : s) + v.confidence);
                Integer c = counts.get(v.goal);
                counts.put(v.goal, (c == null ? 0 : c) + 1);
            }
        }
        ManagerGoal best = ManagerGoal.STANDBY;
        double bestScore = -1;
        for (Map.Entry<ManagerGoal, Double> e : scores.entrySet()) {
            if (e.getValue() > bestScore) {
                bestScore = e.getValue();
                best = e.getKey();
            }
        }
        int vc = counts.get(best) == null ? 0 : counts.get(best);
        if (bestScore < 0) bestScore = 0;
        return new Result(best, bestScore, vc);
    }
}
