package com.hiveminemobile.ai.manager.intel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Phase 071 — Ordered goal stack. Higher index = lower priority.
 * Head of list is the active goal.
 */
public final class GoalHierarchy {
    private final ArrayList<ManagerGoal> stack = new ArrayList<ManagerGoal>();

    public GoalHierarchy() {
        stack.add(ManagerGoal.STANDBY);
    }

    public synchronized ManagerGoal active() {
        return stack.isEmpty() ? ManagerGoal.STANDBY : stack.get(0);
    }

    public synchronized void push(ManagerGoal goal) {
        if (goal == null) return;
        stack.remove(goal);
        stack.add(0, goal);
    }

    public synchronized void completeActive() {
        if (!stack.isEmpty()) stack.remove(0);
        if (stack.isEmpty()) stack.add(ManagerGoal.STANDBY);
    }

    public synchronized void clearTo(ManagerGoal goal) {
        stack.clear();
        stack.add(goal == null ? ManagerGoal.STANDBY : goal);
    }

    public synchronized List<ManagerGoal> snapshot() {
        return Collections.unmodifiableList(new ArrayList<ManagerGoal>(stack));
    }
}
