package com.hiveminemobile.ai.manager.intel;

/** Phase 071 — Top-level manager goals (not macro commands). */
public enum ManagerGoal {
    STANDBY,
    FARM_POLLEN,
    CONVERT_HONEY,
    TURN_IN_QUEST,
    RECOVER_SESSION,
    SHUTDOWN
}
