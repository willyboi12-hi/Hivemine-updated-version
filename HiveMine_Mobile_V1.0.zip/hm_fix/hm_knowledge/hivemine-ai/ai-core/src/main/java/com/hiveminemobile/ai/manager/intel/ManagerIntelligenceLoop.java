package com.hiveminemobile.ai.manager.intel;

import com.hiveminemobile.ai.automation.ActionPlanner;
import com.hiveminemobile.ai.decision.PowerDecisionEngine;
import com.hiveminemobile.ai.decision.AdaptivePolicyBrain;
import com.hiveminemobile.ai.automation.AutomationOrchestrator;

import java.util.ArrayList;
import java.util.List;

/**
 * Phase 078 — One intelligence step: policy + votes + fusion + conflict + escalation,
 * then maps ManagerGoal onto AutomationOrchestrator goals (no direct MacroPort).
 */
public final class ManagerIntelligenceLoop {
    private final GoalHierarchy hierarchy = new GoalHierarchy();
    private final SpecialistArbiter arbiter = new SpecialistArbiter();
    private final DecisionFusion fusion = new DecisionFusion();
    private final ConflictResolver conflicts = new ConflictResolver();
    private final ManagerPolicyEngine policy = new ManagerPolicyEngine();
    private final EscalationManager escalation;
    private final PlanGraph plan = new PlanGraph();
    private final ManagerIntelligenceReport report = new ManagerIntelligenceReport();
    private final PowerDecisionEngine power = new PowerDecisionEngine();
    private final AdaptivePolicyBrain adaptiveBrain = new AdaptivePolicyBrain();
    private boolean usePowerEngine = true;

    private AutomationOrchestrator automation; // optional

    public ManagerIntelligenceLoop(EscalationManager escalation) {
        this.escalation = escalation == null
                ? new EscalationManager(2, 4, 7)
                : escalation;
    }

    public void bindAutomation(AutomationOrchestrator orch) {
        this.automation = orch;
    }

    public void setUsePowerEngine(boolean on) { usePowerEngine = on; }
    public PowerDecisionEngine power() { return power; }
    public AdaptivePolicyBrain adaptiveBrain() { return adaptiveBrain; }

    public GoalHierarchy hierarchy() { return hierarchy; }
    public PlanGraph plan() { return plan; }
    public ManagerIntelligenceReport report() { return report; }
    public EscalationManager escalation() { return escalation; }

    /**
     * @param flags world observation flags
     * @param votes specialist votes (may be empty)
     * @return chosen manager goal after all layers
     */
    public ManagerGoal step(ManagerPolicyEngine.WorldFlags flags, List<SpecialistVote> votes) {
        AdaptivePolicyBrain.Observation o = new AdaptivePolicyBrain.Observation();
        if (flags != null) {
            o.bagFull = flags.bagFull;
            o.questComplete = flags.questComplete;
            o.disconnected = flags.disconnected;
            o.faulted = flags.faulted;
            o.userWantsFarm = flags.userWantsFarm;
            o.bagFill = flags.bagFill;
            o.pollenRate = flags.pollenRate;
            o.risk = flags.risk;
            o.observationFresh = flags.observationFresh;
            o.ageMs = flags.observationAgeMs;
        }
        AdaptivePolicyBrain.Decision adaptive = adaptiveBrain.decide(o, votes, System.currentTimeMillis());
        if (adaptive != null && adaptive.confidence >= 0.80) {
            ManagerGoal chosen = adaptive.goal;
            hierarchy.push(chosen);
            report.record(chosen, chosen, new DecisionFusion.Result(chosen, adaptive.confidence, 1),
                    votes == null || votes.isEmpty() ? new SpecialistVote("adaptive", chosen, adaptive.confidence, adaptive.reason)
                            : votes.get(0), escalation.level());
            applyToAutomation(chosen, flags);
            return chosen;
        }
        ManagerGoal policyGoal = policy.evaluate(flags);
        List<SpecialistVote> safeVotes = votes == null ? new ArrayList<SpecialistVote>() : votes;
        DecisionFusion.Result fused = fusion.fuse(safeVotes);
        SpecialistVote arb = arbiter.arbitrate(safeVotes);

        ManagerGoal chosen;
        if (usePowerEngine) {
            PowerDecisionEngine.Factors f = new PowerDecisionEngine.Factors();
            if (flags != null) {
                f.bagFull = flags.bagFull;
                f.questComplete = flags.questComplete;
                f.disconnected = flags.disconnected;
                f.faulted = flags.faulted;
                f.userWantsFarm = flags.userWantsFarm;
                f.bagFill = flags.bagFill > 0 ? flags.bagFill : (flags.bagFull ? 1.0 : 0.0);
                f.pollenRate = flags.pollenRate;
                f.risk = flags.risk;
            }
            chosen = power.decide(f, safeVotes);
        } else {
            chosen = conflicts.resolve(policyGoal, fused.goal);
            chosen = conflicts.resolve(chosen, arb.goal);
        }

        ManagerGoal esc = escalation.goalOverride();
        if (esc != null) chosen = conflicts.resolve(chosen, esc);

        hierarchy.push(chosen);
        report.record(chosen, policyGoal, fused, arb, escalation.level());

        applyToAutomation(chosen, flags);
        return chosen;
    }

    private void applyToAutomation(ManagerGoal goal, ManagerPolicyEngine.WorldFlags flags) {
        if (automation == null) return;
        if (flags != null && flags.disconnected) {
            automation.setDisconnectedHint(true);
        }
        switch (goal) {
            case SHUTDOWN:
            case STANDBY:
                automation.setGoal(ActionPlanner.Goal.IDLE);
                break;
            case RECOVER_SESSION:
                automation.setGoal(ActionPlanner.Goal.RECOVER_THEN_FARM);
                break;
            case FARM_POLLEN:
            case CONVERT_HONEY:
            case TURN_IN_QUEST:
                automation.setGoal(ActionPlanner.Goal.FARM);
                break;
            default:
                automation.setGoal(ActionPlanner.Goal.IDLE);
        }
    }
}
