package com.hiveminemobile.ai.manager.intel;

/** Phase 075 — One step in a manager plan. */
public final class PlanNode {
    public final String id;
    public final ManagerGoal goal;
    public final String detail;

    public PlanNode(String id, ManagerGoal goal, String detail) {
        this.id = id == null ? "" : id;
        this.goal = goal == null ? ManagerGoal.STANDBY : goal;
        this.detail = detail == null ? "" : detail;
    }
}
