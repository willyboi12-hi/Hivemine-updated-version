package com.hiveminemobile.ai.manager.intel;

/** Phase 072 — One specialist's recommendation. */
public final class SpecialistVote {
    public final String specialistId;
    public final ManagerGoal goal;
    public final double confidence; // 0..1
    public final String rationale;

    public SpecialistVote(String specialistId, ManagerGoal goal, double confidence, String rationale) {
        this.specialistId = specialistId == null ? "?" : specialistId;
        this.goal = goal == null ? ManagerGoal.STANDBY : goal;
        this.confidence = Math.max(0, Math.min(1, confidence));
        this.rationale = rationale == null ? "" : rationale;
    }
}
