package com.hiveminemobile.ai.manager.runtime;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIException;
import com.hiveminemobile.ai.automation.ActionPlanner;
import com.hiveminemobile.ai.automation.AutomationOrchestrator;
import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.manager.ManagerCoordinator;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.manager.intel.ManagerIntelligenceLoop;
import com.hiveminemobile.ai.manager.intel.ManagerPolicyEngine;
import com.hiveminemobile.ai.manager.intel.SpecialistVote;
import com.hiveminemobile.ai.merge.SpecialistCatalogFactory;
import com.hiveminemobile.ai.modules.BaseSpecialist;
import com.hiveminemobile.ai.learning.LearningRuntimeService;
import com.hiveminemobile.ai.learning.Recommendation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Android-independent closed-loop manager runtime. It turns live macro telemetry into manager
 * goals, feeds those goals into the scheduler/automation layer, and never bypasses
 * AutomationController authorization.
 */
public final class ManagerRuntimeService {
    private final ManagerCoordinator coordinator;
    private final ManagerIntelligenceLoop intelligence;
    private final AutomationOrchestrator automation;
    private final LearningRuntimeService learning = new LearningRuntimeService(500, 5);
    private boolean started;
    private boolean userWantsFarm;
    private boolean controlEnabled;
    private boolean questSmart;
    private String materialGoal = "";
    private ManagerGoal lastGoal = ManagerGoal.STANDBY;
    private String lastDecision = "";

    public ManagerRuntimeService(AIConfiguration configuration, AutomationController controller, MacroPort port) {
        if (controller == null || port == null) throw new IllegalArgumentException("controller and port are required");
        coordinator = new ManagerCoordinator(configuration == null ? AIConfiguration.empty() : configuration);
        for (BaseSpecialist specialist : new SpecialistCatalogFactory().all()) coordinator.registerSpecialist(specialist);
        intelligence = new ManagerIntelligenceLoop(null);
        automation = new AutomationOrchestrator(controller, port, 1000L, 6L * 60L * 60L * 1000L, 4, 5);
        intelligence.bindAutomation(automation);
    }

    public synchronized void start() throws AIException {
        if (started) return;
        coordinator.start();
        started = true;
    }

    public synchronized void stop() {
        automation.emergencyStop(System.currentTimeMillis(), "manager-runtime-stop");
        coordinator.shutdown();
        started = false;
        userWantsFarm = false;
        questSmart = false;
        materialGoal = "";
        controlEnabled = false;
        lastGoal = ManagerGoal.STANDBY;
    }

    public synchronized void setUserWantsFarm(boolean wanted) { userWantsFarm = wanted; controlEnabled = true; }
    /** Enables quest-aware farming without pretending a quest is complete when telemetry cannot verify it. */
    public synchronized void setQuestSmart(boolean enabled) { questSmart = enabled; controlEnabled = true; }
    /** Sets the material objective as structured manager state rather than relying on a raw sentence. */
    public synchronized void setMaterialGoal(String goal) { materialGoal = goal == null ? "" : goal.trim(); controlEnabled = true; }
    public synchronized boolean isQuestSmart() { return questSmart; }
    public synchronized String materialGoal() { return materialGoal; }
    /** Clears Manager control without issuing a macro action; the manager becomes observe-only. */
    public synchronized void releaseControl() {
        controlEnabled = false;
        userWantsFarm = false;
        questSmart = false;
        materialGoal = "";
    }
    public synchronized boolean isStarted() { return started; }
    public synchronized ManagerGoal lastGoal() { return lastGoal; }
    public synchronized String lastDecision() { return lastDecision; }
    public synchronized ManagerCoordinator coordinator() { return coordinator; }
    public synchronized AutomationOrchestrator automation() { return automation; }
    public synchronized LearningRuntimeService learning() { return learning; }
    public synchronized List<Recommendation> learningRecommendations() { return learning.recommendations(); }
    public synchronized void recordOutcome(String capability, String specialistId, boolean success, String detail, long nowMillis) {
        learning.recordOutcome(capability, specialistId, success, detail, nowMillis);
    }

    /** Feeds a verified outcome back into the adaptive policy so future choices improve. */
    public synchronized void recordAdaptiveOutcome(ManagerGoal goal, boolean improved) {
        intelligence.adaptiveBrain().recordOutcome(goal, improved);
    }

    /** One closed-loop cycle: observe -> manager decision -> scheduler -> authorized macro action. */
    public synchronized ManagerGoal tick(MacroStatus status, long nowMillis) {
        if (!started || status == null) return ManagerGoal.STANDBY;
        ManagerPolicyEngine.WorldFlags flags = new ManagerPolicyEngine.WorldFlags();
        flags.disconnected = !status.isConnected();
        flags.faulted = automation.state() == com.hiveminemobile.ai.automation.AutomationState.FAULT;
        flags.userWantsFarm = userWantsFarm || questSmart || !materialGoal.isEmpty();
        flags.bagFull = status.getBagPercent() >= 95;
        flags.bagFill = status.getBagPercent() < 0 ? 0.0 : status.getBagPercent() / 100.0;
        long observedAt = status.getObservedAtMillis();
        flags.observationAgeMs = observedAt <= 0 ? Long.MAX_VALUE : Math.max(0L, nowMillis - observedAt);
        flags.observationFresh = flags.observationAgeMs <= 3000L;
        // A stale scene/telemetry sample is treated as uncertainty rather than truth.
        flags.risk = flags.observationFresh ? 0.0 : 0.35;
        // Quest completion is deliberately not fabricated. Until a quest reader provides a
        // verified completion signal, questSmart means "farm toward quest objectives" rather
        // than "turn in a quest".
        flags.questComplete = false;
        List<SpecialistVote> votes = votes(status, flags);
        ManagerGoal goal = intelligence.step(flags, votes);
        if (!controlEnabled) {
            lastGoal = goal;
            lastDecision = goal.name() + " (observe-only)";
            return goal;
        }
        lastGoal = goal;
        lastDecision = goal.name() + " from " + votes.size() + " specialist votes";

        if (goal == ManagerGoal.SHUTDOWN || goal == ManagerGoal.STANDBY) {
            if (goal == ManagerGoal.SHUTDOWN) automation.emergencyStop(nowMillis, "manager-safety-shutdown");
            else automation.setGoal(ActionPlanner.Goal.IDLE);
        } else if (goal == ManagerGoal.RECOVER_SESSION) {
            automation.setGoal(ActionPlanner.Goal.RECOVER_THEN_FARM);
        } else if (goal == ManagerGoal.CONVERT_HONEY) {
            automation.setGoal(ActionPlanner.Goal.CONVERT);
        } else {
            automation.setGoal(ActionPlanner.Goal.FARM);
        }
        if (automation.state() == com.hiveminemobile.ai.automation.AutomationState.IDLE
                && goal != ManagerGoal.STANDBY && goal != ManagerGoal.SHUTDOWN) {
            automation.arm("manager-session", nowMillis);
        }
        automation.tick(nowMillis);
        return goal;
    }

    private static List<SpecialistVote> votes(MacroStatus status, ManagerPolicyEngine.WorldFlags flags) {
        List<SpecialistVote> out = new ArrayList<>();
        if (!status.isConnected()) {
            out.add(new SpecialistVote("recovery", ManagerGoal.RECOVER_SESSION, 0.98, "macro service disconnected"));
            out.add(new SpecialistVote("safety", ManagerGoal.SHUTDOWN, 0.95, "execution endpoint unavailable"));
        } else if (status.getBagPercent() >= 95) {
            out.add(new SpecialistVote("conversion", ManagerGoal.CONVERT_HONEY, 0.96, "bag is at least 95% full"));
        } else if (flags.userWantsFarm) {
            out.add(new SpecialistVote("farming", ManagerGoal.FARM_POLLEN, 0.92, "user requested farming"));
        } else {
            out.add(new SpecialistVote("safety", ManagerGoal.STANDBY, 0.70, "no active user goal"));
        }
        return Collections.unmodifiableList(out);
    }
}
