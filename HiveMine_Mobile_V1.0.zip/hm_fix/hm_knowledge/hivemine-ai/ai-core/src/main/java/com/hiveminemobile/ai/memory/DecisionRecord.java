package com.hiveminemobile.ai.memory;

/** One recorded manager decision and the result observed for it. Immutable. */
public final class DecisionRecord {
    public enum Outcome { SUCCESS, FAILURE, UNKNOWN }

    public static final int MAX_DETAIL_LENGTH = 500;

    private final long sequence;
    private final long recordedAtMillis;
    private final String taskId;
    private final String capability;
    private final String specialistId;
    private final String decision;
    private final Outcome outcome;
    private final String detail;

    DecisionRecord(long sequence, long recordedAtMillis, String taskId, String capability,
                   String specialistId, String decision, Outcome outcome, String detail) {
        this.sequence = sequence;
        this.recordedAtMillis = recordedAtMillis;
        this.taskId = taskId;
        this.capability = capability;
        this.specialistId = specialistId;
        this.decision = decision;
        this.outcome = outcome;
        this.detail = detail;
    }

    public long getSequence() { return sequence; }
    public long getRecordedAtMillis() { return recordedAtMillis; }
    public String getTaskId() { return taskId; }
    public String getCapability() { return capability; }
    public String getSpecialistId() { return specialistId; }
    public String getDecision() { return decision; }
    public Outcome getOutcome() { return outcome; }
    public String getDetail() { return detail; }
}
