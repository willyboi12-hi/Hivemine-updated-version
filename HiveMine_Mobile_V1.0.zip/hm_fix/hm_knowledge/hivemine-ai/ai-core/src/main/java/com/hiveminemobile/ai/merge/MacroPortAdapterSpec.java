package com.hiveminemobile.ai.merge;
/**
 * Spec for HiveMine Mobile's MacroPort implementation at merge time.
 * This class does not bind Android; it only validates adapter promises.
 */
public final class MacroPortAdapterSpec {
    public boolean validates(boolean implementsStart, boolean implementsStop,
                             boolean implementsRecover, boolean implementsReadStatus,
                             boolean aiControlIsUserOnly) {
        return implementsStart && implementsStop && implementsRecover
                && implementsReadStatus && aiControlIsUserOnly;
    }
    public String mergeInstructions() {
        return "Implement com.hiveminemobile.ai.control.MacroPort in HiveMine Mobile. "
                + "Wire AutomationController.setAiControlEnabled only from user UI.";
    }
}
