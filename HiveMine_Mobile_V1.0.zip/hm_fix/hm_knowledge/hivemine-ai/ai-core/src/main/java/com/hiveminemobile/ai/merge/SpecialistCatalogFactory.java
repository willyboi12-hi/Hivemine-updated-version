package com.hiveminemobile.ai.merge;

import com.hiveminemobile.ai.modules.*;
import java.util.ArrayList;
import java.util.List;

/** Registers the full specialist set for V2. */
public final class SpecialistCatalogFactory {
    public List<BaseSpecialist> all() {
        ArrayList<BaseSpecialist> list = new ArrayList<BaseSpecialist>();
        list.add(new VisionAI());
        list.add(new StateAI());
        list.add(new FarmingAI());
        list.add(new NavigationAI());
        list.add(new InventoryAI());
        list.add(new QuestAI());
        list.add(new PerformanceAI());
        list.add(new LearningAI());
        list.add(new FieldAI());
        list.add(new MovementAI());
        list.add(new BeeAI());
        list.add(new AbilityAI());
        list.add(new TokenAI());
        list.add(new FieldSelectionAI());
        list.add(new ConversionAI());
        list.add(new EquipmentAI());
        list.add(new ShopAI());
        list.add(new BoostAI());
        list.add(new TimerAI());
        list.add(new SafetyAI());
        return list;
    }
}
