package com.hiveminemobile.ai.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Phase 028. Descriptive statistics over historical values and simple efficiency ratios. */
public final class AnalyticsAI extends BaseSpecialist {
    public static final String ID = "analytics";

    public static final class Summary {
        private final int count;
        private final double mean;
        private final double median;
        private final double min;
        private final double max;
        private final double p90;

        Summary(int count, double mean, double median, double min, double max, double p90) {
            this.count = count;
            this.mean = mean;
            this.median = median;
            this.min = min;
            this.max = max;
            this.p90 = p90;
        }

        public int getCount() { return count; }
        public double getMean() { return mean; }
        public double getMedian() { return median; }
        public double getMin() { return min; }
        public double getMax() { return max; }
        /** 90th percentile by the nearest-rank method. */
        public double getP90() { return p90; }
    }

    public AnalyticsAI() {
        super(ID, "analyze.statistics");
    }

    public Summary summarize(List<Double> values) {
        if (values == null || values.isEmpty()) throw new IllegalArgumentException("no values to summarise");
        List<Double> sorted = new ArrayList<>();
        double sum = 0.0;
        for (Double value : values) {
            if (value == null || Double.isNaN(value) || Double.isInfinite(value)) {
                throw new IllegalArgumentException("values must be finite");
            }
            sorted.add(value);
            sum += value;
        }
        Collections.sort(sorted);
        int n = sorted.size();
        double median = n % 2 == 1 ? sorted.get(n / 2) : (sorted.get(n / 2 - 1) + sorted.get(n / 2)) / 2.0;
        int rank = (int) Math.ceil(0.9 * n);
        return new Summary(n, sum / n, median, sorted.get(0), sorted.get(n - 1), sorted.get(rank - 1));
    }

    public double efficiency(double output, double minutes) {
        if (!(minutes > 0.0)) throw new IllegalArgumentException("minutes must be positive");
        if (!(output >= 0.0)) throw new IllegalArgumentException("output must not be negative");
        return output / minutes;
    }
}
