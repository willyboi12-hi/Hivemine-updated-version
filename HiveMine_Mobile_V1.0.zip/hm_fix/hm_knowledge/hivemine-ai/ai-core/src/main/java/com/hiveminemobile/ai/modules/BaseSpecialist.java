package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIInterface;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Shared identity for Stage 2 specialists. Each module is a pure analyzer: it reads the data it is
 * given and returns findings. None of them captures the screen, reads game memory or uses Android.
 */
public abstract class BaseSpecialist implements AIInterface {
    private final String id;
    private final Set<String> capabilities;

    protected BaseSpecialist(String id, String... capabilities) {
        this.id = id;
        this.capabilities = Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(capabilities)));
    }

    @Override public final String getId() { return id; }
    @Override public final String getVersion() { return "1.0.0"; }
    @Override public final Set<String> getCapabilities() { return capabilities; }
    @Override public void onInitialize(AIConfiguration configuration) { }
    @Override public void onShutdown() { }
}
