package com.hiveminemobile.ai.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Phase 025. Checks a device description against what the application needs: Android API level,
 * granted permissions, device features and memory. It reads descriptions only; it queries no device.
 */
public final class CompatibilityAI extends BaseSpecialist {
    public static final String ID = "compatibility";

    public static final class Device {
        private final int androidApi;
        private final int memoryMb;
        private final Set<String> permissions;
        private final Set<String> features;

        public Device(int androidApi, int memoryMb, Set<String> permissions, Set<String> features) {
            if (androidApi < 1) throw new IllegalArgumentException("androidApi must be positive");
            if (memoryMb < 0) throw new IllegalArgumentException("memoryMb must not be negative");
            this.androidApi = androidApi;
            this.memoryMb = memoryMb;
            this.permissions = Collections.unmodifiableSet(new LinkedHashSet<>(permissions));
            this.features = Collections.unmodifiableSet(new LinkedHashSet<>(features));
        }
    }

    public static final class Requirements {
        private final int minApi;
        private final int minMemoryMb;
        private final Set<String> permissions;
        private final Set<String> features;

        public Requirements(int minApi, int minMemoryMb, Set<String> permissions, Set<String> features) {
            if (minApi < 1) throw new IllegalArgumentException("minApi must be positive");
            if (minMemoryMb < 0) throw new IllegalArgumentException("minMemoryMb must not be negative");
            this.minApi = minApi;
            this.minMemoryMb = minMemoryMb;
            this.permissions = Collections.unmodifiableSet(new LinkedHashSet<>(permissions));
            this.features = Collections.unmodifiableSet(new LinkedHashSet<>(features));
        }
    }

    public static final class Issue {
        private final boolean blocking;
        private final String message;

        Issue(boolean blocking, String message) {
            this.blocking = blocking;
            this.message = message;
        }

        /** A blocking issue means the application cannot run as required. */
        public boolean isBlocking() { return blocking; }
        public String getMessage() { return message; }
    }

    public CompatibilityAI() {
        super(ID, "analyze.compatibility");
    }

    public List<Issue> check(Device device, Requirements requirements) {
        List<Issue> issues = new ArrayList<>();
        if (device.androidApi < requirements.minApi) {
            issues.add(new Issue(true, "Android API " + device.androidApi + " is below the required "
                + requirements.minApi));
        }
        for (String permission : requirements.permissions) {
            if (!device.permissions.contains(permission)) {
                issues.add(new Issue(true, "Permission not granted: " + permission));
            }
        }
        for (String feature : requirements.features) {
            if (!device.features.contains(feature)) issues.add(new Issue(true, "Feature missing: " + feature));
        }
        if (device.memoryMb < requirements.minMemoryMb) {
            issues.add(new Issue(false, "Memory " + device.memoryMb + " MB is below the recommended "
                + requirements.minMemoryMb + " MB"));
        }
        return Collections.unmodifiableList(issues);
    }

    public static boolean isCompatible(List<Issue> issues) {
        for (Issue issue : issues) {
            if (issue.blocking) return false;
        }
        return true;
    }
}
