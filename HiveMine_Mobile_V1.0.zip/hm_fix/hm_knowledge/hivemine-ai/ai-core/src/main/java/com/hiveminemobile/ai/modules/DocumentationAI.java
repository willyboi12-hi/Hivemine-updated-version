package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.AIInterface;
import com.hiveminemobile.ai.Identifiers;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Phase 030. Writes a deterministic Markdown report of the registered modules and the phase status.
 * The same inputs always produce the same text, so reports can be diffed between releases.
 */
public final class DocumentationAI extends BaseSpecialist {
    public static final String ID = "documentation";
    private static final int TITLE_LIMIT = 120;

    public static final class Entry {
        private final String id;
        private final String version;
        private final Set<String> capabilities;

        public Entry(String id, String version, Set<String> capabilities) {
            if (!Identifiers.isValid(id)) throw new IllegalArgumentException("module id is invalid: " + id);
            if (version == null || version.trim().isEmpty()) throw new IllegalArgumentException("version is required");
            this.id = id;
            this.version = version;
            this.capabilities = Collections.unmodifiableSet(new TreeSet<>(capabilities));
        }

        public String getId() { return id; }
        public String getVersion() { return version; }
        public Set<String> getCapabilities() { return capabilities; }
    }

    public DocumentationAI() {
        super(ID, "document.report");
    }

    /** Describes modules sorted by id. */
    public List<Entry> describe(List<AIInterface> modules) {
        List<Entry> entries = new ArrayList<>();
        for (AIInterface module : modules) {
            entries.add(new Entry(module.getId(), module.getVersion(), module.getCapabilities()));
        }
        Collections.sort(entries, new Comparator<Entry>() {
            @Override public int compare(Entry left, Entry right) {
                return left.id.compareTo(right.id);
            }
        });
        return Collections.unmodifiableList(entries);
    }

    public String buildReport(String title, List<Entry> entries, Map<String, String> phaseStatus) {
        if (title == null || title.trim().isEmpty() || title.trim().length() > TITLE_LIMIT) {
            throw new IllegalArgumentException("title must be 1-" + TITLE_LIMIT + " characters");
        }
        List<Entry> sorted = new ArrayList<>(entries);
        Collections.sort(sorted, new Comparator<Entry>() {
            @Override public int compare(Entry left, Entry right) {
                return left.id.compareTo(right.id);
            }
        });
        StringBuilder report = new StringBuilder();
        report.append("# ").append(title.trim()).append("\n\n## Modules\n\n");
        for (Entry entry : sorted) {
            String capabilities = entry.capabilities.isEmpty() ? "none" : String.join(", ", entry.capabilities);
            report.append("- `").append(entry.id).append("` v").append(entry.version)
                .append(" — capabilities: ").append(capabilities).append('\n');
        }
        report.append("\n## Phase status\n\n");
        for (Map.Entry<String, String> phase : new TreeMap<>(phaseStatus).entrySet()) {
            report.append("- ").append(phase.getKey()).append(": ").append(phase.getValue()).append('\n');
        }
        return report.toString();
    }
}
