package com.hiveminemobile.ai.modules;

import java.util.List;

/**
 * Phase 014. Compares recognised field observations with a planned route. It reports whether the
 * character appears on route, off route, lost or finished. It issues no movement commands.
 */
public final class NavigationAI extends BaseSpecialist {
    public static final String ID = "navigation";

    public enum Status { UNKNOWN, ON_ROUTE, OFF_ROUTE, LOST, COMPLETE }

    public static final class Assessment {
        private final Status status;
        private final String lastSeen;
        private final String expectedNext;

        Assessment(Status status, String lastSeen, String expectedNext) {
            this.status = status;
            this.lastSeen = lastSeen;
            this.expectedNext = expectedNext;
        }

        public Status getStatus() { return status; }
        /** Most recent recognised field, or null when nothing was recognised. */
        public String getLastSeen() { return lastSeen; }
        /** Next planned field after the furthest one reached, or null at the end of the route. */
        public String getExpectedNext() { return expectedNext; }
    }

    private final int lostAfterMismatches;

    public NavigationAI() {
        this(3);
    }

    public NavigationAI(int lostAfterMismatches) {
        super(ID, "analyze.location");
        if (lostAfterMismatches < 1) throw new IllegalArgumentException("lostAfterMismatches must be at least 1");
        this.lostAfterMismatches = lostAfterMismatches;
    }

    /**
     * plannedFields is the route in order. observedFields is the recognised field in time order;
     * a null entry is a frame that was not recognised and is skipped. The route advances one field
     * at a time, and a run of unexpected fields of the configured length counts as lost.
     */
    public Assessment assess(List<String> plannedFields, List<String> observedFields) {
        if (plannedFields == null || plannedFields.isEmpty()) {
            throw new IllegalArgumentException("route must have at least one field");
        }
        if (observedFields == null) throw new IllegalArgumentException("observations must not be null");
        int reached = 0;
        int mismatchStreak = 0;
        String lastSeen = null;
        for (String seen : observedFields) {
            if (seen == null) continue;
            lastSeen = seen;
            if (seen.equals(plannedFields.get(reached))) {
                mismatchStreak = 0;
            } else if (reached + 1 < plannedFields.size() && seen.equals(plannedFields.get(reached + 1))) {
                reached++;
                mismatchStreak = 0;
            } else {
                mismatchStreak++;
            }
        }
        String expected = reached + 1 < plannedFields.size() ? plannedFields.get(reached + 1) : null;
        if (lastSeen == null) return new Assessment(Status.UNKNOWN, null, expected);
        Status status;
        if (mismatchStreak >= lostAfterMismatches) status = Status.LOST;
        else if (mismatchStreak > 0) status = Status.OFF_ROUTE;
        else if (reached == plannedFields.size() - 1) status = Status.COMPLETE;
        else status = Status.ON_ROUTE;
        return new Assessment(status, lastSeen, expected);
    }
}
