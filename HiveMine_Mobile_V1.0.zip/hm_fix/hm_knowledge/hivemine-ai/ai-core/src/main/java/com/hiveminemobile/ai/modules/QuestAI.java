package com.hiveminemobile.ai.modules;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Phase 016. Reads quest lines such as "Brown Bear: collect pollen 45/100", tracks progress across
 * readings, and flags a quest whose progress has not moved for a set time.
 */
public final class QuestAI extends BaseSpecialist {
    public static final String ID = "quest";

    public enum Status { IN_PROGRESS, COMPLETE, STALLED, UNREADABLE }

    private static final Pattern LINE = Pattern.compile("^(.+?): (.+) (\\d{1,9})/(\\d{1,9})$");

    public static final class Assessment {
        private final String key;
        private final Status status;
        private final int current;
        private final int target;
        private final String note;

        Assessment(String key, Status status, int current, int target, String note) {
            this.key = key;
            this.status = status;
            this.current = current;
            this.target = target;
            this.note = note;
        }

        /** Giver and objective without the numbers, or null when the line was unreadable. */
        public String getKey() { return key; }
        public Status getStatus() { return status; }
        public int getCurrent() { return current; }
        public int getTarget() { return target; }
        public String getNote() { return note; }
    }

    private static final class Track {
        int lastCurrent;
        long lastChangeAt;

        Track(int current, long at) {
            this.lastCurrent = current;
            this.lastChangeAt = at;
        }
    }

    private final long stallAfterMillis;
    private final Map<String, Track> tracks = new HashMap<>();

    public QuestAI() {
        this(10L * 60_000L);
    }

    public QuestAI(long stallAfterMillis) {
        super(ID, "analyze.quest");
        if (stallAfterMillis < 1L) throw new IllegalArgumentException("stallAfterMillis must be positive");
        this.stallAfterMillis = stallAfterMillis;
    }

    public synchronized Assessment observe(String text, long nowMillis) {
        Matcher matcher = LINE.matcher(text == null ? "" : text.trim());
        if (!matcher.matches()) {
            return new Assessment(null, Status.UNREADABLE, 0, 0, "text does not match a quest line");
        }
        String key = matcher.group(1).trim() + ": " + matcher.group(2).trim();
        int current = Integer.parseInt(matcher.group(3));
        int target = Integer.parseInt(matcher.group(4));
        if (target < 1 || current > target) {
            return new Assessment(key, Status.UNREADABLE, current, target, "progress is outside the target");
        }
        Track track = tracks.get(key);
        if (track == null) {
            tracks.put(key, new Track(current, nowMillis));
        } else if (current != track.lastCurrent) {
            track.lastCurrent = current;
            track.lastChangeAt = nowMillis;
        }
        Track now = tracks.get(key);
        if (current >= target) return new Assessment(key, Status.COMPLETE, current, target, "");
        long idleMillis = nowMillis - now.lastChangeAt;
        if (idleMillis > stallAfterMillis) {
            return new Assessment(key, Status.STALLED, current, target,
                "no progress for " + (idleMillis / 60_000L) + " minute(s)");
        }
        return new Assessment(key, Status.IN_PROGRESS, current, target, "");
    }
}
