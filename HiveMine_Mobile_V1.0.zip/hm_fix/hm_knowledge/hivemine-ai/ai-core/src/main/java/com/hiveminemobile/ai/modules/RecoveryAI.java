package com.hiveminemobile.ai.modules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Phase 018. Turns recent errors into a recovery plan. Every plan requires the user's approval; the
 * module never performs a step itself. Repeated or input-related errors escalate to a safe stop.
 */
public final class RecoveryAI extends BaseSpecialist {
    public static final String ID = "recovery";

    public enum ErrorKind { DISCONNECT, SCENE_UNKNOWN, STATE_STALE, GESTURE_REFUSED }
    public enum Severity { INFO, WARNING, CRITICAL }
    public enum Step { REOBSERVE_SCREEN, WAIT_AND_OBSERVE, REJOIN_SERVER, SAFE_STOP, ASK_USER }

    public static final class ErrorEvent {
        private final ErrorKind kind;
        private final long atMillis;

        public ErrorEvent(ErrorKind kind, long atMillis) {
            if (kind == null) throw new IllegalArgumentException("kind must not be null");
            this.kind = kind;
            this.atMillis = atMillis;
        }
    }

    public static final class Plan {
        private final Severity severity;
        private final List<Step> steps;
        private final boolean requiresApproval;
        private final String summary;

        Plan(Severity severity, List<Step> steps, boolean requiresApproval, String summary) {
            this.severity = severity;
            this.steps = Collections.unmodifiableList(new ArrayList<>(steps));
            this.requiresApproval = requiresApproval;
            this.summary = summary;
        }

        public Severity getSeverity() { return severity; }
        public List<Step> getSteps() { return steps; }
        public boolean isRequiresApproval() { return requiresApproval; }
        public String getSummary() { return summary; }
    }

    private final long windowMillis;
    private final int criticalCount;

    public RecoveryAI() {
        this(10L * 60_000L, 3);
    }

    public RecoveryAI(long windowMillis, int criticalCount) {
        super(ID, "plan.recovery");
        if (windowMillis < 1L) throw new IllegalArgumentException("windowMillis must be positive");
        if (criticalCount < 1) throw new IllegalArgumentException("criticalCount must be at least 1");
        this.windowMillis = windowMillis;
        this.criticalCount = criticalCount;
    }

    public Plan plan(List<ErrorEvent> events, long nowMillis) {
        List<ErrorEvent> recent = new ArrayList<>();
        for (ErrorEvent event : events) {
            if (event.atMillis <= nowMillis && nowMillis - event.atMillis <= windowMillis) recent.add(event);
        }
        if (recent.isEmpty()) {
            return new Plan(Severity.INFO, Collections.<Step>emptyList(), true, "No recent errors; nothing to recover.");
        }
        boolean inputRefused = false;
        boolean allDisconnects = true;
        for (ErrorEvent event : recent) {
            if (event.kind == ErrorKind.GESTURE_REFUSED) inputRefused = true;
            if (event.kind != ErrorKind.DISCONNECT) allDisconnects = false;
        }
        if (inputRefused) {
            return critical("A game input was refused; stop and ask the user before continuing.");
        }
        if (recent.size() >= criticalCount) {
            return critical(recent.size() + " errors in the last " + (windowMillis / 60_000L)
                + " minute(s); stop and ask the user.");
        }
        if (allDisconnects) {
            return new Plan(Severity.WARNING, Arrays.asList(Step.WAIT_AND_OBSERVE, Step.REJOIN_SERVER), true,
                "Disconnect detected; wait, then offer to rejoin the server.");
        }
        return new Plan(Severity.WARNING, Arrays.asList(Step.REOBSERVE_SCREEN, Step.WAIT_AND_OBSERVE), true,
            "Recent errors; re-check the screen before continuing.");
    }

    private static Plan critical(String summary) {
        return new Plan(Severity.CRITICAL, Arrays.asList(Step.SAFE_STOP, Step.ASK_USER), true, summary);
    }
}
