package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.Identifiers;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Phase 023. Records automation sessions: one running at a time, closed as completed or aborted,
 * with a bounded history and a summary report.
 */
public final class SessionAI extends BaseSpecialist {
    public static final String ID = "session";
    private static final int NOTE_LIMIT = 200;

    public enum Outcome { RUNNING, COMPLETED, ABORTED }

    public static final class Session {
        private final String id;
        private final long startedAtMillis;
        private final long endedAtMillis;
        private final Outcome outcome;
        private final String note;

        Session(String id, long startedAtMillis, long endedAtMillis, Outcome outcome, String note) {
            this.id = id;
            this.startedAtMillis = startedAtMillis;
            this.endedAtMillis = endedAtMillis;
            this.outcome = outcome;
            this.note = note;
        }

        public String getId() { return id; }
        public long getStartedAtMillis() { return startedAtMillis; }
        /** -1 while the session is still running. */
        public long getEndedAtMillis() { return endedAtMillis; }
        public Outcome getOutcome() { return outcome; }
        public String getNote() { return note; }
        /** Duration in milliseconds, or -1 while running. */
        public long getDurationMillis() { return endedAtMillis < 0L ? -1L : endedAtMillis - startedAtMillis; }
    }

    public static final class Report {
        private final int total;
        private final int completed;
        private final int aborted;
        private final String running;
        private final long averageMillis;
        private final long totalClosedMillis;

        Report(int total, int completed, int aborted, String running, long averageMillis, long totalClosedMillis) {
            this.total = total;
            this.completed = completed;
            this.aborted = aborted;
            this.running = running;
            this.averageMillis = averageMillis;
            this.totalClosedMillis = totalClosedMillis;
        }

        public int getTotal() { return total; }
        public int getCompleted() { return completed; }
        public int getAborted() { return aborted; }
        /** Id of the running session, or null. */
        public String getRunning() { return running; }
        /** Average duration of closed sessions, or -1 when none are closed. */
        public long getAverageMillis() { return averageMillis; }
        public long getTotalClosedMillis() { return totalClosedMillis; }
    }

    private final int historyLimit;
    private final List<Session> history = new ArrayList<>();

    public SessionAI() {
        this(100);
    }

    public SessionAI(int historyLimit) {
        super(ID, "analyze.session");
        if (historyLimit < 1) throw new IllegalArgumentException("historyLimit must be at least 1");
        this.historyLimit = historyLimit;
    }

    public synchronized Session start(String id, long nowMillis) {
        if (!Identifiers.isValid(id)) throw new IllegalArgumentException("session id is invalid");
        for (Session existing : history) {
            if (existing.id.equals(id)) throw new IllegalArgumentException("session id already used: " + id);
            if (existing.outcome == Outcome.RUNNING) {
                throw new IllegalArgumentException("a session is already running: " + existing.id);
            }
        }
        Session session = new Session(id, nowMillis, -1L, Outcome.RUNNING, "");
        history.add(session);
        trim();
        return session;
    }

    public synchronized Session end(String id, Outcome outcome, String note, long nowMillis) {
        if (outcome == null || outcome == Outcome.RUNNING) throw new IllegalArgumentException("outcome must be closed");
        int index = indexOfRunning(id);
        if (index < 0) throw new IllegalArgumentException("no running session with id: " + id);
        Session running = history.get(index);
        if (nowMillis < running.startedAtMillis) throw new IllegalArgumentException("end precedes start");
        String text = note == null ? "" : note.trim();
        if (text.length() > NOTE_LIMIT) text = text.substring(0, NOTE_LIMIT);
        Session closed = new Session(id, running.startedAtMillis, nowMillis, outcome, text);
        history.set(index, closed);
        return closed;
    }

    public synchronized Report report() {
        int completed = 0;
        int aborted = 0;
        long closedTotal = 0L;
        int closed = 0;
        String running = null;
        for (Session session : history) {
            if (session.outcome == Outcome.RUNNING) {
                running = session.id;
                continue;
            }
            closed++;
            closedTotal += session.getDurationMillis();
            if (session.outcome == Outcome.COMPLETED) completed++;
            else aborted++;
        }
        long average = closed == 0 ? -1L : closedTotal / closed;
        return new Report(history.size(), completed, aborted, running, average, closedTotal);
    }

    public synchronized List<Session> history() {
        return Collections.unmodifiableList(new ArrayList<>(history));
    }

    private int indexOfRunning(String id) {
        for (int i = 0; i < history.size(); i++) {
            Session session = history.get(i);
            if (session.outcome == Outcome.RUNNING && session.id.equals(id)) return i;
        }
        return -1;
    }

    /** Drops the oldest closed sessions once the history is over its limit. */
    private void trim() {
        while (history.size() > historyLimit) {
            int oldestClosed = -1;
            for (int i = 0; i < history.size(); i++) {
                if (history.get(i).outcome != Outcome.RUNNING) {
                    oldestClosed = i;
                    break;
                }
            }
            if (oldestClosed < 0) return;
            history.remove(oldestClosed);
        }
    }
}
