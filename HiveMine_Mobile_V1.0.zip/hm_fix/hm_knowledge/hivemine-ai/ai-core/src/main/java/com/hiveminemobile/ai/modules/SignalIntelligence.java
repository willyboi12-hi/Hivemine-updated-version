package com.hiveminemobile.ai.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** Shared smarter signal ranking for specialists. */
public final class SignalIntelligence {
    private SignalIntelligence() {}

    public static List<String> rankedKeys(Map<String, Double> signals) {
        ArrayList<Map.Entry<String, Double>> list = new ArrayList<Map.Entry<String, Double>>();
        if (signals != null) list.addAll(signals.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
            @Override public int compare(Map.Entry<String, Double> a, Map.Entry<String, Double> b) {
                double av = a.getValue() == null ? 0 : a.getValue();
                double bv = b.getValue() == null ? 0 : b.getValue();
                if (av < bv) return 1;
                if (av > bv) return -1;
                return a.getKey().compareTo(b.getKey());
            }
        });
        ArrayList<String> keys = new ArrayList<String>();
        for (Map.Entry<String, Double> e : list) keys.add(e.getKey());
        return keys;
    }

    public static double spread(Map<String, Double> signals) {
        if (signals == null || signals.isEmpty()) return 0;
        double min = Double.POSITIVE_INFINITY, max = Double.NEGATIVE_INFINITY;
        for (Double d : signals.values()) {
            if (d == null) continue;
            if (d < min) min = d;
            if (d > max) max = d;
        }
        if (min == Double.POSITIVE_INFINITY) return 0;
        return max - min;
    }

    public static double normalized(double value, double min, double max) {
        if (max <= min) return 0;
        double n = (value - min) / (max - min);
        if (n < 0) return 0;
        if (n > 1) return 1;
        return n;
    }
}
