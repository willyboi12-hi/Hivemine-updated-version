package com.hiveminemobile.ai.monitor;

/** Phase 095: receives execution updates. */
public interface ExecutionEventListener {
    void onEvent(ExecutionEvent e);

    final class ExecutionEvent {
        public enum Type { ACCEPTED, STARTED, PROGRESS, COMPLETED, FAILED }
        public final String taskId;
        public final Type type;
        public final long atMillis;
        public ExecutionEvent(String taskId, Type type, long at) { this.taskId = taskId; this.type = type; this.atMillis = at; }
    }
}
