package com.hiveminemobile.ai.monitor;

import com.hiveminemobile.ai.monitor.ExecutionEventListener.ExecutionEvent;
import java.util.*;

/**
 * Phase 095: the state of each task. ACCEPTED is not COMPLETED. Only a COMPLETED event completes a task.
 * Terminal states (COMPLETED, FAILED) ignore later events.
 */
public final class ExecutionStateTracker {
    public enum State { ACCEPTED, RUNNING, COMPLETED, FAILED, STALLED }

    public static final class Entry {
        public final String taskId;
        public State state;
        public long lastSeenMillis;
        Entry(String id, State s, long at) { taskId = id; state = s; lastSeenMillis = at; }
    }

    private final Map<String, Entry> entries = new LinkedHashMap<>();

    /** Returns true when the event changed the task. */
    public synchronized boolean apply(ExecutionEvent e) {
        if (e == null || e.taskId == null || e.taskId.trim().isEmpty()) return false;
        Entry cur = entries.get(e.taskId);
        if (cur == null) {
            if (e.type != ExecutionEvent.Type.ACCEPTED) return false;
            entries.put(e.taskId, new Entry(e.taskId, State.ACCEPTED, e.atMillis));
            return true;
        }
        if (cur.state == State.COMPLETED || cur.state == State.FAILED) return false;
        State next;
        switch (e.type) {
            case STARTED: next = State.RUNNING; break;
            case PROGRESS: next = State.RUNNING; break;
            case COMPLETED: next = State.COMPLETED; break;
            case FAILED: next = State.FAILED; break;
            default: return false;
        }
        cur.state = next;
        cur.lastSeenMillis = e.atMillis;
        return true;
    }

    public synchronized void markStalled(String taskId) {
        Entry e = entries.get(taskId);
        if (e != null && (e.state == State.RUNNING || e.state == State.ACCEPTED)) e.state = State.STALLED;
    }

    public synchronized Entry get(String taskId) { return entries.get(taskId); }
    public synchronized List<Entry> all() { return new ArrayList<>(entries.values()); }
}
