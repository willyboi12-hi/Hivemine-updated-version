package com.hiveminemobile.ai.monitor;

import java.util.*;

/** Phase 095: counts per state. Accepted and completed are counted separately, never merged. */
public final class ExecutionSummaryGenerator {
    public List<String> summarize(List<ExecutionStateTracker.Entry> entries) {
        Map<ExecutionStateTracker.State, Integer> counts = new EnumMap<>(ExecutionStateTracker.State.class);
        for (ExecutionStateTracker.Entry e : entries) counts.merge(e.state, 1, Integer::sum);
        List<String> out = new ArrayList<>();
        out.add("tracked tasks: " + entries.size());
        for (ExecutionStateTracker.State s : ExecutionStateTracker.State.values())
            out.add(s + ": " + counts.getOrDefault(s, 0));
        return out;
    }
}
