package com.hiveminemobile.ai.monitor;

import java.util.*;

/** Phase 095: finds tasks that have not reported in for longer than the stall limit. Terminal tasks are never stalled. */
public final class ExecutionTimeoutDetector {
    private final long stallMillis;

    public ExecutionTimeoutDetector(long stallMillis) {
        if (stallMillis <= 0) throw new IllegalArgumentException("stall limit must be positive");
        this.stallMillis = stallMillis;
    }

    public List<String> stalled(List<ExecutionStateTracker.Entry> entries, long now) {
        List<String> out = new ArrayList<>();
        for (ExecutionStateTracker.Entry e : entries) {
            boolean live = e.state == ExecutionStateTracker.State.RUNNING || e.state == ExecutionStateTracker.State.ACCEPTED;
            if (live && now - e.lastSeenMillis > stallMillis) out.add(e.taskId);
        }
        return out;
    }
}
