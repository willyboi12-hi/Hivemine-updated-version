package com.hiveminemobile.ai.monitor;

import com.hiveminemobile.ai.monitor.ExecutionEventListener.ExecutionEvent;
import java.util.*;

/** Phase 095: one monitor for all active tasks. Stalls are reported to Recovery AI, and system outages are reported too. */
public final class UnifiedExecutionMonitor {
    /** Implemented by Recovery AI. */
    public interface RecoveryNotifier { void onStalled(String taskId, long atMillis); }

    private final ExecutionStateTracker tracker = new ExecutionStateTracker();
    private final ExecutionTimeoutDetector detector;
    private final ExecutionSummaryGenerator summaries = new ExecutionSummaryGenerator();
    private final RecoveryNotifier recovery;
    private final List<ExecutionEventListener> listeners = new ArrayList<>();
    private final Map<String, Boolean> systemUp = new TreeMap<>();

    public UnifiedExecutionMonitor(long stallMillis, RecoveryNotifier recovery) {
        this.detector = new ExecutionTimeoutDetector(stallMillis);
        this.recovery = recovery;
    }

    public synchronized void addListener(ExecutionEventListener l) { if (l != null) listeners.add(l); }

    public synchronized boolean receive(ExecutionEvent e) {
        boolean changed = tracker.apply(e);
        if (changed) for (ExecutionEventListener l : listeners) {
            try { l.onEvent(e); } catch (RuntimeException ignored) { /* one listener cannot stop monitoring */ }
        }
        return changed;
    }

    /** Marks stalled tasks and tells Recovery AI about each one. Returns the stalled ids. */
    public synchronized List<String> sweep(long now) {
        List<String> stalled = detector.stalled(tracker.all(), now);
        for (String id : stalled) {
            tracker.markStalled(id);
            if (recovery != null) recovery.onStalled(id, now);
        }
        return stalled;
    }

    public synchronized void setSystemAvailable(String system, boolean up) { systemUp.put(system, up); }

    /** Systems the monitor has been told are down. A system never reported is not listed as down. */
    public synchronized List<String> systemsDown() {
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, Boolean> e : systemUp.entrySet()) if (!e.getValue()) out.add(e.getKey());
        return out;
    }

    public synchronized String statusOf(String taskId) {
        ExecutionStateTracker.Entry e = tracker.get(taskId);
        return e == null ? "UNKNOWN" : e.state.name();
    }

    public synchronized List<String> summary() { return summaries.summarize(tracker.all()); }
}
