package com.hiveminemobile.ai.observation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Phase 044. Matches OCR text to a known field name, tolerating small reading errors. A match needs a
 * single best candidate within a distance of about a quarter of the name's length; ties are rejected.
 */
public final class FieldRecognizer {
    public static final class Match {
        private final String field;
        private final int distance;

        Match(String field, int distance) {
            this.field = field;
            this.distance = distance;
        }

        public String getField() { return field; }
        public int getDistance() { return distance; }
    }

    private final List<String> fields;

    public FieldRecognizer(List<String> knownFields) {
        if (knownFields == null || knownFields.isEmpty()) throw new IllegalArgumentException("at least one field is required");
        List<String> copy = new ArrayList<>();
        for (String field : knownFields) {
            Observation.requireText(field, "field");
            copy.add(field.trim());
        }
        this.fields = Collections.unmodifiableList(copy);
    }

    /** The best matching field, or null when nothing is close enough or two fields tie. */
    public Match match(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        String reading = normalize(text);
        int best = Integer.MAX_VALUE;
        String bestField = null;
        int ties = 0;
        for (String field : fields) {
            int distance = levenshtein(reading, normalize(field));
            if (distance < best) {
                best = distance;
                bestField = field;
                ties = 1;
            } else if (distance == best) {
                ties++;
            }
        }
        int allowed = Math.max(1, normalize(bestField).length() / 4);
        if (ties != 1 || best > allowed) return null;
        return new Match(bestField, best);
    }

    static String normalize(String text) {
        return text.trim().toLowerCase().replaceAll("\\s+", " ");
    }

    static int levenshtein(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[b.length()];
    }
}
