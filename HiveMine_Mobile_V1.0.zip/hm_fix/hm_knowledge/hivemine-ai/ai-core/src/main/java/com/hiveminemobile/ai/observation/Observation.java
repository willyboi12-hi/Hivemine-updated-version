package com.hiveminemobile.ai.observation;

/** One observed fact: a key, its value, where it came from, when it was seen, and how sure we are. Immutable. */
public final class Observation {
    private final String key;
    private final String value;
    private final String source;
    private final long atMillis;
    private final double confidence;

    public Observation(String key, String value, String source, long atMillis, double confidence) {
        requireText(key, "key");
        requireText(source, "source");
        if (value == null) throw new IllegalArgumentException("value must not be null");
        if (!(confidence >= 0.0 && confidence <= 1.0)) throw new IllegalArgumentException("confidence must be 0-1");
        this.key = key;
        this.value = value;
        this.source = source;
        this.atMillis = atMillis;
        this.confidence = confidence;
    }

    public String getKey() { return key; }
    public String getValue() { return value; }
    public String getSource() { return source; }
    public long getAtMillis() { return atMillis; }
    public double getConfidence() { return confidence; }

    static void requireText(String text, String name) {
        if (text == null || text.trim().isEmpty()) throw new IllegalArgumentException(name + " must not be blank");
    }
}
