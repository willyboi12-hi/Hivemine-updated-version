package com.hiveminemobile.ai.observation;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Phase 050. A bounded history of observations per key, with time-range queries. The oldest entries go first. */
public final class ObservationHistory {
    private final int perKeyLimit;
    private final Map<String, ArrayDeque<Observation>> byKey = new HashMap<>();

    public ObservationHistory(int perKeyLimit) {
        if (perKeyLimit < 1) throw new IllegalArgumentException("perKeyLimit must be at least 1");
        this.perKeyLimit = perKeyLimit;
    }

    public synchronized void record(Observation observation) {
        ArrayDeque<Observation> entries = byKey.get(observation.getKey());
        if (entries == null) {
            entries = new ArrayDeque<>();
            byKey.put(observation.getKey(), entries);
        }
        entries.addLast(observation);
        while (entries.size() > perKeyLimit) entries.removeFirst();
    }

    public synchronized Observation latest(String key) {
        ArrayDeque<Observation> entries = byKey.get(key);
        return entries == null || entries.isEmpty() ? null : entries.peekLast();
    }

    /** Observations for the key with fromMillis <= time <= toMillis, oldest first. */
    public synchronized List<Observation> between(String key, long fromMillis, long toMillis) {
        List<Observation> matches = new ArrayList<>();
        ArrayDeque<Observation> entries = byKey.get(key);
        if (entries != null) {
            for (Observation observation : entries) {
                if (observation.getAtMillis() >= fromMillis && observation.getAtMillis() <= toMillis) matches.add(observation);
            }
        }
        return Collections.unmodifiableList(matches);
    }

    public synchronized int size(String key) {
        ArrayDeque<Observation> entries = byKey.get(key);
        return entries == null ? 0 : entries.size();
    }
}
