package com.hiveminemobile.ai.observation;

import com.hiveminemobile.ai.modules.VisionAI;

/**
 * Phase 041. The only path to a screen frame. Capture is refused unless the user has authorized
 * screen observation. The actual capture is supplied by the app layer (for HiveMine Mobile, its existing
 * screenshot code), so this class never reaches the screen itself.
 */
public final class ObservationSource {
    public enum Status { CAPTURED, NOT_AUTHORIZED, CAPTURE_FAILED }

    /** Supplies a frame. Implemented by the app layer. */
    public interface FrameProvider {
        VisionAI.Frame capture() throws Exception;
    }

    public static final class Capture {
        private final Status status;
        private final VisionAI.Frame frame;
        private final long atMillis;
        private final String reason;

        Capture(Status status, VisionAI.Frame frame, long atMillis, String reason) {
            this.status = status;
            this.frame = frame;
            this.atMillis = atMillis;
            this.reason = reason;
        }

        public Status getStatus() { return status; }
        /** Null unless the status is CAPTURED. */
        public VisionAI.Frame getFrame() { return frame; }
        public long getAtMillis() { return atMillis; }
        public String getReason() { return reason; }
    }

    private final FrameProvider provider;
    private boolean authorized;

    public ObservationSource(FrameProvider provider) {
        if (provider == null) throw new IllegalArgumentException("provider must not be null");
        this.provider = provider;
    }

    /** Called only from the user's own settings. */
    public synchronized void setAuthorized(boolean granted) {
        authorized = granted;
    }

    public synchronized boolean isAuthorized() {
        return authorized;
    }

    public synchronized Capture observe(long nowMillis) {
        if (!authorized) return new Capture(Status.NOT_AUTHORIZED, null, nowMillis, "screen observation is not authorized");
        try {
            VisionAI.Frame frame = provider.capture();
            if (frame == null) return new Capture(Status.CAPTURE_FAILED, null, nowMillis, "no frame returned");
            return new Capture(Status.CAPTURED, frame, nowMillis, "captured");
        } catch (Exception failure) {
            String message = failure.getMessage() == null ? failure.getClass().getSimpleName() : failure.getMessage();
            return new Capture(Status.CAPTURE_FAILED, null, nowMillis, message);
        }
    }
}
