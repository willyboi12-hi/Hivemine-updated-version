package com.hiveminemobile.ai.observation;

import com.hiveminemobile.ai.modules.QuestAI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Phase 046. Picks quest lines out of OCR lines and tracks them through QuestAI. Non-quest lines are skipped. */
public final class QuestReader {
    private final QuestAI quest;

    public QuestReader(QuestAI quest) {
        if (quest == null) throw new IllegalArgumentException("quest must not be null");
        this.quest = quest;
    }

    public List<QuestAI.Assessment> read(List<String> ocrLines, long nowMillis) {
        List<QuestAI.Assessment> found = new ArrayList<>();
        for (String line : ocrLines) {
            QuestAI.Assessment assessment = quest.observe(line, nowMillis);
            if (assessment.getStatus() != QuestAI.Status.UNREADABLE) found.add(assessment);
        }
        return Collections.unmodifiableList(found);
    }
}
