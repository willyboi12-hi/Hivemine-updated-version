package com.hiveminemobile.ai.observation;

import com.hiveminemobile.ai.modules.VisionAI;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Phase 043. Reads text from a frame region through an OCR engine and validates what comes back.
 * The engine is an interface: no OCR engine is bundled, so recognition accuracy is unverified until
 * a real engine is supplied. The parsers below are fully testable and reject anything malformed.
 */
public final class TextReader {
    /** A text recognizer, supplied by the app layer or a later phase. */
    public interface OcrEngine {
        OcrText read(VisionAI.Frame frame, VisionAI.Region region) throws Exception;
    }

    public static final class OcrText {
        private final String text;
        private final double confidence;

        public OcrText(String text, double confidence) {
            if (text == null) throw new IllegalArgumentException("text must not be null");
            if (!(confidence >= 0.0 && confidence <= 1.0)) throw new IllegalArgumentException("confidence must be 0-1");
            this.text = text;
            this.confidence = confidence;
        }
    }

    private static final Pattern COUNT = Pattern.compile("^(\\d+(?:\\.\\d+)?)([KMB]?)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern PERCENT = Pattern.compile("^(\\d{1,3})%?$");
    private static final Pattern FRACTION = Pattern.compile("^(\\d{1,9})/(\\d{1,9})$");
    private static final Pattern DURATION = Pattern.compile("^(\\d{1,2}):(\\d{2})(?::(\\d{2}))?$");

    private final OcrEngine engine;
    private final double minimumConfidence;

    public TextReader(OcrEngine engine, double minimumConfidence) {
        if (engine == null) throw new IllegalArgumentException("engine must not be null");
        if (!(minimumConfidence >= 0.0 && minimumConfidence <= 1.0)) throw new IllegalArgumentException("minimum must be 0-1");
        this.engine = engine;
        this.minimumConfidence = minimumConfidence;
    }

    /** The recognized text, or null when the engine fails or is not confident enough. */
    public String readText(VisionAI.Frame frame, VisionAI.Region region) {
        try {
            OcrText result = engine.read(frame, region);
            if (result == null || result.confidence < minimumConfidence) return null;
            return result.text.trim();
        } catch (Exception failure) {
            return null;
        }
    }

    /** "1,234" -> 1234, "1.2K" -> 1200, "3M" -> 3000000. Null when not a count. */
    public static Long parseCount(String text) {
        if (text == null) return null;
        Matcher m = COUNT.matcher(text.trim().replace(",", ""));
        if (!m.matches()) return null;
        double base = Double.parseDouble(m.group(1));
        String suffix = m.group(2).toUpperCase();
        double multiplier = suffix.equals("K") ? 1e3 : suffix.equals("M") ? 1e6 : suffix.equals("B") ? 1e9 : 1.0;
        double value = Math.round(base * multiplier);
        return value > Long.MAX_VALUE ? null : (long) value;
    }

    /** "72%" or "72" -> 72, 0 to 100 only. Null otherwise. */
    public static Integer parsePercent(String text) {
        if (text == null) return null;
        Matcher m = PERCENT.matcher(text.trim());
        if (!m.matches()) return null;
        int value = Integer.parseInt(m.group(1));
        return value <= 100 ? value : null;
    }

    /** "45/100" -> {45, 100} with numerator not above denominator and denominator at least 1. Null otherwise. */
    public static int[] parseFraction(String text) {
        if (text == null) return null;
        Matcher m = FRACTION.matcher(text.trim());
        if (!m.matches()) return null;
        int numerator = Integer.parseInt(m.group(1));
        int denominator = Integer.parseInt(m.group(2));
        if (denominator < 1 || numerator > denominator) return null;
        return new int[] {numerator, denominator};
    }

    /** "3:20" -> 200000 ms, "1:00:00" -> 3600000 ms. Minutes and seconds must be under 60. Null otherwise. */
    public static Long parseDurationMillis(String text) {
        if (text == null) return null;
        Matcher m = DURATION.matcher(text.trim());
        if (!m.matches()) return null;
        int first = Integer.parseInt(m.group(1));
        int second = Integer.parseInt(m.group(2));
        if (m.group(3) == null) {
            if (second >= 60) return null;
            return (first * 60L + second) * 1000L;
        }
        int third = Integer.parseInt(m.group(3));
        if (second >= 60 || third >= 60) return null;
        return (first * 3600L + second * 60L + third) * 1000L;
    }
}
