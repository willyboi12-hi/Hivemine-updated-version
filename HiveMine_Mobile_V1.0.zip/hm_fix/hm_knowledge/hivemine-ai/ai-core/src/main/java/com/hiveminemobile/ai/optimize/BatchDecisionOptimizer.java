package com.hiveminemobile.ai.optimize;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import java.util.List;
/** Phase 086 — Collapses a streak of identical goals to one action. */
public final class BatchDecisionOptimizer {
    public ManagerGoal collapse(List<ManagerGoal> recent) {
        if (recent == null || recent.isEmpty()) return ManagerGoal.STANDBY;
        ManagerGoal last = recent.get(recent.size() - 1);
        int streak = 0;
        for (int i = recent.size() - 1; i >= 0; i--) {
            if (recent.get(i) == last) streak++;
            else break;
        }
        // Need at least 2 agreeing samples before leaving STANDBY noise
        if (last != ManagerGoal.STANDBY && streak < 2 && recent.size() > 1) {
            return ManagerGoal.STANDBY;
        }
        return last;
    }
}
