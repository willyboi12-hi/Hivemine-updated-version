package com.hiveminemobile.ai.optimize;
/** Phase 083 — Suggests next allowed time with jittered spacing. */
public final class CooldownOptimizer {
    private final double minFactor;
    private final double maxFactor;
    public CooldownOptimizer(double minFactor, double maxFactor) {
        this.minFactor = minFactor <= 0 ? 0.9 : minFactor;
        this.maxFactor = maxFactor < this.minFactor ? this.minFactor : maxFactor;
    }
    public long nextAllowedMs(long lastMs, long baseCooldownMs, double random01) {
        double r = Math.max(0, Math.min(1, random01));
        double f = minFactor + (maxFactor - minFactor) * r;
        return lastMs + (long) (baseCooldownMs * f);
    }
    public boolean ready(long nowMs, long nextAllowedMs) { return nowMs >= nextAllowedMs; }
}
