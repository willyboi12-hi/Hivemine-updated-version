package com.hiveminemobile.ai.optimize;
/** Phase 088 — Tunable knobs for the optimization engine. */
public final class OptimizationPolicy {
    public long observationTtlMs = 750;
    public int budgetPerWindow = 20;
    public double loadNormal = 0.7;
    public double loadHigh = 0.9;
    public double cooldownMin = 0.9;
    public double cooldownMax = 1.1;
    public boolean batchDecisions = true;
}
