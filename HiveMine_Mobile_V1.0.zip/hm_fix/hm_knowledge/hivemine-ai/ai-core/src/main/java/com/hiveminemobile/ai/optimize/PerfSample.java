package com.hiveminemobile.ai.optimize;
/** Phase 081 — One timed sample. */
public final class PerfSample {
    public final String name;
    public final long durationMs;
    public PerfSample(String name, long durationMs) {
        this.name = name == null ? "" : name;
        this.durationMs = Math.max(0, durationMs);
    }
}
