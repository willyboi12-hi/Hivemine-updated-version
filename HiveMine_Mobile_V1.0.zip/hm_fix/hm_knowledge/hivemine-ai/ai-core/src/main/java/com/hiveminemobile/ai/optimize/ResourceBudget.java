package com.hiveminemobile.ai.optimize;
/** Phase 084 — Token budget for expensive AI work per window. */
public final class ResourceBudget {
    private final int capacity;
    private int remaining;
    public ResourceBudget(int capacity) {
        this.capacity = Math.max(0, capacity);
        this.remaining = this.capacity;
    }
    public int remaining() { return remaining; }
    public int capacity() { return capacity; }
    public boolean trySpend(int amount) {
        if (amount < 0 || amount > remaining) return false;
        remaining -= amount;
        return true;
    }
    public void refill() { remaining = capacity; }
}
