package com.hiveminemobile.ai.performance;

/** Phase 099: memory samples and the peak seen. The source is injected so tests do not depend on the JVM. */
public final class MemoryUsageAnalyzer {
    public interface Source { long usedBytes(); }

    public static Source runtime() {
        return () -> { Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); };
    }

    private final Source source;
    private long peak;

    public MemoryUsageAnalyzer(Source source) { this.source = source; }

    public synchronized long sample() {
        long used = source.usedBytes();
        if (used > peak) peak = used;
        return used;
    }

    public synchronized long peak() { return peak; }
}
