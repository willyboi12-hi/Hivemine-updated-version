package com.hiveminemobile.ai.performance;

/** Phase 099: compares a measurement with its baseline. A missing baseline is reported, not treated as a pass. */
public final class PerformanceRegressionDetector {
    public enum Verdict { OK, REGRESSION, NO_BASELINE }

    public static Verdict compare(double currentMillis, Double baselineMillis, double tolerance) {
        if (baselineMillis == null || baselineMillis.isNaN()) return Verdict.NO_BASELINE;
        return currentMillis > baselineMillis * (1.0 + tolerance) ? Verdict.REGRESSION : Verdict.OK;
    }
}
