package com.hiveminemobile.ai.performance;

import java.util.*;

/** Phase 099: background jobs that are running. Jobs not on the allowed list are reported as unnecessary work. */
public final class ResourceConsumptionTracker {
    private final Map<String, Integer> active = new TreeMap<>();

    public synchronized void start(String job) { active.merge(job, 1, Integer::sum); }

    public synchronized void stop(String job) {
        Integer n = active.get(job);
        if (n == null) return;
        if (n <= 1) active.remove(job); else active.put(job, n - 1);
    }

    public synchronized int activeCount() {
        int total = 0;
        for (int n : active.values()) total += n;
        return total;
    }

    public synchronized List<String> unnecessary(Set<String> allowed) {
        List<String> out = new ArrayList<>();
        for (String job : active.keySet()) if (!allowed.contains(job)) out.add(job);
        return out;
    }
}
