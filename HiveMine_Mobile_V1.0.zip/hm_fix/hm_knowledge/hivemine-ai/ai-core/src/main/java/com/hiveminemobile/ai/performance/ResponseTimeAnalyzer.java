package com.hiveminemobile.ai.performance;

import java.util.*;

/** Phase 099: response-time samples and percentiles. */
public final class ResponseTimeAnalyzer {
    private final List<Long> nanos = new ArrayList<>();

    public synchronized void record(long elapsedNanos) { if (elapsedNanos >= 0) nanos.add(elapsedNanos); }

    public synchronized int count() { return nanos.size(); }

    /** Nearest-rank percentile in milliseconds. NaN when there are no samples. */
    public synchronized double percentileMillis(double p) {
        if (nanos.isEmpty() || p <= 0 || p > 100) return Double.NaN;
        List<Long> s = new ArrayList<>(nanos);
        Collections.sort(s);
        int rank = (int) Math.ceil(p / 100.0 * s.size());
        return s.get(Math.max(0, Math.min(s.size() - 1, rank - 1))) / 1_000_000.0;
    }

    public synchronized double maxMillis() {
        if (nanos.isEmpty()) return Double.NaN;
        return Collections.max(nanos) / 1_000_000.0;
    }
}
