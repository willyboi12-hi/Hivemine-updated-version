package com.hiveminemobile.ai.performance;

import java.util.*;

/**
 * Phase 099: measures HiveMine AI against documented targets. Speed measurements never count as a pass
 * when the correctness check behind them fails.
 */
public final class SystemPerformanceValidationManager {
    /** Documented targets. Changing one should be a reviewed decision, not a test fix. */
    public static final double INIT_P95_TARGET_MS = 500.0;
    public static final double RESPONSE_P95_TARGET_MS = 50.0;
    public static final double WORKLOAD_TARGET_MS = 5000.0;

    /** A realistic workload. It returns true only when every result was correct. */
    public interface Workload { boolean run(); }

    public static final class Measurement {
        public final String name; public final double valueMillis, targetMillis; public final boolean correct;
        Measurement(String n, double v, double t, boolean c) { name = n; valueMillis = v; targetMillis = t; correct = c; }
        public boolean passed() { return correct && valueMillis <= targetMillis; }
        @Override public String toString() {
            return (passed() ? "PASS " : "FAIL ") + name + ": " + String.format(Locale.ROOT, "%.2f", valueMillis)
                + " ms (target " + targetMillis + " ms, correct=" + correct + ")";
        }
    }

    public Measurement measureInit(String name, Runnable init, int runs) {
        ResponseTimeAnalyzer a = new ResponseTimeAnalyzer();
        for (int i = 0; i < runs; i++) { long t = System.nanoTime(); init.run(); a.record(System.nanoTime() - t); }
        return new Measurement(name, a.percentileMillis(95), INIT_P95_TARGET_MS, true);
    }

    public Measurement measureResponse(String name, java.util.function.BooleanSupplier op, int runs) {
        ResponseTimeAnalyzer a = new ResponseTimeAnalyzer();
        boolean correct = true;
        for (int i = 0; i < runs; i++) {
            long t = System.nanoTime();
            if (!op.getAsBoolean()) correct = false;
            a.record(System.nanoTime() - t);
        }
        return new Measurement(name, a.percentileMillis(95), RESPONSE_P95_TARGET_MS, correct);
    }

    public Measurement measureWorkload(String name, Workload w) {
        long t = System.nanoTime();
        boolean correct = w.run();
        return new Measurement(name, (System.nanoTime() - t) / 1_000_000.0, WORKLOAD_TARGET_MS, correct);
    }

    public String report(List<Measurement> ms) {
        StringBuilder b = new StringBuilder("Performance against documented targets\n");
        for (Measurement m : ms) b.append(m).append('\n');
        return b.toString();
    }
}
