package com.hiveminemobile.ai.phases;

import com.hiveminemobile.ai.decision.PowerDecisionEngine;
import com.hiveminemobile.ai.merge.SpecialistCatalogFactory;
import com.hiveminemobile.ai.modules.BaseSpecialist;
import com.hiveminemobile.ai.modules.SignalIntelligence;

import java.util.HashMap;
import java.util.List;

/** Executes lightweight verification for any phase number 1-250. */
public final class PhaseExecutor {
    public static final class Result {
        public final int phase;
        public final boolean ok;
        public final String detail;
        public Result(int phase, boolean ok, String detail) {
            this.phase = phase; this.ok = ok; this.detail = detail == null ? "" : detail;
        }
    }

    public Result verify(int phaseNumber) {
        PhaseCatalog.Phase p = PhaseCatalog.get(phaseNumber);
        if (p == null) return new Result(phaseNumber, false, "unknown phase");
        try {
            if ("SPECIALIST".equals(p.domain) || "SPECIALIST_DEPTH".equals(p.domain)) {
                List<BaseSpecialist> all = new SpecialistCatalogFactory().all();
                if (all.size() < 20) return new Result(phaseNumber, false, "specialists < 20");
            }
            if ("MANAGER_INTEL".equals(p.domain) || "MANAGER".equals(p.domain)) {
                PowerDecisionEngine eng = new PowerDecisionEngine();
                PowerDecisionEngine.Factors f = new PowerDecisionEngine.Factors();
                f.userWantsFarm = true;
                f.pollenRate = 0.8;
                if (eng.decide(f, null) == null) return new Result(phaseNumber, false, "no decision");
            }
            if ("DATA".equals(p.domain)) {
                HashMap<String, Double> m = new HashMap<String, Double>();
                m.put("a", 1.0);
                m.put("b", 2.0);
                if (SignalIntelligence.rankedKeys(m).isEmpty()) return new Result(phaseNumber, false, "rank empty");
            }
            Class.forName(p.implementorClass);
            return new Result(phaseNumber, true, p.name);
        } catch (ClassNotFoundException e) {
            return new Result(phaseNumber, false, "missing " + p.implementorClass);
        } catch (Throwable t) {
            return new Result(phaseNumber, false, t.getClass().getSimpleName());
        }
    }

    public int verifyAll() {
        int ok = 0;
        for (int i = 1; i <= 250; i++) if (verify(i).ok) ok++;
        return ok;
    }
}
