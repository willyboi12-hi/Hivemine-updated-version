package com.hiveminemobile.ai.registry;

import java.util.*;

/** Phase 091: an identifier and the responsibilities one specialist AI system supports. */
public final class AISystemDescriptor {
    public final String id;
    public final List<String> capabilities;

    AISystemDescriptor(String id, List<String> caps) {
        this.id = id.trim();
        Set<String> c = new LinkedHashSet<>();
        for (String s : caps) c.add(s.trim());
        this.capabilities = Collections.unmodifiableList(new ArrayList<>(c));
    }
}
