package com.hiveminemobile.ai.registry;

/** Phase 091: one registered system and where it is in its lifecycle. */
public final class AISystemRegistration {
    public enum Lifecycle { REGISTERED, INITIALIZED, SHUT_DOWN }

    public final AISystemDescriptor descriptor;
    public final long registeredAtMillis;
    private Lifecycle lifecycle = Lifecycle.REGISTERED;

    AISystemRegistration(AISystemDescriptor d, long at) { descriptor = d; registeredAtMillis = at; }

    public synchronized Lifecycle lifecycle() { return lifecycle; }
    synchronized void setLifecycle(Lifecycle l) { lifecycle = l; }
}
