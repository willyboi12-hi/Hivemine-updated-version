package com.hiveminemobile.ai.registry;

import java.util.*;

/** Phase 091: whether each system is currently available, and when that last changed. */
public final class SystemAvailabilityTracker {
    private final Map<String, Boolean> available = new TreeMap<>();
    private final Map<String, Long> changedAt = new TreeMap<>();

    public synchronized void set(String systemId, boolean on, long now) {
        Boolean old = available.get(systemId);
        available.put(systemId, on);
        if (old == null || old != on) changedAt.put(systemId, now);
    }

    /** Unknown systems are not available. */
    public synchronized boolean isAvailable(String systemId) { return Boolean.TRUE.equals(available.get(systemId)); }

    public synchronized Long lastChange(String systemId) { return changedAt.get(systemId); }

    public synchronized void forget(String systemId) { available.remove(systemId); changedAt.remove(systemId); }
}
