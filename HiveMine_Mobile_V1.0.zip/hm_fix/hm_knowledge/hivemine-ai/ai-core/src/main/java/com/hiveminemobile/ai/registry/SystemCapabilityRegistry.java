package com.hiveminemobile.ai.registry;

import java.util.*;

/** Phase 091: which systems support which capability. */
public final class SystemCapabilityRegistry {
    private final Map<String, Set<String>> byCapability = new TreeMap<>();

    public synchronized void add(String systemId, List<String> caps) {
        for (String c : caps) byCapability.computeIfAbsent(c, k -> new TreeSet<>()).add(systemId);
    }

    public synchronized void remove(String systemId) {
        for (Set<String> s : byCapability.values()) s.remove(systemId);
    }

    public synchronized List<String> systemsFor(String capability) {
        Set<String> s = byCapability.get(capability);
        return s == null ? Collections.<String>emptyList() : new ArrayList<>(s);
    }

    public synchronized Set<String> capabilities() { return new TreeSet<>(byCapability.keySet()); }
}
