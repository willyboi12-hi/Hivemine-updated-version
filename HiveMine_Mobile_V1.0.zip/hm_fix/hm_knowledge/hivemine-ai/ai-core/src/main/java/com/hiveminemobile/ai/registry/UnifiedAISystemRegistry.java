package com.hiveminemobile.ai.registry;

import java.util.*;

/**
 * Phase 091: the one place that knows which specialist AI systems exist, what they can do,
 * and whether they are initialized, available, or shut down. Manager AI reads this to decide.
 */
public final class UnifiedAISystemRegistry {
    public enum Result { REGISTERED, DUPLICATE, INVALID }

    private final Map<String, AISystemRegistration> systems = new TreeMap<>();
    private final SystemCapabilityRegistry capabilities = new SystemCapabilityRegistry();
    private final SystemAvailabilityTracker availability = new SystemAvailabilityTracker();

    public synchronized Result register(String id, List<String> caps, long now) {
        if (blank(id) || caps == null || caps.isEmpty()) return Result.INVALID;
        for (String c : caps) if (blank(c)) return Result.INVALID;
        String key = id.trim();
        if (systems.containsKey(key)) return Result.DUPLICATE;
        AISystemRegistration reg = new AISystemRegistration(new AISystemDescriptor(key, caps), now);
        systems.put(key, reg);
        capabilities.add(key, reg.descriptor.capabilities);
        availability.set(key, false, now);
        return Result.REGISTERED;
    }

    /** A system is usable only after it is initialized. */
    public synchronized boolean markInitialized(String id, long now) {
        AISystemRegistration r = systems.get(id);
        if (r == null || r.lifecycle() != AISystemRegistration.Lifecycle.REGISTERED) return false;
        r.setLifecycle(AISystemRegistration.Lifecycle.INITIALIZED);
        availability.set(id, true, now);
        return true;
    }

    public synchronized boolean setAvailable(String id, boolean on, long now) {
        AISystemRegistration r = systems.get(id);
        if (r == null || r.lifecycle() == AISystemRegistration.Lifecycle.SHUT_DOWN) return false;
        availability.set(id, on, now);
        return true;
    }

    /** Returns true only the first time. A shut-down system stays registered, so it cannot be re-registered. */
    public synchronized boolean shutdown(String id, long now) {
        AISystemRegistration r = systems.get(id);
        if (r == null || r.lifecycle() == AISystemRegistration.Lifecycle.SHUT_DOWN) return false;
        r.setLifecycle(AISystemRegistration.Lifecycle.SHUT_DOWN);
        availability.set(id, false, now);
        return true;
    }

    public synchronized boolean isUsable(String id) {
        AISystemRegistration r = systems.get(id);
        return r != null && r.lifecycle() == AISystemRegistration.Lifecycle.INITIALIZED && availability.isAvailable(id);
    }

    public synchronized List<String> availableFor(String capability) {
        List<String> out = new ArrayList<>();
        for (String id : capabilities.systemsFor(capability)) if (isUsable(id)) out.add(id);
        return out;
    }

    /** Capabilities that at least one usable system supports. The scheduler dispatches only these. */
    public synchronized Set<String> usableCapabilities() {
        Set<String> out = new TreeSet<>();
        for (String cap : capabilities.capabilities()) if (!availableFor(cap).isEmpty()) out.add(cap);
        return out;
    }

    public synchronized List<String> statusReport() {
        List<String> out = new ArrayList<>();
        for (AISystemRegistration r : systems.values())
            out.add(r.descriptor.id + ": " + r.lifecycle() + ", available=" + isUsable(r.descriptor.id)
                + ", capabilities=" + r.descriptor.capabilities);
        return out;
    }

    public synchronized int size() { return systems.size(); }

    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
