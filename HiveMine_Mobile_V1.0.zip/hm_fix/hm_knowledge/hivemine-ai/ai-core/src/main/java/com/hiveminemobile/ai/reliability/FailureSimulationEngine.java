package com.hiveminemobile.ai.reliability;

import com.hiveminemobile.ai.adaptive.AdaptiveConfigurationEngine;
import com.hiveminemobile.ai.android.*;
import com.hiveminemobile.ai.crosssystem.*;
import com.hiveminemobile.ai.history.HistoricalPerformanceAnalyzer;
import com.hiveminemobile.ai.monitor.*;
import com.hiveminemobile.ai.registry.UnifiedAISystemRegistry;
import com.hiveminemobile.ai.scheduling.IntelligentTaskScheduler;
import com.hiveminemobile.ai.scheduling.ScheduledTask;
import java.util.*;

import static com.hiveminemobile.ai.reliability.RecoveryValidationSuite.require;

/** Phase 098: builds the standard failure scenarios. Each scenario uses fresh objects, so they do not affect each other. */
public final class FailureSimulationEngine {
    public static List<SystemFailureScenario> standard() {
        List<SystemFailureScenario> s = new ArrayList<>();
        s.add(new SystemFailureScenario("unavailable specialist",
            "a usable system goes down: work waits, is reported, and runs after recovery", () -> {
            UnifiedAISystemRegistry reg = new UnifiedAISystemRegistry();
            reg.register("farm", Collections.singletonList("farming"), 0);
            reg.markInitialized("farm", 0);
            IntelligentTaskScheduler sch = new IntelligentTaskScheduler(reg, 10, 60_000);
            sch.submit("t1", "farming", 5, Collections.<String>emptyList(), 0);
            reg.setAvailable("farm", false, 1);
            require(sch.next(2) == null, "task dispatched to a system that is down");
            require(sch.state("t1").state() == ScheduledTask.State.QUEUED, "task lost while waiting");
            require(sch.report().lines().get(sch.report().lines().size() - 1).contains("WAITING"), "wait was not reported");
            reg.setAvailable("farm", true, 3);
            require(sch.next(4) != null, "task did not run after recovery");
        }));
        s.add(new SystemFailureScenario("malformed messages",
            "malformed and misrouted messages are refused and never reach a handler", () -> {
            CrossSystemCommunicationManager m = new CrossSystemCommunicationManager(1000, null);
            m.register("manager", msg -> { throw new AssertionError("malformed message was delivered"); });
            require(m.send(new CrossSystemMessage("", null, "quest", "manager", "REQUEST", "x", 0), 0)
                == CrossSystemCommunicationManager.SendResult.MALFORMED, "blank id accepted");
            require(m.send(new CrossSystemMessage("m1", null, "quest", "nowhere", "REQUEST", "x", 0), 0)
                == CrossSystemCommunicationManager.SendResult.UNKNOWN_DESTINATION, "unknown destination accepted");
            require(m.send(new CrossSystemMessage("m2", null, "quest", "manager", "RESPONSE", "x", 0), 0)
                == CrossSystemCommunicationManager.SendResult.MALFORMED, "response without request id accepted");
        }));
        s.add(new SystemFailureScenario("communication timeout",
            "a message that is never delivered is reported to Manager AI as timed out", () -> {
            List<String> reported = new ArrayList<>();
            CrossSystemCommunicationManager m = new CrossSystemCommunicationManager(1000, (id, why) -> reported.add(id + " " + why));
            m.register("farm", msg -> { });
            require(m.send(new CrossSystemMessage("m3", null, "manager", "farm", "REQUEST", "x", 0), 0)
                == CrossSystemCommunicationManager.SendResult.SENT, "valid message not sent");
            require(m.tick(500).isEmpty(), "timed out before the deadline");
            require(m.tick(1500).equals(Collections.singletonList("m3")), "timeout not detected");
            require(reported.contains("m3 timed out"), "timeout not reported to Manager AI");
        }));
        s.add(new SystemFailureScenario("handler failure",
            "a handler that throws is marked FAILED, reported, and logged", () -> {
            List<String> reported = new ArrayList<>();
            CrossSystemCommunicationManager m = new CrossSystemCommunicationManager(1000, (id, why) -> reported.add(id));
            m.register("quest", msg -> { throw new IllegalStateException("boom"); });
            m.send(new CrossSystemMessage("m4", null, "manager", "quest", "REQUEST", "x", 0), 0);
            require(m.deliver("m4", 1) == CrossSystemCommunicationManager.DeliveryResult.HANDLER_FAILED, "failure not reported as failed");
            require(m.stateOf("m4") == MessageDeliveryTracker.State.FAILED, "state not FAILED");
            require(reported.contains("m4"), "failure not sent to Manager AI");
            require(m.logEntries().get(m.logEntries().size() - 1).contains("FAILED m4"), "failure not logged");
        }));
        s.add(new SystemFailureScenario("duplicate processing",
            "a delivered message is never processed a second time", () -> {
            int[] calls = {0};
            CrossSystemCommunicationManager m = new CrossSystemCommunicationManager(1000, null);
            m.register("farm", msg -> calls[0]++);
            m.send(new CrossSystemMessage("m5", null, "manager", "farm", "REQUEST", "x", 0), 0);
            m.deliver("m5", 1);
            require(m.deliver("m5", 2) == CrossSystemCommunicationManager.DeliveryResult.DUPLICATE_PROCESSED, "second delivery not refused");
            require(calls[0] == 1, "handler ran " + calls[0] + " times");
        }));
        s.add(new SystemFailureScenario("configuration failure",
            "a failed write leaves the stored settings unchanged and records no backup", () -> {
            Map<String, String> stored = new TreeMap<>();
            stored.put("speed", "1");
            AndroidConfigurationSyncManager sync = new AndroidConfigurationSyncManager(new AndroidConfigurationSyncManager.Store() {
                public Map<String, String> read() { return new TreeMap<>(stored); }
                public void write(Map<String, String> v) { throw new RuntimeException("disk full"); }
            });
            Map<String, String> profile = new TreeMap<>();
            profile.put("speed", "2");
            require(sync.sync(profile) == AndroidConfigurationSyncManager.Result.FAILED, "write failure not reported");
            require("1".equals(stored.get("speed")), "stored settings changed");
            require(sync.backupCount() == 0, "backup kept after failed write");
        }));
        s.add(new SystemFailureScenario("interrupted task",
            "a task that stops reporting is marked stalled, Recovery AI is told, and a later failure is recorded", () -> {
            List<String> recovered = new ArrayList<>();
            UnifiedExecutionMonitor mon = new UnifiedExecutionMonitor(1000, (id, at) -> recovered.add(id));
            mon.receive(new ExecutionEventListener.ExecutionEvent("t9", ExecutionEventListener.ExecutionEvent.Type.ACCEPTED, 0));
            mon.receive(new ExecutionEventListener.ExecutionEvent("t9", ExecutionEventListener.ExecutionEvent.Type.STARTED, 0));
            require(mon.sweep(500).isEmpty(), "stalled before the limit");
            require(mon.sweep(1500).equals(Collections.singletonList("t9")), "stall not detected");
            require(recovered.equals(Collections.singletonList("t9")), "Recovery AI not notified");
            require("STALLED".equals(mon.statusOf("t9")), "status not STALLED");
            mon.receive(new ExecutionEventListener.ExecutionEvent("t9", ExecutionEventListener.ExecutionEvent.Type.FAILED, 1600));
            require("FAILED".equals(mon.statusOf("t9")), "later failure not recorded");
        }));
        s.add(new SystemFailureScenario("application restart",
            "after a restart with integration not ready, the AI stays stopped and restores nothing", () -> {
            AndroidIntegrationManager notReady = new AndroidIntegrationManager();
            AndroidLifecycleController c = new AndroidLifecycleController(notReady);
            require(!c.start(), "started without integration");
            require(c.state() == AndroidLifecycleController.State.STOPPED, "not stopped after restart");
            require(c.restoreAfterRestart().isEmpty(), "restored state while integration is not ready");
        }));
        s.add(new SystemFailureScenario("corrupted stored records",
            "a corrupted record is counted as incomplete and does not crash the analysis", () -> {
            List<com.hiveminemobile.ai.memory.DecisionRecord> records = new ArrayList<>();
            records.add(null);
            HistoricalPerformanceAnalyzer.Report r = new HistoricalPerformanceAnalyzer().analyze(records);
            require(r.incomplete == 1, "corrupted record not counted");
            require(r.byCapability.isEmpty(), "corrupted record was counted as data");
        }));
        s.add(new SystemFailureScenario("recovery limits",
            "recovery stops after its limit and reports that the limit was reached", () -> {
            RecoveryValidationSuite.RetryLimiter lim = new RecoveryValidationSuite.RetryLimiter(3);
            require(lim.attempt() && lim.attempt() && lim.attempt(), "fewer than 3 attempts allowed");
            require(!lim.attempt(), "fourth attempt allowed");
            require(lim.exhausted() && lim.used() == 3, "limit state not reported");
        }));
        s.add(new SystemFailureScenario("safe shutdown",
            "a shut-down system is no longer dispatched, cannot be re-registered, and its work is reported", () -> {
            UnifiedAISystemRegistry reg = new UnifiedAISystemRegistry();
            reg.register("quest", Collections.singletonList("quest"), 0);
            reg.markInitialized("quest", 0);
            IntelligentTaskScheduler sch = new IntelligentTaskScheduler(reg, 10, 60_000);
            sch.submit("q1", "quest", 1, Collections.<String>emptyList(), 0);
            require(reg.shutdown("quest", 1), "shutdown not applied");
            require(!reg.shutdown("quest", 2), "second shutdown applied");
            require(sch.next(3) == null, "dispatched to a shut-down system");
            require(reg.register("quest", Collections.singletonList("quest"), 4)
                == UnifiedAISystemRegistry.Result.DUPLICATE, "shut-down system re-registered");
            require(sch.report().lines().get(sch.report().lines().size() - 1).contains("WAITING"), "shutdown wait not reported");
        }));
        return s;
    }

}
