package com.hiveminemobile.ai.reliability;

import java.util.*;

/** Phase 098: runs failure scenarios. Each scenario is reported PASS or FAIL. A FAIL is never hidden. */
public final class RecoveryValidationSuite {
    public static final class Outcome {
        public final String name; public final boolean passed; public final String detail;
        Outcome(String n, boolean p, String d) { name = n; passed = p; detail = d; }
    }

    /** Limits how many times a recovery may be attempted, so recovery cannot loop forever. */
    public static final class RetryLimiter {
        private final int max;
        private int used;
        public RetryLimiter(int max) { if (max < 1) throw new IllegalArgumentException("max must be positive"); this.max = max; }
        /** Returns false once the limit is reached. Refused attempts are visible through exhausted(). */
        public synchronized boolean attempt() { if (used >= max) return false; used++; return true; }
        public synchronized boolean exhausted() { return used >= max; }
        public synchronized int used() { return used; }
    }

    public static void require(boolean ok, String message) { if (!ok) throw new AssertionError(message); }

    public List<Outcome> run(List<SystemFailureScenario> scenarios) {
        List<Outcome> out = new ArrayList<>();
        for (SystemFailureScenario s : scenarios) {
            try {
                s.check.run();
                out.add(new Outcome(s.name, true, "ok"));
            } catch (AssertionError e) {
                out.add(new Outcome(s.name, false, e.getMessage() == null ? "assertion failed" : e.getMessage()));
            } catch (Exception e) {
                out.add(new Outcome(s.name, false, "unexpected " + e));
            }
        }
        return out;
    }
}
