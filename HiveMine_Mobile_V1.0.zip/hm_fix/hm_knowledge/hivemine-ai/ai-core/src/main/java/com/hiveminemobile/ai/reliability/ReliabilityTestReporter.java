package com.hiveminemobile.ai.reliability;

import java.util.*;

/** Phase 098: text report. Unresolved failures are listed by name, not counted away. */
public final class ReliabilityTestReporter {
    public String toText(List<RecoveryValidationSuite.Outcome> outcomes) {
        StringBuilder b = new StringBuilder("Reliability scenarios\n");
        int failed = 0;
        for (RecoveryValidationSuite.Outcome o : outcomes) {
            b.append(o.passed ? "PASS  " : "FAIL  ").append(o.name);
            if (!o.passed) { b.append(" - ").append(o.detail); failed++; }
            b.append('\n');
        }
        b.append(outcomes.size() - failed).append(" passed, ").append(failed).append(" failed\n");
        return b.toString();
    }

    public List<String> unresolved(List<RecoveryValidationSuite.Outcome> outcomes) {
        List<String> out = new ArrayList<>();
        for (RecoveryValidationSuite.Outcome o : outcomes) if (!o.passed) out.add(o.name + ": " + o.detail);
        return out;
    }
}
