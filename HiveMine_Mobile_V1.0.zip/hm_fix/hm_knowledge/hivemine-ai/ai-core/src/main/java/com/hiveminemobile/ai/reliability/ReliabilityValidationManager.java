package com.hiveminemobile.ai.reliability;

import java.util.List;

/** Phase 098: runs the standard failure scenarios and returns the outcomes. */
public final class ReliabilityValidationManager {
    public List<RecoveryValidationSuite.Outcome> runStandard() {
        return new RecoveryValidationSuite().run(FailureSimulationEngine.standard());
    }
}
