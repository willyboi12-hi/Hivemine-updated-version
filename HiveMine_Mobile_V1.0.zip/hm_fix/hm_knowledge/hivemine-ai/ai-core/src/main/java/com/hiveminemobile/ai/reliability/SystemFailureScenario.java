package com.hiveminemobile.ai.reliability;

/** Phase 098: one named failure to simulate. The check throws AssertionError or any exception when the system misbehaves. */
public final class SystemFailureScenario {
    public interface Check { void run() throws Exception; }

    public final String name, description;
    final Check check;

    public SystemFailureScenario(String name, String description, Check check) {
        this.name = name; this.description = description; this.check = check;
    }
}
