package com.hiveminemobile.ai.scheduling;

import com.hiveminemobile.ai.registry.UnifiedAISystemRegistry;
import java.util.*;

/**
 * Phase 092: orders work from Manager AI by priority, dependencies, and which systems are usable.
 * Work that cannot run yet waits, expires visibly after maxWait, or fails visibly when a dependency fails.
 */
public final class IntelligentTaskScheduler {
    private final UnifiedAISystemRegistry registry;
    private final TaskQueueManager queue;
    private final TaskCancellationController cancellation;
    private final TaskSchedulingReport report = new TaskSchedulingReport();

    public IntelligentTaskScheduler(UnifiedAISystemRegistry registry, int capacity, long maxWaitMillis) {
        this.registry = registry;
        this.queue = new TaskQueueManager(capacity, maxWaitMillis);
        this.cancellation = new TaskCancellationController(queue);
    }

    public synchronized TaskQueueManager.Result submit(String id, String capability, int priority, List<String> deps, long now) {
        TaskQueueManager.Result r = queue.enqueue(id, capability, priority, deps, now);
        report.record(now, String.valueOf(id), "SUBMIT:" + r, capability);
        return r;
    }

    /** Expires and fails tasks that cannot run, then returns the next task to dispatch, or null. */
    public synchronized ScheduledTask next(long now) {
        for (ScheduledTask t : queue.expire(now)) report.record(now, t.id, "EXPIRED", t.reason());
        for (ScheduledTask t : queue.failBlocked()) report.record(now, t.id, "FAILED", t.reason());
        ScheduledTask t = queue.pollNext(registry.usableCapabilities(), now);
        if (t != null) report.record(now, t.id, "DISPATCHED", t.capability);
        else if (queue.queued() > 0) report.record(now, "-", "WAITING", queue.queued() + " queued, none runnable yet");
        return t;
    }

    public synchronized boolean complete(String id, boolean ok, String reason, long now) {
        boolean done = queue.finish(id, ok, reason);
        report.record(now, String.valueOf(id), done ? (ok ? "DONE" : "FAILED") : "COMPLETE_REFUSED", reason);
        return done;
    }

    public synchronized TaskCancellationController.Result cancel(String id, long now) {
        TaskCancellationController.Result r = cancellation.cancel(id);
        report.record(now, String.valueOf(id), "CANCEL:" + r, null);
        return r;
    }

    public synchronized ScheduledTask state(String id) { return queue.get(id); }
    public synchronized TaskSchedulingReport report() { return report; }
    public synchronized int queued() { return queue.queued(); }
}
