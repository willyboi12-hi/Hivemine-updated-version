package com.hiveminemobile.ai.scheduling;

import java.util.*;

/** Phase 092: one task waiting for, or running on, a specialist system. */
public final class ScheduledTask {
    public enum State { QUEUED, RUNNING, DONE, FAILED, CANCELLED, EXPIRED }

    public final String id, capability;
    public final int priority;
    public final List<String> dependencies;
    public final long enqueuedAtMillis;
    State state = State.QUEUED;
    String reason = "";

    ScheduledTask(String id, String capability, int priority, List<String> deps, long at) {
        this.id = id; this.capability = capability; this.priority = priority;
        this.dependencies = Collections.unmodifiableList(new ArrayList<>(deps));
        this.enqueuedAtMillis = at;
    }

    public State state() { return state; }
    public String reason() { return reason; }
}
