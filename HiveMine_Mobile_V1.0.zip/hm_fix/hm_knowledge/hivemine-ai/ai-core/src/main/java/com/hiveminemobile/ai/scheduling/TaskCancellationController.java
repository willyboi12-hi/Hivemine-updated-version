package com.hiveminemobile.ai.scheduling;

/**
 * Phase 092: cancels queued work. A RUNNING task is not cancelled here, because only the execution layer
 * can stop it. The caller gets RUNNING_NOT_CANCELLED instead of a false success.
 */
public final class TaskCancellationController {
    public enum Result { CANCELLED, NOT_FOUND, ALREADY_FINISHED, RUNNING_NOT_CANCELLED }

    private final TaskQueueManager queue;

    public TaskCancellationController(TaskQueueManager queue) { this.queue = queue; }

    public synchronized Result cancel(String id) {
        ScheduledTask t = queue.get(id == null ? null : id.trim());
        if (t == null) return Result.NOT_FOUND;
        switch (t.state) {
            case QUEUED:
                t.state = ScheduledTask.State.CANCELLED;
                t.reason = "cancelled before it started";
                return Result.CANCELLED;
            case RUNNING:
                return Result.RUNNING_NOT_CANCELLED;
            default:
                return Result.ALREADY_FINISHED;
        }
    }
}
