package com.hiveminemobile.ai.scheduling;

import java.util.*;

/** Phase 092: dependency checks. Cycles and self-dependencies are refused before a task is queued. */
public final class TaskDependencyResolver {
    private TaskDependencyResolver() {}

    /** True when a task depends on itself, directly or through other tasks in the graph. */
    public static boolean hasCycle(Map<String, List<String>> graph) {
        Set<String> done = new HashSet<>(), active = new HashSet<>();
        for (String n : graph.keySet()) if (visit(n, graph, done, active)) return true;
        return false;
    }

    private static boolean visit(String n, Map<String, List<String>> g, Set<String> done, Set<String> active) {
        if (done.contains(n)) return false;
        if (!active.add(n)) return true;
        List<String> deps = g.get(n);
        if (deps != null) for (String d : deps) if (visit(d, g, done, active)) return true;
        active.remove(n);
        done.add(n);
        return false;
    }

    /** The dependencies not yet in the done set. */
    public static List<String> unmet(List<String> deps, Set<String> done) {
        List<String> out = new ArrayList<>();
        for (String d : deps) if (!done.contains(d)) out.add(d);
        return out;
    }
}
