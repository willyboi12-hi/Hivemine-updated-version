package com.hiveminemobile.ai.scheduling;

/** Phase 092: priority first, then waiting time, so low-priority work is not starved forever. */
public final class TaskPriorityEvaluator {
    public static final int MIN_PRIORITY = 0, MAX_PRIORITY = 10;

    private TaskPriorityEvaluator() {}

    public static boolean validPriority(int p) { return p >= MIN_PRIORITY && p <= MAX_PRIORITY; }

    public static long score(int priority, long waitedMillis) {
        int p = Math.max(MIN_PRIORITY, Math.min(MAX_PRIORITY, priority));
        long aging = Math.min(Math.max(0L, waitedMillis) / 1000L, 999_999L);
        return p * 1_000_000L + aging;
    }
}
