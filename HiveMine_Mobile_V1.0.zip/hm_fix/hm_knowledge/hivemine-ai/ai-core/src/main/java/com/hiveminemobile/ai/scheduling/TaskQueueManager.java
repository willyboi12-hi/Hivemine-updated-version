package com.hiveminemobile.ai.scheduling;

import java.util.*;

/** Phase 092: bounded queue. Tasks are never dropped silently: a full queue refuses, and old tasks expire visibly. */
public final class TaskQueueManager {
    public enum Result { QUEUED, DUPLICATE, FULL, INVALID }

    private final int capacity;
    private final long maxWaitMillis;
    private final Map<String, ScheduledTask> tasks = new LinkedHashMap<>();

    public TaskQueueManager(int capacity, long maxWaitMillis) {
        if (capacity < 1 || maxWaitMillis < 1) throw new IllegalArgumentException("capacity and maxWait must be positive");
        this.capacity = capacity;
        this.maxWaitMillis = maxWaitMillis;
    }

    public synchronized Result enqueue(String id, String capability, int priority, List<String> deps, long now) {
        if (blank(id) || blank(capability) || !TaskPriorityEvaluator.validPriority(priority) || deps == null) return Result.INVALID;
        for (String d : deps) if (blank(d) || d.trim().equals(id.trim())) return Result.INVALID;
        if (tasks.containsKey(id.trim())) return Result.DUPLICATE;
        if (queued() >= capacity) return Result.FULL;
        tasks.put(id.trim(), new ScheduledTask(id.trim(), capability.trim(), priority,
            trimmed(deps), now));
        return Result.QUEUED;
    }

    /** Expires queued tasks that waited too long. Returns them so the caller can report each one. */
    public synchronized List<ScheduledTask> expire(long now) {
        List<ScheduledTask> out = new ArrayList<>();
        for (ScheduledTask t : tasks.values())
            if (t.state == ScheduledTask.State.QUEUED && now - t.enqueuedAtMillis > maxWaitMillis) {
                t.state = ScheduledTask.State.EXPIRED;
                t.reason = "waited longer than " + maxWaitMillis + " ms";
                out.add(t);
            }
        return out;
    }

    /** Dependencies that ended in a state other than DONE make this task fail. Returns the failed tasks. */
    public synchronized List<ScheduledTask> failBlocked() {
        List<ScheduledTask> out = new ArrayList<>();
        for (ScheduledTask t : tasks.values()) {
            if (t.state != ScheduledTask.State.QUEUED) continue;
            for (String d : t.dependencies) {
                ScheduledTask dep = tasks.get(d);
                if (dep != null && isTerminalNotDone(dep.state)) {
                    t.state = ScheduledTask.State.FAILED;
                    t.reason = "dependency " + d + " is " + dep.state;
                    out.add(t);
                    break;
                }
            }
        }
        return out;
    }

    /** Picks the best queued task whose capability is usable and whose dependencies are done. */
    public synchronized ScheduledTask pollNext(Set<String> usable, long now) {
        Set<String> done = doneIds();
        ScheduledTask best = null;
        long bestScore = Long.MIN_VALUE;
        for (ScheduledTask t : tasks.values()) {
            if (t.state != ScheduledTask.State.QUEUED || !usable.contains(t.capability)) continue;
            if (!TaskDependencyResolver.unmet(t.dependencies, done).isEmpty()) continue;
            long s = TaskPriorityEvaluator.score(t.priority, now - t.enqueuedAtMillis);
            if (s > bestScore) { bestScore = s; best = t; }
        }
        if (best != null) best.state = ScheduledTask.State.RUNNING;
        return best;
    }

    public synchronized boolean finish(String id, boolean ok, String reason) {
        ScheduledTask t = tasks.get(id);
        if (t == null || t.state != ScheduledTask.State.RUNNING) return false;
        t.state = ok ? ScheduledTask.State.DONE : ScheduledTask.State.FAILED;
        t.reason = reason == null ? "" : reason;
        return true;
    }

    public synchronized ScheduledTask get(String id) { return tasks.get(id); }

    public synchronized int queued() {
        int n = 0;
        for (ScheduledTask t : tasks.values()) if (t.state == ScheduledTask.State.QUEUED) n++;
        return n;
    }

    public synchronized Collection<ScheduledTask> all() { return Collections.unmodifiableCollection(new ArrayList<>(tasks.values())); }

    synchronized Set<String> doneIds() {
        Set<String> s = new HashSet<>();
        for (ScheduledTask t : tasks.values()) if (t.state == ScheduledTask.State.DONE) s.add(t.id);
        return s;
    }

    static boolean isTerminalNotDone(ScheduledTask.State s) {
        return s == ScheduledTask.State.FAILED || s == ScheduledTask.State.CANCELLED || s == ScheduledTask.State.EXPIRED;
    }

    private static List<String> trimmed(List<String> in) {
        List<String> out = new ArrayList<>();
        for (String s : in) out.add(s.trim());
        return out;
    }

    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
