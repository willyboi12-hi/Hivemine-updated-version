package com.hiveminemobile.ai.scheduling;

import java.util.*;

/** Phase 092: a bounded log of every scheduling decision, including refusals and expiries. */
public final class TaskSchedulingReport {
    private static final int MAX = 500;
    private final Deque<String> lines = new ArrayDeque<>();

    public synchronized void record(long now, String taskId, String decision, String detail) {
        lines.addLast(now + " " + taskId + " " + decision + (detail == null || detail.isEmpty() ? "" : " - " + detail));
        while (lines.size() > MAX) lines.removeFirst();
    }

    public synchronized List<String> lines() { return new ArrayList<>(lines); }
}
