package com.hiveminemobile.ai.shared;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Phase 038. Combines evidence into one confidence. Confidence from one source counts once (its best
 * reading), each source's confidence halves every half-life, and independent sources combine as
 * 1 - product(1 - c). Two weak readings therefore never add up to a certain one from a single source.
 */
public final class ConfidenceEngine {
    public static final class Evidence {
        private final String source;
        private final double confidence;
        private final long observedAtMillis;

        public Evidence(String source, double confidence, long observedAtMillis) {
            ContextEngine.requireText(source, "source");
            if (!(confidence >= 0.0 && confidence <= 1.0)) throw new IllegalArgumentException("confidence must be 0-1");
            this.source = source;
            this.confidence = confidence;
            this.observedAtMillis = observedAtMillis;
        }
    }

    private final long halfLifeMillis;

    public ConfidenceEngine(long halfLifeMillis) {
        if (halfLifeMillis < 1L) throw new IllegalArgumentException("halfLifeMillis must be positive");
        this.halfLifeMillis = halfLifeMillis;
    }

    public double combine(List<Evidence> evidence, long nowMillis) {
        Map<String, Double> bestBySource = new HashMap<>();
        for (Evidence item : evidence) {
            long age = Math.max(0L, nowMillis - item.observedAtMillis);
            double decayed = item.confidence * Math.pow(0.5, age / (double) halfLifeMillis);
            Double current = bestBySource.get(item.source);
            if (current == null || decayed > current) bestBySource.put(item.source, decayed);
        }
        if (bestBySource.isEmpty()) return 0.0;
        double disbelief = 1.0;
        for (double value : bestBySource.values()) disbelief *= (1.0 - value);
        return 1.0 - disbelief;
    }

    public static boolean shouldAct(double confidence, double threshold) {
        if (!(threshold >= 0.0 && threshold <= 1.0)) throw new IllegalArgumentException("threshold must be 0-1");
        return confidence >= threshold;
    }
}
