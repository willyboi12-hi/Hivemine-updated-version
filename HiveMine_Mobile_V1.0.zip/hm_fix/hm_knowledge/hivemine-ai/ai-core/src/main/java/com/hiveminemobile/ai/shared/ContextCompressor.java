package com.hiveminemobile.ai.shared;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Phase 036. Shrinks an observation log before it is shown or sent: consecutive identical lines
 * collapse into one line with a count, and when the result is still too long only the newest lines
 * are kept.
 */
public final class ContextCompressor {
    public static final class Result {
        private final List<String> lines;
        private final int inputCount;
        private final int collapsed;
        private final int overflowDropped;

        Result(List<String> lines, int inputCount, int collapsed, int overflowDropped) {
            this.lines = lines;
            this.inputCount = inputCount;
            this.collapsed = collapsed;
            this.overflowDropped = overflowDropped;
        }

        public List<String> getLines() { return lines; }
        public int getInputCount() { return inputCount; }
        /** Input lines absorbed into a run count. */
        public int getCollapsed() { return collapsed; }
        public int getOverflowDropped() { return overflowDropped; }
    }

    private final int maxLines;

    public ContextCompressor(int maxLines) {
        if (maxLines < 1) throw new IllegalArgumentException("maxLines must be at least 1");
        this.maxLines = maxLines;
    }

    public Result compress(List<String> observations) {
        List<String> runs = new ArrayList<>();
        int collapsed = 0;
        int i = 0;
        while (i < observations.size()) {
            String current = observations.get(i);
            int j = i;
            while (j + 1 < observations.size() && observations.get(j + 1).equals(current)) j++;
            int count = j - i + 1;
            runs.add(count == 1 ? current : current + " (x" + count + ")");
            collapsed += count - 1;
            i = j + 1;
        }
        int overflow = Math.max(0, runs.size() - maxLines);
        List<String> kept = new ArrayList<>(runs.subList(overflow, runs.size()));
        return new Result(Collections.unmodifiableList(kept), observations.size(), collapsed, overflow);
    }
}
