package com.hiveminemobile.ai.shared;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Phase 031. Shared context for all modules: the latest value per key, with its source, observation
 * time and time-to-live. Older observations never replace newer ones, and expired values are never returned.
 */
public final class ContextEngine {
    public static final class Entry {
        private final String key;
        private final String value;
        private final String source;
        private final long observedAtMillis;
        private final long ttlMillis;

        Entry(String key, String value, String source, long observedAtMillis, long ttlMillis) {
            this.key = key;
            this.value = value;
            this.source = source;
            this.observedAtMillis = observedAtMillis;
            this.ttlMillis = ttlMillis;
        }

        public String getKey() { return key; }
        public String getValue() { return value; }
        public String getSource() { return source; }
        public long getObservedAtMillis() { return observedAtMillis; }
        boolean expiredAt(long nowMillis) { return nowMillis - observedAtMillis > ttlMillis; }
    }

    private final Map<String, Entry> entries = new HashMap<>();

    public synchronized void publish(String key, String value, String source, long observedAtMillis, long ttlMillis) {
        requireText(key, "key");
        requireText(source, "source");
        if (value == null) throw new IllegalArgumentException("value must not be null");
        if (ttlMillis < 1L) throw new IllegalArgumentException("ttlMillis must be positive");
        Entry current = entries.get(key);
        if (current != null && current.observedAtMillis >= observedAtMillis) return;
        entries.put(key, new Entry(key, value, source, observedAtMillis, ttlMillis));
    }

    /** The latest unexpired entry for the key, or null. */
    public synchronized Entry query(String key, long nowMillis) {
        Entry entry = entries.get(key);
        return entry == null || entry.expiredAt(nowMillis) ? null : entry;
    }

    public synchronized Map<String, String> snapshot(long nowMillis) {
        Map<String, String> values = new HashMap<>();
        for (Entry entry : entries.values()) {
            if (!entry.expiredAt(nowMillis)) values.put(entry.key, entry.value);
        }
        return Collections.unmodifiableMap(values);
    }

    /** Removes expired entries and returns how many were removed. */
    public synchronized int expire(long nowMillis) {
        int removed = 0;
        for (Iterator<Entry> it = entries.values().iterator(); it.hasNext(); ) {
            if (it.next().expiredAt(nowMillis)) {
                it.remove();
                removed++;
            }
        }
        return removed;
    }

    static void requireText(String text, String name) {
        if (text == null || text.trim().isEmpty()) throw new IllegalArgumentException(name + " must not be blank");
    }
}
