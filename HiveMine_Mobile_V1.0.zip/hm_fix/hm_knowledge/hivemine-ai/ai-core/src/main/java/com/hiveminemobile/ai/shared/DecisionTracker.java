package com.hiveminemobile.ai.shared;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Phase 039. Tracks decisions from the moment they are sent until their outcome is verified. A
 * decision is PENDING, never a success, until it is verified. Decisions that go unverified past their
 * deadline become UNVERIFIED_TIMEOUT and are kept out of success rates.
 */
public final class DecisionTracker {
    public enum State { PENDING, VERIFIED_SUCCESS, VERIFIED_FAILURE, UNVERIFIED_TIMEOUT }

    public static final class Decision {
        private final long id;
        private final String kind;
        private final String description;
        private final long madeAtMillis;
        private final State state;

        Decision(long id, String kind, String description, long madeAtMillis, State state) {
            this.id = id;
            this.kind = kind;
            this.description = description;
            this.madeAtMillis = madeAtMillis;
            this.state = state;
        }

        public long getId() { return id; }
        public String getKind() { return kind; }
        public String getDescription() { return description; }
        public long getMadeAtMillis() { return madeAtMillis; }
        public State getState() { return state; }
    }

    private final long verifyWithinMillis;
    private final Map<Long, Decision> decisions = new LinkedHashMap<>();
    private long nextId = 1L;

    public DecisionTracker(long verifyWithinMillis) {
        if (verifyWithinMillis < 1L) throw new IllegalArgumentException("verifyWithinMillis must be positive");
        this.verifyWithinMillis = verifyWithinMillis;
    }

    public synchronized Decision open(String kind, String description, long nowMillis) {
        ContextEngine.requireText(kind, "kind");
        ContextEngine.requireText(description, "description");
        Decision decision = new Decision(nextId++, kind, description, nowMillis, State.PENDING);
        decisions.put(decision.id, decision);
        return decision;
    }

    public synchronized Decision verify(long id, boolean succeeded) {
        Decision current = decisions.get(id);
        if (current == null) throw new IllegalArgumentException("no decision with id " + id);
        if (current.state != State.PENDING) throw new IllegalStateException("decision " + id + " is already resolved");
        Decision resolved = new Decision(id, current.kind, current.description, current.madeAtMillis,
            succeeded ? State.VERIFIED_SUCCESS : State.VERIFIED_FAILURE);
        decisions.put(id, resolved);
        return resolved;
    }

    /** Marks overdue pending decisions as unverified and returns them. */
    public synchronized List<Decision> expire(long nowMillis) {
        List<Decision> expired = new ArrayList<>();
        for (Map.Entry<Long, Decision> entry : decisions.entrySet()) {
            Decision decision = entry.getValue();
            if (decision.state == State.PENDING && nowMillis - decision.madeAtMillis > verifyWithinMillis) {
                Decision timedOut = new Decision(decision.id, decision.kind, decision.description,
                    decision.madeAtMillis, State.UNVERIFIED_TIMEOUT);
                entry.setValue(timedOut);
                expired.add(timedOut);
            }
        }
        return Collections.unmodifiableList(expired);
    }

    public synchronized Map<Long, Decision> snapshot() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(decisions));
    }

    /** Verified success share for a kind; empty when nothing has been verified for it. */
    public synchronized java.util.OptionalDouble verifiedSuccessRate(String kind) {
        int successes = 0;
        int total = 0;
        for (Decision decision : decisions.values()) {
            if (!decision.kind.equals(kind)) continue;
            if (decision.state == State.VERIFIED_SUCCESS) {
                successes++;
                total++;
            } else if (decision.state == State.VERIFIED_FAILURE) {
                total++;
            }
        }
        return total == 0 ? java.util.OptionalDouble.empty() : java.util.OptionalDouble.of(successes / (double) total);
    }
}
