package com.hiveminemobile.ai.shared;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Phase 032. A bounded, ordered event queue. Events are delivered only when dispatch() is called, so
 * the caller controls timing. Each event id is processed at most once. A failing subscriber is counted
 * and never stops delivery to the others.
 */
public final class EventBus {
    public static final String ANY = "*";

    public interface Subscriber {
        void onEvent(Event event) throws Exception;
    }

    public enum PublishResult { QUEUED, DUPLICATE, FULL }

    public static final class Event {
        private final String id;
        private final String type;
        private final String payload;
        private final long atMillis;

        Event(String id, String type, String payload, long atMillis) {
            this.id = id;
            this.type = type;
            this.payload = payload;
            this.atMillis = atMillis;
        }

        public String getId() { return id; }
        public String getType() { return type; }
        public String getPayload() { return payload; }
        public long getAtMillis() { return atMillis; }
    }

    private final int capacity;
    private final ArrayDeque<Event> queue = new ArrayDeque<>();
    private final Map<String, List<Subscriber>> subscribers = new HashMap<>();
    private final Set<String> seenIds = new HashSet<>();
    private long delivered;
    private long failed;
    private long dropped;
    private long duplicates;

    public EventBus(int capacity) {
        if (capacity < 1) throw new IllegalArgumentException("capacity must be at least 1");
        this.capacity = capacity;
    }

    public synchronized void subscribe(String type, Subscriber subscriber) {
        ContextEngine.requireText(type, "type");
        if (subscriber == null) throw new IllegalArgumentException("subscriber must not be null");
        List<Subscriber> list = subscribers.get(type);
        if (list == null) {
            list = new ArrayList<>();
            subscribers.put(type, list);
        }
        list.add(subscriber);
    }

    public synchronized PublishResult publish(String id, String type, String payload, long atMillis) {
        ContextEngine.requireText(id, "id");
        ContextEngine.requireText(type, "type");
        if (ANY.equals(type)) throw new IllegalArgumentException("'*' is a subscription, not an event type");
        if (payload == null) throw new IllegalArgumentException("payload must not be null");
        if (seenIds.contains(id)) {
            duplicates++;
            return PublishResult.DUPLICATE;
        }
        if (queue.size() >= capacity) {
            dropped++;
            return PublishResult.FULL;
        }
        seenIds.add(id);
        queue.addLast(new Event(id, type, payload, atMillis));
        return PublishResult.QUEUED;
    }

    /** Delivers every queued event in publish order. Returns how many events were dispatched. */
    public synchronized int dispatch() {
        int dispatched = 0;
        while (!queue.isEmpty()) {
            Event event = queue.pollFirst();
            dispatched++;
            deliver(subscribers.get(event.type), event);
            deliver(subscribers.get(ANY), event);
        }
        return dispatched;
    }

    private void deliver(List<Subscriber> targets, Event event) {
        if (targets == null) return;
        for (Subscriber target : new ArrayList<>(targets)) {
            try {
                target.onEvent(event);
                delivered++;
            } catch (Exception failure) {
                failed++;
            }
        }
    }

    public synchronized int pending() { return queue.size(); }
    public synchronized long getDelivered() { return delivered; }
    public synchronized long getFailed() { return failed; }
    public synchronized long getDropped() { return dropped; }
    public synchronized long getDuplicates() { return duplicates; }
}
