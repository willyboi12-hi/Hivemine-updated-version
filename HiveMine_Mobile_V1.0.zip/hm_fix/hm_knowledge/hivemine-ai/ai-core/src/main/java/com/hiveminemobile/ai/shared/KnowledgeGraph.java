package com.hiveminemobile.ai.shared;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Phase 035. A directed graph of named things (fields, quests, resources, ...) connected by typed
 * relations. It answers neighbour queries and finds the shortest directed path between two nodes.
 */
public final class KnowledgeGraph {
    /** node -> relation type -> target nodes. */
    private final Map<String, Map<String, Set<String>>> edges = new HashMap<>();
    private final Set<String> nodes = new HashSet<>();

    public synchronized void relate(String from, String type, String to) {
        ContextEngine.requireText(from, "from");
        ContextEngine.requireText(type, "type");
        ContextEngine.requireText(to, "to");
        nodes.add(from);
        nodes.add(to);
        Map<String, Set<String>> byType = edges.get(from);
        if (byType == null) {
            byType = new LinkedHashMap<>();
            edges.put(from, byType);
        }
        Set<String> targets = byType.get(type);
        if (targets == null) {
            targets = new HashSet<>();
            byType.put(type, targets);
        }
        targets.add(to);
    }

    public synchronized List<String> neighbors(String node, String type) {
        Map<String, Set<String>> byType = edges.get(node);
        if (byType == null || !byType.containsKey(type)) return Collections.emptyList();
        List<String> sorted = new ArrayList<>(byType.get(type));
        Collections.sort(sorted);
        return Collections.unmodifiableList(sorted);
    }

    /** Shortest directed path following any relation type, endpoints included. Empty when none exists. */
    public synchronized List<String> path(String from, String to) {
        if (!nodes.contains(from) || !nodes.contains(to)) return Collections.emptyList();
        Map<String, String> parent = new HashMap<>();
        Deque<String> queue = new ArrayDeque<>();
        parent.put(from, null);
        queue.add(from);
        while (!queue.isEmpty()) {
            String node = queue.poll();
            if (node.equals(to)) return rebuild(parent, to);
            for (String next : allTargets(node)) {
                if (!parent.containsKey(next)) {
                    parent.put(next, node);
                    queue.add(next);
                }
            }
        }
        return Collections.emptyList();
    }

    public synchronized int nodeCount() { return nodes.size(); }

    private Set<String> allTargets(String node) {
        Set<String> all = new HashSet<>();
        Map<String, Set<String>> byType = edges.get(node);
        if (byType != null) {
            for (Set<String> targets : byType.values()) all.addAll(targets);
        }
        return all;
    }

    private static List<String> rebuild(Map<String, String> parent, String end) {
        LinkedList<String> path = new LinkedList<>();
        for (String node = end; node != null; node = parent.get(node)) path.addFirst(node);
        return Collections.unmodifiableList(new ArrayList<>(path));
    }
}
