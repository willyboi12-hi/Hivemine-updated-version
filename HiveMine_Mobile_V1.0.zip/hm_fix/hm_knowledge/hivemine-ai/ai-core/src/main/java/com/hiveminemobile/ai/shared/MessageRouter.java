package com.hiveminemobile.ai.shared;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 033. Routes messages to handlers by the longest matching type prefix. Messages no route
 * claims are counted as unroutable, and handler failures are counted without stopping the router.
 */
public final class MessageRouter {
    public interface Handler {
        void handle(String type, String body) throws Exception;
    }

    public enum Result { ROUTED, UNROUTABLE, HANDLER_FAILED }

    private static final class Route {
        final String prefix;
        final Handler handler;

        Route(String prefix, Handler handler) {
            this.prefix = prefix;
            this.handler = handler;
        }
    }

    private final List<Route> routes = new ArrayList<>();
    private long routed;
    private long unroutable;
    private long failed;

    public synchronized void register(String prefix, Handler handler) {
        ContextEngine.requireText(prefix, "prefix");
        if (handler == null) throw new IllegalArgumentException("handler must not be null");
        for (Route route : routes) {
            if (route.prefix.equals(prefix)) throw new IllegalArgumentException("prefix already registered: " + prefix);
        }
        routes.add(new Route(prefix, handler));
        routes.sort(Comparator.comparingInt((Route route) -> route.prefix.length()).reversed());
    }

    public synchronized Result route(String type, String body) {
        if (type != null) {
            for (Route route : routes) {
                if (!type.startsWith(route.prefix)) continue;
                try {
                    route.handler.handle(type, body);
                    routed++;
                    return Result.ROUTED;
                } catch (Exception failure) {
                    failed++;
                    return Result.HANDLER_FAILED;
                }
            }
        }
        unroutable++;
        return Result.UNROUTABLE;
    }

    public synchronized long getRouted() { return routed; }
    public synchronized long getUnroutable() { return unroutable; }
    public synchronized long getFailed() { return failed; }
}
