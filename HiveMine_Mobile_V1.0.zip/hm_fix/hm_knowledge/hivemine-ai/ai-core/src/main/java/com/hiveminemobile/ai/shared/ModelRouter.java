package com.hiveminemobile.ai.shared;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

/**
 * Phase 037. Chooses the analyzer for a capability: the cheapest registered option that meets the
 * required accuracy. Accuracy is a declared figure, not a measured one; measured figures can replace it
 * once the testing stages provide them.
 */
public final class ModelRouter {
    public static final class Model {
        private final String name;
        private final Set<String> capabilities;
        private final double accuracy;
        private final double costPerCall;

        public Model(String name, Set<String> capabilities, double accuracy, double costPerCall) {
            ContextEngine.requireText(name, "name");
            if (capabilities == null || capabilities.isEmpty()) throw new IllegalArgumentException("capabilities required");
            if (!(accuracy >= 0.0 && accuracy <= 1.0)) throw new IllegalArgumentException("accuracy must be 0-1");
            if (!(costPerCall >= 0.0)) throw new IllegalArgumentException("cost must not be negative");
            this.name = name;
            this.capabilities = Collections.unmodifiableSet(new TreeSet<>(capabilities));
            this.accuracy = accuracy;
            this.costPerCall = costPerCall;
        }

        public String getName() { return name; }
        public double getAccuracy() { return accuracy; }
        public double getCostPerCall() { return costPerCall; }
    }

    private final List<Model> models = new ArrayList<>();

    public synchronized void register(Model model) {
        if (model == null) throw new IllegalArgumentException("model must not be null");
        for (Model existing : models) {
            if (existing.name.equals(model.name)) throw new IllegalArgumentException("model already registered: " + model.name);
        }
        models.add(model);
    }

    public synchronized Optional<Model> select(String capability, double minimumAccuracy) {
        Model best = null;
        for (Model model : models) {
            if (!model.capabilities.contains(capability) || model.accuracy < minimumAccuracy) continue;
            if (best == null || compare(model, best) < 0) best = model;
        }
        return Optional.ofNullable(best);
    }

    /** Negative when a is preferred: lower cost, then higher accuracy, then name. */
    private static int compare(Model a, Model b) {
        return Comparator.comparingDouble((Model m) -> m.costPerCall)
            .thenComparing(Comparator.comparingDouble((Model m) -> m.accuracy).reversed())
            .thenComparing(m -> m.name)
            .compare(a, b);
    }
}
