package com.hiveminemobile.ai.shared;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Phase 034. A key/value memory saved to a UTF-8 text file, one record per line. Tabs, newlines and
 * backslashes are escaped, so any text round-trips. Malformed lines are skipped and counted, never fatal.
 */
public final class PersistentMemoryStore {
    public static final class Record {
        private final String key;
        private final String value;
        private final long savedAtMillis;

        Record(String key, String value, long savedAtMillis) {
            this.key = key;
            this.value = value;
            this.savedAtMillis = savedAtMillis;
        }

        public String getKey() { return key; }
        public String getValue() { return value; }
        public long getSavedAtMillis() { return savedAtMillis; }
    }

    private final Map<String, Record> records = new TreeMap<>();
    private int corruptLines;

    public synchronized void put(String key, String value, long nowMillis) {
        ContextEngine.requireText(key, "key");
        if (value == null) throw new IllegalArgumentException("value must not be null");
        records.put(key, new Record(key, value, nowMillis));
    }

    public synchronized Record get(String key) {
        return records.get(key);
    }

    public synchronized int size() { return records.size(); }

    public synchronized int getCorruptLines() { return corruptLines; }

    public synchronized void save(Path file) throws IOException {
        List<String> lines = new ArrayList<>();
        for (Record record : records.values()) {
            lines.add(escape(record.key) + '\t' + escape(record.value) + '\t' + record.savedAtMillis);
        }
        Files.write(file, lines, StandardCharsets.UTF_8);
    }

    public static PersistentMemoryStore load(Path file) throws IOException {
        PersistentMemoryStore store = new PersistentMemoryStore();
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            String[] parts = line.split("\t", -1);
            if (parts.length != 3) {
                store.corruptLines++;
                continue;
            }
            String key = unescape(parts[0]);
            String value = unescape(parts[1]);
            Long savedAt = parseLong(parts[2]);
            if (key == null || value == null || savedAt == null || key.trim().isEmpty()) {
                store.corruptLines++;
                continue;
            }
            store.records.put(key, new Record(key, value, savedAt));
        }
        return store;
    }

    public synchronized Map<String, Record> snapshot() {
        return Collections.unmodifiableMap(new TreeMap<>(records));
    }

    static String escape(String text) {
        return text.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r");
    }

    /** Reverses escape(); returns null for an invalid escape sequence. */
    static String unescape(String text) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c != '\\') {
                out.append(c);
                continue;
            }
            if (i + 1 >= text.length()) return null;
            char next = text.charAt(++i);
            if (next == 't') out.append('\t');
            else if (next == 'n') out.append('\n');
            else if (next == 'r') out.append('\r');
            else if (next == '\\') out.append('\\');
            else return null;
        }
        return out.toString();
    }

    private static Long parseLong(String text) {
        try {
            return Long.valueOf(text.trim());
        } catch (NumberFormatException notANumber) {
            return null;
        }
    }
}
