package com.hiveminemobile.ai.shared;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Phase 040. Divides a fixed capacity (for example processing slots per tick) among requests. Each
 * round, the remaining capacity is split in proportion to priority among unsatisfied requests, with at
 * least one unit each while capacity lasts. Higher priority gets more, and no request is starved.
 */
public final class ResourceAllocator {
    public static final class Request {
        private final String id;
        private final int priority;
        private final int units;

        public Request(String id, int priority, int units) {
            ContextEngine.requireText(id, "id");
            if (priority < 1 || priority > 10) throw new IllegalArgumentException("priority must be 1-10");
            if (units < 1) throw new IllegalArgumentException("units must be at least 1");
            this.id = id;
            this.priority = priority;
            this.units = units;
        }
    }

    public static final class Grant {
        private final String id;
        private final int units;

        Grant(String id, int units) {
            this.id = id;
            this.units = units;
        }

        public String getId() { return id; }
        public int getUnits() { return units; }
    }

    public List<Grant> allocate(int capacity, List<Request> requests) {
        if (capacity < 0) throw new IllegalArgumentException("capacity must not be negative");
        Map<String, Integer> granted = new LinkedHashMap<>();
        for (Request request : requests) granted.put(request.id, 0);
        int remaining = capacity;
        boolean progressed = true;
        while (remaining > 0 && progressed) {
            progressed = false;
            int roundCapacity = remaining;
            int sumPriority = 0;
            for (Request request : requests) {
                if (granted.get(request.id) < request.units) sumPriority += request.priority;
            }
            for (Request request : requests) {
                int have = granted.get(request.id);
                int want = request.units - have;
                if (want <= 0 || remaining == 0) continue;
                int share = Math.max(1, roundCapacity * request.priority / sumPriority);
                int give = Math.min(share, Math.min(want, remaining));
                granted.put(request.id, have + give);
                remaining -= give;
                progressed = true;
            }
        }
        List<Grant> grants = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : granted.entrySet()) grants.add(new Grant(entry.getKey(), entry.getValue()));
        return Collections.unmodifiableList(grants);
    }
}
