package com.hiveminemobile.ai.specialist;

/** Immutable outcome of a specialist registration attempt. */
public final class RegistrationResult {
    private final boolean accepted;
    private final String specialistId, message;
    private RegistrationResult(boolean accepted, String specialistId, String message) {
        this.accepted = accepted; this.specialistId = specialistId; this.message = message;
    }
    public static RegistrationResult accepted(String id) {
        return new RegistrationResult(true, id, "Specialist registered");
    }
    public static RegistrationResult rejected(String id, String reason) {
        return new RegistrationResult(false, id, reason);
    }
    public boolean isAccepted() { return accepted; }
    public String getSpecialistId() { return specialistId; }
    public String getMessage() { return message; }
}
