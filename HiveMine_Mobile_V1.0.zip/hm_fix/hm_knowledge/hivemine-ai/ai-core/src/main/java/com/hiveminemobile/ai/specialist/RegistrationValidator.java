package com.hiveminemobile.ai.specialist;

import com.hiveminemobile.ai.AIInterface;
import java.util.Set;
import java.util.regex.Pattern;

/** Validates specialist identity, metadata, capabilities and manager compatibility. */
public final class RegistrationValidator {
    private static final Pattern ID = Pattern.compile("[a-z][a-z0-9._-]{0,63}");
    private static final Pattern VERSION = Pattern.compile("[0-9]+\\.[0-9]+\\.[0-9]+");
    private RegistrationValidator() { }

    public static String validate(AIInterface module, SpecialistMetadata metadata, String managerVersion) {
        if (module == null) return "Specialist module is missing";
        if (metadata == null) return "Specialist metadata is missing";
        if (!validVersion(managerVersion)) return "Manager version is invalid";
        String id = metadata.getSpecialistId();
        if (id == null || !ID.matcher(id).matches()) return "Specialist ID is invalid";
        if (!id.equals(module.getId())) return "Metadata ID does not match module ID";
        if (!validVersion(metadata.getVersion()) || !metadata.getVersion().equals(module.getVersion()))
            return "Specialist version is invalid or inconsistent";
        if (metadata.getCapabilities().isEmpty()) return "At least one capability is required";
        for (String capability : metadata.getCapabilities())
            if (capability == null || !ID.matcher(capability).matches()) return "Capability identifier is invalid";
        Set<String> dependencies = metadata.getDependencies();
        for (String dependency : dependencies) {
            if (dependency == null || !ID.matcher(dependency).matches()) return "Dependency identifier is invalid";
            if (id.equals(dependency)) return "Specialist cannot depend on itself";
        }
        String minimum = metadata.getMinimumManagerVersion();
        String maximum = metadata.getMaximumManagerVersion();
        if (minimum != null && (!validVersion(minimum) || compare(managerVersion, minimum) < 0))
            return "Manager version is below specialist minimum or minimum is invalid";
        if (maximum != null && (!validVersion(maximum) || compare(managerVersion, maximum) > 0))
            return "Manager version exceeds specialist maximum or maximum is invalid";
        return null;
    }
    private static boolean validVersion(String value) {
        return value != null && VERSION.matcher(value).matches();
    }
    private static int compare(String left, String right) {
        String[] a = left.split("\\."), b = right.split("\\.");
        for (int i = 0; i < 3; i++) {
            int result = Integer.compare(Integer.parseInt(a[i]), Integer.parseInt(b[i]));
            if (result != 0) return result;
        }
        return 0;
    }
}
