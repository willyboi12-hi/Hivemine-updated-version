package com.hiveminemobile.ai.specialist;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/** Immutable registration metadata supplied by a specialist module. */
public final class SpecialistMetadata {
    public enum ResourceClass { LIGHT, STANDARD, HEAVY }
    private final String specialistId, version, minimumManagerVersion, maximumManagerVersion;
    private final Set<String> capabilities, dependencies;
    private final ResourceClass resourceClass;

    public SpecialistMetadata(String specialistId, String version, String minimumManagerVersion,
            String maximumManagerVersion, Set<String> capabilities, Set<String> dependencies,
            ResourceClass resourceClass) {
        this.specialistId = specialistId;
        this.version = version;
        this.minimumManagerVersion = minimumManagerVersion;
        this.maximumManagerVersion = maximumManagerVersion;
        this.capabilities = immutableCopy(capabilities);
        this.dependencies = immutableCopy(dependencies);
        this.resourceClass = resourceClass == null ? ResourceClass.STANDARD : resourceClass;
    }
    public static SpecialistMetadata from(com.hiveminemobile.ai.AIInterface module, Set<String> dependencies) {
        if (module == null) throw new IllegalArgumentException("module must not be null");
        return new SpecialistMetadata(module.getId(), module.getVersion(), "1.0.0", null,
            module.getCapabilities(), dependencies, ResourceClass.STANDARD);
    }
    private static Set<String> immutableCopy(Set<String> source) {
        return source == null ? Collections.<String>emptySet()
            : Collections.unmodifiableSet(new LinkedHashSet<>(source));
    }
    public String getSpecialistId() { return specialistId; }
    public String getVersion() { return version; }
    public String getMinimumManagerVersion() { return minimumManagerVersion; }
    public String getMaximumManagerVersion() { return maximumManagerVersion; }
    public Set<String> getCapabilities() { return capabilities; }
    public Set<String> getDependencies() { return dependencies; }
    public ResourceClass getResourceClass() { return resourceClass; }
}
