package com.hiveminemobile.ai.specialist;

import com.hiveminemobile.ai.AIInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Capability-aware registry. It stores metadata and status, but does not execute modules. */
public final class SpecialistRegistry {
    public static final String MANAGER_VERSION = "1.0.0";
    private static final class Entry {
        final AIInterface module;
        final SpecialistMetadata metadata;
        final long registeredAt;
        SpecialistStatus status = SpecialistStatus.REGISTERED;
        Entry(AIInterface module, SpecialistMetadata metadata) {
            this.module = module; this.metadata = metadata; this.registeredAt = System.currentTimeMillis();
        }
    }
    private final Map<String, Entry> entries = new LinkedHashMap<>();

    public synchronized RegistrationResult register(AIInterface module, SpecialistMetadata metadata) {
        String id = metadata == null ? (module == null ? null : module.getId()) : metadata.getSpecialistId();
        String problem = RegistrationValidator.validate(module, metadata, MANAGER_VERSION);
        if (problem != null) return RegistrationResult.rejected(id, problem);
        if (entries.containsKey(id)) return RegistrationResult.rejected(id, "Specialist ID is already registered");
        entries.put(id, new Entry(module, metadata));
        return RegistrationResult.accepted(id);
    }
    public synchronized boolean unregister(String id) { return id != null && entries.remove(id) != null; }
    public synchronized AIInterface getModule(String id) {
        Entry e = id == null ? null : entries.get(id); return e == null ? null : e.module;
    }
    public synchronized SpecialistMetadata getMetadata(String id) {
        Entry e = id == null ? null : entries.get(id); return e == null ? null : e.metadata;
    }
    public synchronized SpecialistStatus getStatus(String id) {
        Entry e = id == null ? null : entries.get(id); return e == null ? null : e.status;
    }
    public synchronized boolean updateStatus(String id, SpecialistStatus status) {
        Entry e = id == null ? null : entries.get(id);
        if (e == null || status == null) return false;
        e.status = status; return true;
    }
    public synchronized List<String> findByCapability(String capability) {
        List<String> matches = new ArrayList<>();
        if (capability != null) for (Entry e : entries.values()) {
            if (e.metadata.getCapabilities().contains(capability)
                    && e.status != SpecialistStatus.UNAVAILABLE && e.status != SpecialistStatus.FAILED)
                matches.add(e.metadata.getSpecialistId());
        }
        return Collections.unmodifiableList(matches);
    }
    public synchronized Set<String> getRegisteredIds() {
        return Collections.unmodifiableSet(new LinkedHashSet<>(entries.keySet()));
    }
    public synchronized int size() { return entries.size(); }
    public synchronized long getRegisteredAt(String id) {
        Entry e = id == null ? null : entries.get(id); return e == null ? -1L : e.registeredAt;
    }
}
