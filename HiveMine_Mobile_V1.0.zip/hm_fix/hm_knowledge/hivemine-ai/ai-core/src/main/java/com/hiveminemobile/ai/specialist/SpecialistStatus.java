package com.hiveminemobile.ai.specialist;

/** Informational registry state; it never grants execution permission. */
public enum SpecialistStatus { REGISTERED, AVAILABLE, UNAVAILABLE, DEGRADED, FAILED }
