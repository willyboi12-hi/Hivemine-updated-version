package com.hiveminemobile.ai.stabilize;

import com.hiveminemobile.ai.compat.AndroidCompatibilityValidator;
import java.util.*;

/** Phase 100: gathers the checks from phases 091–099 into one stabilization result. */
public final class HiveMineAIStabilizationManager {
    public static Map<String, List<String>> requiredComponents() {
        Map<String, List<String>> m = new LinkedHashMap<>();
        m.put("091 registry", Arrays.asList("com.hiveminemobile.ai.registry.UnifiedAISystemRegistry"));
        m.put("092 scheduling", Arrays.asList("com.hiveminemobile.ai.scheduling.IntelligentTaskScheduler"));
        m.put("093 communication", Arrays.asList("com.hiveminemobile.ai.crosssystem.CrossSystemCommunicationManager"));
        m.put("094 conflicts", Arrays.asList("com.hiveminemobile.ai.conflict.AIConflictResolutionEngine"));
        m.put("095 monitoring", Arrays.asList("com.hiveminemobile.ai.monitor.UnifiedExecutionMonitor"));
        m.put("097 compatibility", Arrays.asList("com.hiveminemobile.ai.compat.AndroidCompatibilityValidator"));
        m.put("098 reliability", Arrays.asList("com.hiveminemobile.ai.reliability.ReliabilityValidationManager"));
        m.put("099 performance", Arrays.asList("com.hiveminemobile.ai.performance.SystemPerformanceValidationManager"));
        m.put("macro communication (089)", Arrays.asList("com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge"));
        m.put("configuration sync (090)", Arrays.asList("com.hiveminemobile.ai.android.AndroidConfigurationSyncManager"));
        m.put("persistent lifecycle (086)", Arrays.asList("com.hiveminemobile.ai.android.AndroidLifecycleController"));
        return m;
    }

    public static final List<String> INCOMPLETE = Collections.unmodifiableList(Arrays.asList(
        "Full Android Gradle build and APK (no Android SDK or network in the build environment)",
        "Device tests of the macro, overlay drawing, and touch",
        "Dashboard Start/Recover/Stop still call AutomationController directly, not the phase 089 bridge",
        "Old overlapping classes in optimize.* and integration.* are not merged (see OVERLAPS.md)",
        "Release signing key is supplied by the user, not the project"));

    public ReleaseReadinessEvaluator.Result stabilize(List<StabilizationChecklist.Item> items, List<String> integrityFailures,
                                                      AndroidCompatibilityValidator.Report compat, String androidBuildStatus) {
        List<String> compatBlockers = new ArrayList<>();
        for (AndroidCompatibilityValidator.Finding f : compat.findings)
            if (f.level == AndroidCompatibilityValidator.Level.BLOCKER) compatBlockers.add("compatibility: " + f.message);
        return new ReleaseReadinessEvaluator().evaluate(items, integrityFailures, compatBlockers, androidBuildStatus);
    }
}
