package com.hiveminemobile.ai.stabilize;

import java.util.*;

/** Phase 100: the final stabilization report as markdown. */
public final class HiveMineAIStabilizationReport {
    public String toMarkdown(ReleaseReadinessEvaluator.Result verdict, List<String> healthLines,
                             List<String> incompleteFunctionality) {
        StringBuilder b = new StringBuilder("# HiveMine AI stabilization report\n\n");
        b.append("Verdict: **").append(verdict.verdict).append("**\n\n");
        b.append("## Health\n");
        for (String l : healthLines) b.append("- ").append(l).append('\n');
        b.append("\n## Blockers\n");
        if (verdict.blockers.isEmpty()) b.append("- none\n");
        for (String s : verdict.blockers) b.append("- ").append(s).append('\n');
        b.append("\n## Incomplete functionality\n");
        for (String s : incompleteFunctionality) b.append("- ").append(s).append('\n');
        b.append("\nThis report is not proof the whole project is ready for release. A READY verdict needs the Android build and device tests to pass.\n");
        return b.toString();
    }
}
