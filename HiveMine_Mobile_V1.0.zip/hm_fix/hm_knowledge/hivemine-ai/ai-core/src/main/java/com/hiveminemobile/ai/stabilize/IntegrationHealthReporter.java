package com.hiveminemobile.ai.stabilize;

import java.util.*;

/** Phase 100: short health summary of the checklist and integrity results. */
public final class IntegrationHealthReporter {
    public List<String> lines(List<StabilizationChecklist.Item> items, List<String> integrityFailures) {
        int present = 0;
        List<String> missing = new ArrayList<>();
        for (StabilizationChecklist.Item i : items) { if (i.present) present++; else missing.add(i.area + ":" + i.className); }
        List<String> out = new ArrayList<>();
        out.add("components present: " + present + "/" + items.size());
        out.add("missing components: " + (missing.isEmpty() ? "none" : missing.toString()));
        out.add("integrity failures: " + (integrityFailures.isEmpty() ? "none" : integrityFailures.toString()));
        return out;
    }
}
