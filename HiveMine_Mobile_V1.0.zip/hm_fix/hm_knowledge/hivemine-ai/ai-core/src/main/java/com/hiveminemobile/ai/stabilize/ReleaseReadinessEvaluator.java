package com.hiveminemobile.ai.stabilize;

import java.util.*;

/**
 * Phase 100: decides READY or NOT_READY. Any blocker means NOT_READY. Android build validation that was
 * not run counts as a blocker, so passing JVM tests cannot make the build look verified.
 */
public final class ReleaseReadinessEvaluator {
    public enum Verdict { READY, NOT_READY }

    public static final String BUILD_VERIFIED = "VERIFIED";

    public static final class Result {
        public final Verdict verdict; public final List<String> blockers;
        Result(Verdict v, List<String> b) { verdict = v; blockers = Collections.unmodifiableList(b); }
    }

    public Result evaluate(List<StabilizationChecklist.Item> items, List<String> integrityFailures,
                           List<String> compatibilityBlockers, String androidBuildStatus) {
        List<String> blockers = new ArrayList<>();
        for (StabilizationChecklist.Item i : items) if (!i.present) blockers.add("missing component " + i.className);
        for (String f : integrityFailures) blockers.add("integrity check failed: " + f);
        blockers.addAll(compatibilityBlockers);
        if (!BUILD_VERIFIED.equals(androidBuildStatus)) blockers.add("Android build validation not verified (status: " + androidBuildStatus + ")");
        return new Result(blockers.isEmpty() ? Verdict.READY : Verdict.NOT_READY, blockers);
    }
}
