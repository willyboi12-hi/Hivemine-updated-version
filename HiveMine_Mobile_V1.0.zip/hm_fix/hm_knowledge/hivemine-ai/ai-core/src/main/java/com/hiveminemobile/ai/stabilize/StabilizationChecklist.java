package com.hiveminemobile.ai.stabilize;

import java.util.*;

/** Phase 100: confirms that each required component exists on the classpath. */
public final class StabilizationChecklist {
    public static final class Item {
        public final String area, className; public final boolean present;
        Item(String a, String c, boolean p) { area = a; className = c; present = p; }
    }

    public static List<Item> check(Map<String, List<String>> requiredByArea) {
        List<Item> out = new ArrayList<>();
        for (Map.Entry<String, List<String>> e : requiredByArea.entrySet())
            for (String c : e.getValue()) out.add(new Item(e.getKey(), c, present(c)));
        return out;
    }

    static boolean present(String className) {
        try { Class.forName(className, false, StabilizationChecklist.class.getClassLoader()); return true; }
        catch (ClassNotFoundException | LinkageError e) { return false; }
    }
}
