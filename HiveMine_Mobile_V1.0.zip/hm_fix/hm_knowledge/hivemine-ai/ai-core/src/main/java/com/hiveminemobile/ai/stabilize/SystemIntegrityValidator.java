package com.hiveminemobile.ai.stabilize;

import java.util.*;

/** Phase 100: turns check results into integrity failures. A failing check is always listed. */
public final class SystemIntegrityValidator {
    public List<String> failures(Map<String, Boolean> checks) {
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, Boolean> e : checks.entrySet()) if (!Boolean.TRUE.equals(e.getValue())) out.add(e.getKey());
        return out;
    }
}
