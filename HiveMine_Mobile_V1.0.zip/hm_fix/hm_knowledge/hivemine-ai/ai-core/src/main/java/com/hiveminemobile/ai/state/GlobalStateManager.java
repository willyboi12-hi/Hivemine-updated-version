package com.hiveminemobile.ai.state;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * In-memory shared state for Bee Swarm workflows. This layer stores observations,
 * not hidden game state. Inputs must come from supported, authorized screen/UI sources.
 */
public final class GlobalStateManager {
    public enum UpdateStatus { ACCEPTED, REJECTED, CONFLICT }
    public static final class UpdateResult {
        private final UpdateStatus status; private final String reason; private final StateConflict conflict;
        private UpdateResult(UpdateStatus status, String reason, StateConflict conflict) {
            this.status = status; this.reason = reason; this.conflict = conflict;
        }
        public UpdateStatus getStatus() { return status; }
        public String getReason() { return reason; }
        public StateConflict getConflict() { return conflict; }
    }

    private final Map<String, StateFact> current = new LinkedHashMap<>();
    private final Deque<StateSnapshot> history = new ArrayDeque<>();
    private final List<StateConflict> conflicts = new ArrayList<>();
    private final int historyLimit;
    private final long maxObservationAgeMillis;

    public GlobalStateManager() { this(50, 120_000L); }
    public GlobalStateManager(int historyLimit, long maxObservationAgeMillis) {
        if (historyLimit < 1 || maxObservationAgeMillis < 0L) throw new IllegalArgumentException("Invalid state manager limits");
        this.historyLimit = historyLimit; this.maxObservationAgeMillis = maxObservationAgeMillis;
    }

    public synchronized UpdateResult update(StateFact fact, long nowMillis) {
        StateValidationResult validation = StateValidator.validate(fact, nowMillis, maxObservationAgeMillis);
        if (!validation.isValid()) return new UpdateResult(UpdateStatus.REJECTED, validation.getReason(), null);
        StateFact old = current.get(fact.getKey());
        if (old != null && !old.getValue().equals(fact.getValue())
                && nowMillis - old.getObservedAtMillis() <= maxObservationAgeMillis) {
            StateConflict conflict = new StateConflict(old, fact);
            conflicts.add(conflict);
            // Do not silently choose between fresh contradictory sources.
            if (fact.getObservedAtMillis() <= old.getObservedAtMillis()
                    || fact.getConfidence() <= old.getConfidence())
                return new UpdateResult(UpdateStatus.CONFLICT, "Conflicting observation retained for review; current value unchanged", conflict);
            current.put(fact.getKey(), fact);
            return new UpdateResult(UpdateStatus.CONFLICT, "Newer, higher-confidence observation selected; conflict retained", conflict);
        }
        if (old == null || fact.getObservedAtMillis() >= old.getObservedAtMillis()) {
            current.put(fact.getKey(), fact);
            return new UpdateResult(UpdateStatus.ACCEPTED, "Observation stored", null);
        }
        return new UpdateResult(UpdateStatus.REJECTED, "Older observation cannot replace newer state", null);
    }

    public synchronized StateFact get(String key) { return current.get(key); }
    public synchronized Map<String, StateFact> getCurrentState() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(current));
    }
    public synchronized boolean isFresh(String key, long nowMillis) {
        StateFact fact = current.get(key);
        return fact != null && nowMillis >= fact.getObservedAtMillis()
                && nowMillis - fact.getObservedAtMillis() <= maxObservationAgeMillis;
    }
    public synchronized List<String> getStaleKeys(long nowMillis) {
        List<String> stale = new ArrayList<>();
        for (Map.Entry<String, StateFact> entry : current.entrySet())
            if (!isFresh(entry.getKey(), nowMillis)) stale.add(entry.getKey());
        return Collections.unmodifiableList(stale);
    }
    public synchronized StateSnapshot createSnapshot(long nowMillis) {
        StateSnapshot snapshot = new StateSnapshot(nowMillis, current);
        history.addFirst(snapshot);
        while (history.size() > historyLimit) history.removeLast();
        return snapshot;
    }
    public synchronized List<StateSnapshot> getHistory() {
        return Collections.unmodifiableList(new ArrayList<>(history));
    }
    public synchronized List<StateConflict> getConflicts() {
        return Collections.unmodifiableList(new ArrayList<>(conflicts));
    }
    public synchronized void clearCurrentState() { current.clear(); }
    public synchronized void restore(StateSnapshot snapshot) {
        if (snapshot == null) throw new IllegalArgumentException("Snapshot is required");
        current.clear(); current.putAll(snapshot.getFacts());
    }
    public synchronized double getAverageConfidence(long nowMillis) {
        double total = 0.0; int count = 0;
        for (String key : current.keySet()) if (isFresh(key, nowMillis)) {
            total += current.get(key).getConfidence(); count++;
        }
        return count == 0 ? 0.0 : total / count;
    }
}
