package com.hiveminemobile.ai.state;

/** Describes disagreeing fresh observations without silently erasing either source. */
public final class StateConflict {
    private final StateFact existing, incoming;
    public StateConflict(StateFact existing, StateFact incoming) { this.existing = existing; this.incoming = incoming; }
    public StateFact getExisting() { return existing; }
    public StateFact getIncoming() { return incoming; }
    public String getKey() { return incoming.getKey(); }
}
