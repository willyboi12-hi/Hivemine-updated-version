package com.hiveminemobile.ai.state;

/** Bee Swarm session domains populated only from supported, user-authorized observations. */
public enum StateDomain {
    SESSION, PLAYER, FIELD, POLLEN, HONEY, INVENTORY, QUEST, BUFF, AUTOMATION, UI, DEVICE
}
