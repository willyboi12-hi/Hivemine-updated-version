package com.hiveminemobile.ai.state;

/** One typed-by-domain observation; values are strings to keep the core dependency-free. */
public final class StateFact {
    private final String key, value, sourceId;
    private final StateDomain domain;
    private final long observedAtMillis;
    private final double confidence;

    public StateFact(String key, String value, StateDomain domain, String sourceId,
                     long observedAtMillis, double confidence) {
        this.key = key; this.value = value; this.domain = domain; this.sourceId = sourceId;
        this.observedAtMillis = observedAtMillis; this.confidence = confidence;
    }
    public String getKey() { return key; }
    public String getValue() { return value; }
    public StateDomain getDomain() { return domain; }
    public String getSourceId() { return sourceId; }
    public long getObservedAtMillis() { return observedAtMillis; }
    public double getConfidence() { return confidence; }
}
