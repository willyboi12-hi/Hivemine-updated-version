package com.hiveminemobile.ai.state;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Immutable point-in-time view of Bee Swarm session facts. */
public final class StateSnapshot {
    private final long createdAtMillis;
    private final Map<String, StateFact> facts;
    public StateSnapshot(long createdAtMillis, Map<String, StateFact> facts) {
        this.createdAtMillis = createdAtMillis;
        this.facts = Collections.unmodifiableMap(new LinkedHashMap<>(facts));
    }
    public long getCreatedAtMillis() { return createdAtMillis; }
    public Map<String, StateFact> getFacts() { return facts; }
    public StateFact get(String key) { return facts.get(key); }
}
