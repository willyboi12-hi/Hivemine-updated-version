package com.hiveminemobile.ai.state;

public final class StateValidationResult {
    private final boolean valid; private final String reason;
    private StateValidationResult(boolean valid, String reason) { this.valid = valid; this.reason = reason; }
    public static StateValidationResult valid() { return new StateValidationResult(true, "Valid observation"); }
    public static StateValidationResult invalid(String reason) { return new StateValidationResult(false, reason); }
    public boolean isValid() { return valid; }
    public String getReason() { return reason; }
}
