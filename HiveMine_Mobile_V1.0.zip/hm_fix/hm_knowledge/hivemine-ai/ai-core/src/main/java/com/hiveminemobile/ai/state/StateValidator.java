package com.hiveminemobile.ai.state;

/** Rejects malformed, future-dated, or implausibly old observations before aggregation. */
public final class StateValidator {
    private StateValidator() { }
    public static StateValidationResult validate(StateFact fact, long nowMillis, long maxAgeMillis) {
        if (fact == null) return StateValidationResult.invalid("Observation is missing");
        if (fact.getKey() == null || fact.getKey().trim().isEmpty()) return StateValidationResult.invalid("State key is blank");
        if (fact.getValue() == null) return StateValidationResult.invalid("State value is missing");
        if (fact.getDomain() == null) return StateValidationResult.invalid("State domain is missing");
        if (fact.getSourceId() == null || fact.getSourceId().trim().isEmpty()) return StateValidationResult.invalid("Observation source is missing");
        if (fact.getObservedAtMillis() <= 0L || fact.getObservedAtMillis() > nowMillis)
            return StateValidationResult.invalid("Observation timestamp is invalid or in the future");
        if (maxAgeMillis < 0L || nowMillis - fact.getObservedAtMillis() > maxAgeMillis)
            return StateValidationResult.invalid("Observation is older than the accepted age");
        if (Double.isNaN(fact.getConfidence()) || Double.isInfinite(fact.getConfidence())
                || fact.getConfidence() < 0.0 || fact.getConfidence() > 1.0)
            return StateValidationResult.invalid("Confidence must be between 0 and 1");
        return StateValidationResult.valid();
    }
}
