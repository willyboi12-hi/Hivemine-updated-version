package com.hiveminemobile.ai.subsystems;

import java.util.Map;

/** Unique subsystem for phase 012 (MANAGER). */
public final class Phase012Subsystem extends AbstractSubsystem {
    public Phase012Subsystem() {
        super(12, "MANAGER", "ManagerSubsystem P012");
    }

    @Override
    public Map<String, Double> evaluate(Map<String, Double> input) {
        double load = get(input, "load", 0.3);
        double backlog = get(input, "backlog", 0.0);
        double score = Math.max(0, 1.0 - load - backlog * 0.2) + (12 % 5) * 0.02;
        setHealth(score > 0.4 ? 1.0 : 0.5);
        return out("managerCapacity", score);
    }
}
