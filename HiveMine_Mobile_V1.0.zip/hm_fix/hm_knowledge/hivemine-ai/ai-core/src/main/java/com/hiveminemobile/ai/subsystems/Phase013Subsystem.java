package com.hiveminemobile.ai.subsystems;

import java.util.Map;

/** Unique subsystem for phase 013 (MANAGER). */
public final class Phase013Subsystem extends AbstractSubsystem {
    public Phase013Subsystem() {
        super(13, "MANAGER", "ManagerSubsystem P013");
    }

    @Override
    public Map<String, Double> evaluate(Map<String, Double> input) {
        double load = get(input, "load", 0.3);
        double backlog = get(input, "backlog", 0.0);
        double score = Math.max(0, 1.0 - load - backlog * 0.2) + (13 % 5) * 0.02;
        setHealth(score > 0.4 ? 1.0 : 0.5);
        return out("managerCapacity", score);
    }
}
