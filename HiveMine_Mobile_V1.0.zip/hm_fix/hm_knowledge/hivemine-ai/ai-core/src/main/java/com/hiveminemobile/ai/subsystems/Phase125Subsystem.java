package com.hiveminemobile.ai.subsystems;

import java.util.Map;

/** Unique subsystem for phase 125 (SPECIALIST_DEPTH). */
public final class Phase125Subsystem extends AbstractSubsystem {
    public Phase125Subsystem() {
        super(125, "SPECIALIST_DEPTH", "SpecialistDepthSubsystem P125");
    }

    @Override
    public Map<String, Double> evaluate(Map<String, Double> input) {
        double depth = get(input, "depth", 0.5);
        double novelty = get(input, "novelty", 0.2);
        double score = depth * 0.75 + novelty * 0.25 + (125 % 13) * 0.01;
        setHealth(depth);
        return out("depthScore", score);
    }
}
