package com.hiveminemobile.ai.subsystems;

import java.util.Map;

/**
 * Unique subsystem instance per phase number. Evaluation formula depends on domain and phase id
 * so each of the 250 instances behaves differently.
 */
public final class PhaseSubsystem extends AbstractSubsystem {
    public PhaseSubsystem(int phase, String domain, String name) {
        super(phase, domain, name);
    }

    @Override
    public Map<String, Double> evaluate(Map<String, Double> input) {
        int n = phaseNumber();
        String d = domain();
        double score;
        if ("FOUNDATION".equals(d)) {
            double stability = get(input, "stability", 0.8);
            double init = get(input, "init", 1.0);
            score = (stability * 0.6 + init * 0.4) * (1.0 + (n % 7) * 0.01);
        } else if ("MANAGER".equals(d)) {
            double load = get(input, "load", 0.3);
            double backlog = get(input, "backlog", 0.0);
            score = Math.max(0, 1.0 - load - backlog * 0.2) + (n % 5) * 0.02;
        } else if ("SPECIALIST".equals(d)) {
            double conf = get(input, "confidence", 0.5);
            double evidence = get(input, "evidence", 0.5);
            score = conf * 0.7 + evidence * 0.3 + (n % 11) * 0.01;
            setHealth(conf);
            return out("specialistScore", score);
        } else if ("INTEGRATION".equals(d)) {
            double connected = get(input, "connected", 0.0);
            double authorized = get(input, "authorized", 0.0);
            score = connected * 0.5 + authorized * 0.5 + (n % 3) * 0.05;
            setHealth(connected > 0.5 ? 1.0 : 0.2);
            return out("integrationReadiness", score);
        } else if ("FARMING".equals(d)) {
            double pollenRate = get(input, "pollenRate", 0.4);
            double bag = get(input, "bagFill", 0.2);
            score = pollenRate * (1.0 - bag * 0.5) + (n % 9) * 0.015;
        } else if ("AUTOMATION".equals(d)) {
            double running = get(input, "running", 0.0);
            double faults = get(input, "faults", 0.0);
            score = running * 0.8 + Math.max(0, 1.0 - faults) * 0.2 + (n % 4) * 0.03;
            setHealth(faults > 3 ? 0.3 : 1.0);
            return out("automationHealth", score);
        } else if ("MANAGER_INTEL".equals(d)) {
            double goalFit = get(input, "goalFit", 0.5);
            double risk = get(input, "risk", 0.2);
            score = goalFit * (1.0 - risk) + (n % 6) * 0.02;
            setHealth(1.0 - risk);
            return out("intelScore", score);
        } else if ("OPTIMIZE".equals(d)) {
            double latency = get(input, "latencyMs", 50);
            score = Math.max(0, 1.0 - latency / 500.0) + (n % 8) * 0.01;
        } else if ("DATA".equals(d)) {
            double freshness = get(input, "freshness", 0.7);
            double completeness = get(input, "completeness", 0.7);
            score = freshness * 0.5 + completeness * 0.5 + (n % 10) * 0.01;
            setHealth(freshness);
            return out("dataQuality", score);
        } else if ("SPECIALIST_DEPTH".equals(d)) {
            double depth = get(input, "depth", 0.5);
            double novelty = get(input, "novelty", 0.2);
            score = depth * 0.75 + novelty * 0.25 + (n % 13) * 0.01;
            setHealth(depth);
            return out("depthScore", score);
        } else if ("UI".equals(d)) {
            double clarity = get(input, "clarity", 0.8);
            score = clarity * (0.9 + (n % 5) * 0.02);
            setHealth(clarity);
            return out("uiScore", score);
        } else if ("MERGE".equals(d)) {
            double adapter = get(input, "adapterReady", 0.0);
            double contract = get(input, "contractOk", 1.0);
            score = adapter * 0.7 + contract * 0.3 + (n % 4) * 0.02;
            setHealth(adapter > 0.5 ? 1.0 : 0.4);
            return out("mergeScore", score);
        } else {
            double tests = get(input, "testsPass", 1.0);
            double docs = get(input, "docs", 0.8);
            score = tests * 0.8 + docs * 0.2 + (n % 7) * 0.01;
            setHealth(tests);
            return out("releaseScore", score);
        }
        setHealth(Math.min(1.0, Math.max(0.0, score)));
        return out("score", score);
    }
}
