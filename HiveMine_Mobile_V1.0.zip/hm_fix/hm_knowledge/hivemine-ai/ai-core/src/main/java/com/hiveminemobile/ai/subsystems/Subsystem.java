package com.hiveminemobile.ai.subsystems;

import java.util.Map;

public interface Subsystem {
    int phaseNumber();
    String id();
    String domain();
    String name();
    Map<String, Double> evaluate(Map<String, Double> input);
    double health();
}
