package com.hiveminemobile.ai.task;

/** Requested importance of a task. Weights feed PriorityScorer. */
public enum Priority {
    LOW(1), NORMAL(2), HIGH(3), CRITICAL(4);

    private final int weight;

    Priority(int weight) { this.weight = weight; }

    public int getWeight() { return weight; }
}
