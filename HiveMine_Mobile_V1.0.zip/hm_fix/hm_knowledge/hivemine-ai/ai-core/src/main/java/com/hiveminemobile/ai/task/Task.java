package com.hiveminemobile.ai.task;

/**
 * Immutable snapshot of one unit of HiveMineManagerAI work. A task names a capability that a
 * specialist must offer; it carries no input, gesture or device command.
 */
public final class Task {
    public static final int MAX_TITLE_LENGTH = 120;
    public static final int MAX_NOTE_LENGTH = 512;

    private final String id;
    private final String title;
    private final String capability;
    private final Priority priority;
    private final TaskCategory category;
    private final TaskStatus status;
    private final String assignee;
    private final int attempts;
    private final String note;
    private final long createdAtMillis;
    private final long updatedAtMillis;

    Task(String id, String title, String capability, Priority priority, TaskCategory category,
         TaskStatus status, String assignee, int attempts, String note,
         long createdAtMillis, long updatedAtMillis) {
        this.id = id;
        this.title = title;
        this.capability = capability;
        this.priority = priority;
        this.category = category;
        this.status = status;
        this.assignee = assignee;
        this.attempts = attempts;
        this.note = note;
        this.createdAtMillis = createdAtMillis;
        this.updatedAtMillis = updatedAtMillis;
    }

    Task withState(TaskStatus newStatus, String newAssignee, int newAttempts, String newNote, long nowMillis) {
        return new Task(id, title, capability, priority, category, newStatus, newAssignee,
            newAttempts, newNote, createdAtMillis, nowMillis);
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getCapability() { return capability; }
    public Priority getPriority() { return priority; }
    public TaskCategory getCategory() { return category; }
    public TaskStatus getStatus() { return status; }
    /** Specialist currently holding the task, or null when it is queued or closed without an owner. */
    public String getAssignee() { return assignee; }
    /** Assignments made so far, which equals failed attempts while the task is PENDING. */
    public int getAttempts() { return attempts; }
    public String getNote() { return note; }
    public long getCreatedAtMillis() { return createdAtMillis; }
    public long getUpdatedAtMillis() { return updatedAtMillis; }
}
