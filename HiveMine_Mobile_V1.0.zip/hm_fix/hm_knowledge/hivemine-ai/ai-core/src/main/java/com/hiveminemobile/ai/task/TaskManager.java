package com.hiveminemobile.ai.task;

import com.hiveminemobile.ai.Identifiers;
import com.hiveminemobile.ai.specialist.SpecialistRegistry;
import com.hiveminemobile.ai.specialist.SpecialistStatus;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Creates, assigns and tracks tasks. Assignment picks only a registered specialist that offers the
 * required capability and passes the gate. Nothing here performs gameplay or device actions.
 */
public final class TaskManager {
    public enum Outcome {
        OK, NOT_FOUND, WRONG_STATE, NOT_ASSIGNEE, NO_SPECIALIST, REFUSED, INVALID, QUEUE_FULL, NOT_RUNNING
    }

    public static final class Result {
        private final Outcome outcome;
        private final Task task;
        private final String message;

        private Result(Outcome outcome, Task task, String message) {
            this.outcome = outcome;
            this.task = task;
            this.message = message;
        }

        public static Result of(Outcome outcome, Task task, String message) {
            return new Result(outcome, task, message == null ? "" : message);
        }

        public Outcome getOutcome() { return outcome; }
        public Task getTask() { return task; }
        public String getMessage() { return message; }
        public boolean isOk() { return outcome == Outcome.OK; }
    }

    private final SpecialistRegistry specialists;
    private final AssignmentGate gate;
    private final int maxAttempts;
    private final int maxOpenTasks;
    private final Map<String, Task> tasks = new LinkedHashMap<>();
    private long nextNumber = 1L;

    public TaskManager(SpecialistRegistry specialists, AssignmentGate gate, int maxAttempts, int maxOpenTasks) {
        if (specialists == null) throw new IllegalArgumentException("specialists must not be null");
        if (gate == null) throw new IllegalArgumentException("gate must not be null");
        if (maxAttempts < 1 || maxOpenTasks < 1) throw new IllegalArgumentException("limits must be at least 1");
        this.specialists = specialists;
        this.gate = gate;
        this.maxAttempts = maxAttempts;
        this.maxOpenTasks = maxOpenTasks;
    }

    public synchronized Result create(String title, String capability, Priority priority,
                                      TaskCategory category, long nowMillis) {
        String name = title == null ? "" : title.trim();
        if (name.isEmpty() || name.length() > Task.MAX_TITLE_LENGTH) {
            return Result.of(Outcome.INVALID, null,
                "Title is missing or longer than " + Task.MAX_TITLE_LENGTH + " characters");
        }
        if (!Identifiers.isValid(capability)) return Result.of(Outcome.INVALID, null, "Capability identifier is invalid");
        if (priority == null || category == null) {
            return Result.of(Outcome.INVALID, null, "Priority and category are required");
        }
        if (openCount() >= maxOpenTasks) return Result.of(Outcome.QUEUE_FULL, null, "Open task limit reached");
        String id = "task-" + nextNumber++;
        Task task = new Task(id, name, capability, priority, category, TaskStatus.PENDING, null, 0,
            "Created", nowMillis, nowMillis);
        tasks.put(id, task);
        return Result.of(Outcome.OK, task, "Task created");
    }

    public synchronized Result assign(String taskId, long nowMillis) {
        Task task = tasks.get(taskId);
        if (task == null) return notFound(taskId);
        if (task.getStatus() != TaskStatus.PENDING) {
            return Result.of(Outcome.WRONG_STATE, task, "Only pending tasks can be assigned");
        }
        List<String> candidates = candidatesFor(task.getCapability());
        if (candidates.isEmpty()) {
            return Result.of(Outcome.NO_SPECIALIST, task, "No available specialist offers " + task.getCapability());
        }
        String refusal = "No specialist passed the assignment gate";
        for (String candidate : candidates) {
            String reason = gate.refuse(task, candidate);
            if (reason == null) {
                Task updated = task.withState(TaskStatus.ASSIGNED, candidate, task.getAttempts() + 1,
                    "Assigned to " + candidate, nowMillis);
                tasks.put(taskId, updated);
                return Result.of(Outcome.OK, updated, "Task assigned to " + candidate);
            }
            refusal = reason;
        }
        return Result.of(Outcome.REFUSED, task, refusal);
    }

    public synchronized Result start(String taskId, String specialistId, long nowMillis) {
        Task task = tasks.get(taskId);
        if (task == null) return notFound(taskId);
        if (!Objects.equals(specialistId, task.getAssignee())) {
            return Result.of(Outcome.NOT_ASSIGNEE, task, "Only the assigned specialist can work on this task");
        }
        if (task.getStatus() != TaskStatus.ASSIGNED) {
            return Result.of(Outcome.WRONG_STATE, task, "Task must be assigned before it starts");
        }
        Task updated = task.withState(TaskStatus.IN_PROGRESS, task.getAssignee(), task.getAttempts(),
            "Started by " + specialistId, nowMillis);
        tasks.put(taskId, updated);
        return Result.of(Outcome.OK, updated, "Task started");
    }

    public synchronized Result complete(String taskId, String specialistId, String summary, long nowMillis) {
        Task task = tasks.get(taskId);
        if (task == null) return notFound(taskId);
        if (!Objects.equals(specialistId, task.getAssignee())) {
            return Result.of(Outcome.NOT_ASSIGNEE, task, "Only the assigned specialist can complete this task");
        }
        if (task.getStatus() != TaskStatus.IN_PROGRESS) {
            return Result.of(Outcome.WRONG_STATE, task, "Task must be in progress to complete");
        }
        Task updated = task.withState(TaskStatus.COMPLETED, task.getAssignee(), task.getAttempts(),
            clip(summary, "Completed"), nowMillis);
        tasks.put(taskId, updated);
        return Result.of(Outcome.OK, updated, "Task completed");
    }

    public synchronized Result fail(String taskId, String specialistId, String reason, long nowMillis) {
        Task task = tasks.get(taskId);
        if (task == null) return notFound(taskId);
        if (!Objects.equals(specialistId, task.getAssignee())) {
            return Result.of(Outcome.NOT_ASSIGNEE, task, "Only the assigned specialist can report this failure");
        }
        if (task.getStatus() != TaskStatus.ASSIGNED && task.getStatus() != TaskStatus.IN_PROGRESS) {
            return Result.of(Outcome.WRONG_STATE, task, "Only assigned or running tasks can fail");
        }
        boolean exhausted = task.getAttempts() >= maxAttempts;
        String text = clip(reason, "No reason given");
        Task updated = task.withState(
            exhausted ? TaskStatus.FAILED : TaskStatus.PENDING,
            exhausted ? task.getAssignee() : null,
            task.getAttempts(),
            "Attempt " + task.getAttempts() + " failed: " + text + (exhausted ? " (no retries left)" : ""),
            nowMillis);
        tasks.put(taskId, updated);
        return Result.of(Outcome.OK, updated, exhausted ? "Task failed permanently" : "Task returned to the queue");
    }

    public synchronized Result cancel(String taskId, long nowMillis) {
        Task task = tasks.get(taskId);
        if (task == null) return notFound(taskId);
        if (!task.getStatus().isOpen()) return Result.of(Outcome.WRONG_STATE, task, "Closed tasks cannot be cancelled");
        Task updated = task.withState(TaskStatus.CANCELLED, task.getAssignee(), task.getAttempts(),
            "Cancelled", nowMillis);
        tasks.put(taskId, updated);
        return Result.of(Outcome.OK, updated, "Task cancelled");
    }

    public synchronized Task get(String taskId) {
        return taskId == null ? null : tasks.get(taskId);
    }

    /** Tasks in creation order, optionally filtered by status (null means all). */
    public synchronized List<Task> list(TaskStatus status) {
        List<Task> matches = new ArrayList<>();
        for (Task task : tasks.values()) {
            if (status == null || task.getStatus() == status) matches.add(task);
        }
        return Collections.unmodifiableList(matches);
    }

    /** Highest-ranked pending tasks, best first, using PriorityScorer. */
    public synchronized List<Task> nextPending(long nowMillis, int limit) {
        if (limit < 1) throw new IllegalArgumentException("limit must be at least 1");
        List<Task> ranked = PriorityScorer.rank(list(TaskStatus.PENDING), nowMillis);
        return Collections.unmodifiableList(new ArrayList<>(ranked.subList(0, Math.min(limit, ranked.size()))));
    }

    public synchronized int openCount() {
        int count = 0;
        for (Task task : tasks.values()) if (task.getStatus().isOpen()) count++;
        return count;
    }

    /** Number of tasks a specialist is holding right now (assigned or in progress). */
    public synchronized int loadOf(String specialistId) {
        int count = 0;
        for (Task task : tasks.values()) {
            boolean active = task.getStatus() == TaskStatus.ASSIGNED || task.getStatus() == TaskStatus.IN_PROGRESS;
            if (active && specialistId != null && specialistId.equals(task.getAssignee())) count++;
        }
        return count;
    }

    /** Specialists offering the capability: fully available first, then least loaded, then registration order. */
    private List<String> candidatesFor(String capability) {
        List<String> ids = new ArrayList<>(specialists.findByCapability(capability));
        Collections.sort(ids, new Comparator<String>() {
            @Override public int compare(String left, String right) {
                int byHealth = Integer.compare(healthRank(left), healthRank(right));
                return byHealth != 0 ? byHealth : Integer.compare(loadOf(left), loadOf(right));
            }
        });
        return ids;
    }

    private int healthRank(String specialistId) {
        return specialists.getStatus(specialistId) == SpecialistStatus.DEGRADED ? 1 : 0;
    }

    private static Result notFound(String taskId) {
        return Result.of(Outcome.NOT_FOUND, null, "No task with id " + taskId);
    }

    private static String clip(String text, String fallback) {
        String value = text == null || text.trim().isEmpty() ? fallback : text.trim();
        return value.length() > Task.MAX_NOTE_LENGTH ? value.substring(0, Task.MAX_NOTE_LENGTH) : value;
    }
}
