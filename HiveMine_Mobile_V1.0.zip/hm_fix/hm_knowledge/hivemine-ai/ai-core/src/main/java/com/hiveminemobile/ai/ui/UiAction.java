package com.hiveminemobile.ai.ui;
/** Actions the UI may request; handled by integration layer, not here. */
public enum UiAction {
    ENABLE_AI_CONTROL,
    DISABLE_AI_CONTROL,
    START_FARM_GOAL,
    STOP_GOAL,
    REFRESH_STATUS
}
