package com.hiveminemobile.ai.ui;
/** UI-facing read model for a future Android layer. */
public final class UiModel {
    public final String title;
    public final String statusLine;
    public final boolean aiControlEnabled;
    public final boolean macroRunning;
    public UiModel(String title, String statusLine, boolean aiControlEnabled, boolean macroRunning) {
        this.title = title == null ? "" : title;
        this.statusLine = statusLine == null ? "" : statusLine;
        this.aiControlEnabled = aiControlEnabled;
        this.macroRunning = macroRunning;
    }
}
