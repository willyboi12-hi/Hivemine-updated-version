package com.hiveminemobile.ai.ui;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
/** Builds UiModel from manager + macro status. */
public final class UiModelFactory {
    public UiModel from(ManagerGoal goal, MacroStatus status, boolean aiEnabled) {
        String g = goal == null ? "STANDBY" : goal.name();
        boolean running = status != null && status.isRunning();
        String line = "goal=" + g + " running=" + running;
        return new UiModel("HiveMineAI", line, aiEnabled, running);
    }
}
