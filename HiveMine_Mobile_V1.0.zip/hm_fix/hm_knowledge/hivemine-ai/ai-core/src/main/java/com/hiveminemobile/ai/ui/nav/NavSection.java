package com.hiveminemobile.ai.ui.nav;

/** Sidebar sections from the HIVEMINE AI UI spec. */
public enum NavSection {
    HOME("Home"),
    MACRO_SETUP("Macro Setup"),
    FARMING("Farming"),
    QUESTS("Quests"),
    LOOT("Loot & Collect"),
    AUTOMATION("Automation"),
    PLANS("Custom Plans"),
    STATISTICS("Statistics"),
    AI_MANAGER("AI Manager"),
    SYSTEMS("Systems"),
    LOGS("Activity Logs"),
    SETTINGS("Settings");

    public final String title;
    NavSection(String title) { this.title = title; }
}
