package com.hiveminemobile.ai.ui.screens;

import com.hiveminemobile.ai.bss.BssFields;
import com.hiveminemobile.ai.loot.BlenderCatalog;
import com.hiveminemobile.ai.ui.nav.NavSection;

import java.util.ArrayList;
import java.util.List;

/** Builds real screen content strings for each nav section (Android/web can render). */
public final class ScreenContent {
    public static final class Model {
        public final String title;
        public final String body;
        public final List<String> actions = new ArrayList<String>();
        public Model(String title, String body) { this.title = title; this.body = body; }
    }

    public Model render(ScreenState state) {
        if (state == null) return new Model("Error", "No state");
        switch (state.section) {
            case HOME: return home(state);
            case MACRO_SETUP: return macroSetup(state);
            case FARMING: return farming(state);
            case QUESTS: return quests(state);
            case LOOT: return loot(state);
            case AUTOMATION: return automation(state);
            case PLANS: return plans(state);
            case STATISTICS: return stats(state);
            case AI_MANAGER: return ai(state);
            case SYSTEMS: return systems(state);
            case LOGS: return logs(state);
            case SETTINGS: return settings(state);
            default: return new Model("Unknown", "");
        }
    }

    private Model home(ScreenState s) {
        String body = "Connection: " + (s.macroStatus.isConnected() ? "Connected" : "Disconnected") + "\n"
                + "Running: " + s.macroStatus.isRunning() + "\n"
                + "AI control: " + s.aiControlEnabled + "\n"
                + "Field: " + s.settings.get("field") + "\n"
                + "Task: " + s.currentTask + "\n"
                + "Note: Honey/pollen live values require macro bag reader on device.\n"
                + "Last plan: " + s.lastPlanSummary;
        Model m = new Model("Home", body);
        m.actions.add("Start Macro");
        m.actions.add("Stop Macro");
        m.actions.add("Preset: Farming Mode");
        m.actions.add("Preset: Quest Mode");
        m.actions.add("Preset: Balanced Progression");
        return m;
    }

    private Model macroSetup(ScreenState s) {
        StringBuilder sb = new StringBuilder();
        for (String k : s.settings.snapshot().keySet()) {
            sb.append(k).append(" = ").append(s.settings.get(k)).append("\n");
        }
        Model m = new Model("Macro Setup", sb.toString());
        m.actions.add("Save Configuration");
        m.actions.add("Reset Configuration");
        m.actions.add("Apply");
        return m;
    }

    private Model farming(ScreenState s) {
        StringBuilder sb = new StringBuilder("Current field: ").append(s.settings.get("field")).append("\n\nFields:\n");
        for (String f : BssFields.NAMES) sb.append(" - ").append(f).append("\n");
        sb.append("\nPattern: ").append(s.settings.get("pattern"))
                .append(" Size: ").append(s.settings.get("size"))
                .append("\nWalk first: ").append(s.settings.get("walkFirst"))
                .append("\nReturn to field: ").append(s.settings.get("returnToField"));
        Model m = new Model("Farming", sb.toString());
        m.actions.add("Set Field");
        m.actions.add("Apply Farming Preset");
        return m;
    }

    private Model quests(ScreenState s) {
        String body = "Quest smart: " + s.settings.get("questSmart") + "\n"
                + "Live quest progress is only available when the macro vision layer sees the quest board.\n"
                + "This screen will not invent completion percentages.";
        Model m = new Model("Quests", body);
        m.actions.add("Enable Quest Smart");
        m.actions.add("Disable Quest Smart");
        return m;
    }

    private Model loot(ScreenState s) {
        StringBuilder sb = new StringBuilder();
        sb.append("Task: ").append(s.currentTask).append("\n");
        sb.append("Field: ").append(s.settings.get("field")).append("\n\n");
        sb.append("Blender recipes (pick one — farms ingredients only):\n");
        for (String name : BlenderCatalog.displayNames()) {
            sb.append(" • ").append(name).append("\n");
        }
        sb.append("\nMacro will set the ingredient field. Craft at the Blender yourself.\n");
        Model m = new Model("Loot & Collect", sb.toString());
        for (String name : BlenderCatalog.displayNames()) {
            m.actions.add("Recipe: " + name);
        }
        m.actions.add("Plan: Tokens");
        return m;
    }

    private Model automation(ScreenState s) {
        String body = "Modules (supported):\n"
                + " - Farming Automation: walkFirst/returnToField/field/pattern\n"
                + " - Quest Automation: questSmart + quest taps\n"
                + " - Honey Conversion: fullAction/fullPercent\n"
                + " - Recovery: reset steps / stuck timers in macro\n"
                + "AI control enabled: " + s.aiControlEnabled;
        Model m = new Model("Automation", body);
        m.actions.add("Enable AI Control");
        m.actions.add("Disable AI Control");
        return m;
    }

    private Model plans(ScreenState s) {
        String body = "Custom plans use ordered supported steps only.\n"
                + "Example: set field -> enable quest smart -> convert when full -> start macro.\n"
                + "Last plan:\n" + s.lastPlanSummary;
        Model m = new Model("Custom Plans", body);
        m.actions.add("Run Last Plan");
        return m;
    }

    private Model stats(ScreenState s) {
        String body = "Statistics require device session data.\n"
                + "Unavailable here: live honey, pollen totals, charts.\n"
                + "Available: configuration snapshot and activity log counts (" + s.activityLog.size() + ").";
        return new Model("Statistics", body);
    }

    private Model ai(ScreenState s) {
        StringBuilder sb = new StringBuilder("AI Manager chat\n\n");
        int from = Math.max(0, s.chatHistory.size() - 8);
        for (int i = from; i < s.chatHistory.size(); i++) sb.append(s.chatHistory.get(i)).append("\n");
        Model m = new Model("AI Manager", sb.toString());
        m.actions.add("Send Command");
        return m;
    }

    private Model systems(ScreenState s) {
        StringBuilder sb = new StringBuilder();
        for (String k : s.systemHealth.keySet()) {
            sb.append(k).append(": ").append(s.systemHealth.get(k)).append("\n");
        }
        return new Model("Systems", sb.toString());
    }

    private Model logs(ScreenState s) {
        StringBuilder sb = new StringBuilder();
        int n = Math.min(30, s.activityLog.size());
        for (int i = 0; i < n; i++) sb.append(s.activityLog.get(i)).append("\n");
        if (n == 0) sb.append("No events yet.\n");
        return new Model("Activity Logs", sb.toString());
    }

    private Model settings(ScreenState s) {
        String body = "Appearance: dark theme (UI clients)\n"
                + "AI control: " + s.aiControlEnabled + "\n"
                + "Human mode: " + s.settings.get("humanMode") + " level " + s.settings.get("humanLevel") + "\n"
                + "Move speed: " + s.settings.get("moveSpeed") + "\n"
                + "Permissions: accessibility is required in HiveMine Mobile.";
        Model m = new Model("Settings", body);
        m.actions.add("Toggle AI Control");
        return m;
    }
}
