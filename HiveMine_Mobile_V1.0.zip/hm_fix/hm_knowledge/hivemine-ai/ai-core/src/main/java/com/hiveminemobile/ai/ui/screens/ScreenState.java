package com.hiveminemobile.ai.ui.screens;

import com.hiveminemobile.ai.bss.BssMacroSettings;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.ui.nav.NavSection;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Shared UI state for all screens — no fake stats. */
public final class ScreenState {
    public NavSection section = NavSection.HOME;
    public final BssMacroSettings settings = new BssMacroSettings();
    public MacroStatus macroStatus = MacroStatus.disconnected("not connected");
    public boolean aiControlEnabled;
    public String currentTask = "Idle";
    public final List<String> activityLog = new ArrayList<String>();
    public final List<String> chatHistory = new ArrayList<String>();
    public String lastPlanSummary = "";
    public int bagPercent = -1;
    public String scene = "UNKNOWN";
    public long lastMacroObservationAtMillis;
    public final Map<String, String> systemHealth = new LinkedHashMap<String, String>();

    public ScreenState() {
        systemHealth.put("Manager AI", "READY");
        systemHealth.put("Macro Communication", "UNKNOWN");
        systemHealth.put("Configuration", "READY");
        systemHealth.put("Farming Manager", "READY");
        systemHealth.put("Quest Manager", "READY");
        systemHealth.put("Task Scheduler", "READY");
        systemHealth.put("Recovery Manager", "READY");
        systemHealth.put("Logging", "READY");
    }

    public void log(String line) {
        activityLog.add(0, System.currentTimeMillis() + " " + line);
        while (activityLog.size() > 200) activityLog.remove(activityLog.size() - 1);
    }

    public void bindMacro(MacroStatus status) {
        macroStatus = status == null ? MacroStatus.disconnected("null") : status;
        systemHealth.put("Macro Communication", macroStatus.isConnected() ? "CONNECTED" : "DISCONNECTED");
        bagPercent = macroStatus.getBagPercent();
        scene = macroStatus.getScene();
        lastMacroObservationAtMillis = macroStatus.getObservedAtMillis();
        systemHealth.put("Screen Telemetry", bagPercent >= 0 || !"UNKNOWN".equals(scene) ? "OBSERVING" : "WAITING");
    }
}
