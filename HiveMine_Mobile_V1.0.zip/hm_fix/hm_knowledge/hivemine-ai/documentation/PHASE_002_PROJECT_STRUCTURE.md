# Phase 002 — HiveMineAI Project Creation

Status: IMPLEMENTED. Tests run: 419 passed, 0 failed (`bash tests/run.sh`). Not built as an APK; there is no Android SDK here.

## What this phase produced

- `ai-core/` — the Java 8, Android-free AI core. Its package is `com.hiveminemobile.ai`, the same package as HiveMine Mobile's existing `:ai-core` module, so the merge replaces files rather than renaming anything.
- `ai-core/.../control/` — the merge boundary:
  - `MacroPort` — the only interface through which HiveMineAI touches the macro: `start`, `stop`, `recover`, `readStatus`.
  - `MacroStatus` — what the macro reports: connected, running, note.
  - `AutomationController` — enforces the authorization rule. AI start and recover are refused until the user enables AI control. Stop is always forwarded. Every result is a request outcome, not a confirmed action.
- `tests/` — the JVM suite (`run.sh`, `RunTests`, one class per phase, integration tests, and `ControlTests`).
- `documentation/` — the Phase 001 inspection report, the reproducible inspection script, the ledger, and the phase documents.

## Merge safety

All 22 `ai-core` files shipped in the uploaded HiveMine Mobile v1.7.0 project are byte-identical in HiveMineAI. The merge is therefore additive: new files are added, and no existing file changes.

## Tests

- Suite: 419 passed, 0 failed.
- New in this phase: 10 checks in `ControlTests`, covering the authorization rule, forwarding of stop when AI control is disabled, the disconnected case, recover, the audit trail, and the port null check.
- The control tests use a fake `MacroPort`. Nothing in them touches Android or the real macro.

## Known limitations

- `MacroPort` has no implementation yet. The HiveMine Mobile adapter is written in Phase 042 (per the ledger) and is unverified until it compiles and runs on a device.
- Phase numbering between the earlier roadmap and the 250-phase prompt is unresolved. The phase documents here use the earlier roadmap's numbers.

## Next steps

- Resolve the numbering decision.
- Decide whether the adapter is added to HiveMine Mobile in a separate patch or merged directly.
