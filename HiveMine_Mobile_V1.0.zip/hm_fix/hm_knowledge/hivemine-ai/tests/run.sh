#!/usr/bin/env bash
# Builds and runs the HiveMine AI suite. Needs only a JDK, no Android SDK, no network.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="build/tests"
rm -rf "$OUT"
mkdir -p "$OUT"
SOURCES=$(find ai-core/src/main/java tests/unit -name '*.java')
if command -v javac >/dev/null 2>&1; then
  javac -encoding UTF-8 -Xlint:none -d "$OUT" $SOURCES
else
  java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -nowarn -d "$OUT" $SOURCES
fi
java -cp "$OUT" com.hiveminemobile.RunTests
