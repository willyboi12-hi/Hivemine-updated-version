package com.hiveminemobile;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIEngine;
import com.hiveminemobile.ai.AIErrorHandler;
import com.hiveminemobile.ai.AIException;
import com.hiveminemobile.ai.AIInterface;
import com.hiveminemobile.ai.AIRegistry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** JVM-only tests for the independent Phase 001 AI foundation. */
public final class AIArchitectureTests {
    private AIArchitectureTests() { }

    public static void run() {
        AIConfiguration configuration = AIConfiguration.builder()
            .put("environment", "test")
            .putBoolean("enabled", true)
            .putInt("maxWorkers", 4)
            .put("invalidBoolean", "sometimes")
            .put("invalidNumber", "four")
            .build();
        RunTests.check("test".equals(configuration.getString("environment", "prod")),
            "AI configuration reads string values");
        RunTests.check(configuration.getBoolean("enabled", false),
            "AI configuration reads boolean values");
        RunTests.check(configuration.getInt("maxWorkers", 1) == 4,
            "AI configuration reads integer values");
        RunTests.check(!configuration.getBoolean("invalidBoolean", false),
            "AI configuration uses fallback for malformed booleans");
        RunTests.check(configuration.getInt("invalidNumber", 7) == 7,
            "AI configuration uses fallback for malformed integers");
        boolean immutableConfiguration = false;
        try {
            configuration.asMap().put("newKey", "newValue");
        } catch (UnsupportedOperationException expected) {
            immutableConfiguration = true;
        }
        RunTests.check(immutableConfiguration,
            "AI configuration exposes an immutable value snapshot");

        AIRegistry registry = new AIRegistry();
        RecordingModule first = new RecordingModule("vision", "1.0.0");
        registry.register(first);
        RunTests.check(registry.size() == 1 && registry.get("vision") == first,
            "AI registry registers and retrieves a module");
        boolean duplicateRejected = false;
        try {
            registry.register(new RecordingModule("vision", "1.0.0"));
        } catch (IllegalArgumentException expected) {
            duplicateRejected = true;
        }
        RunTests.check(duplicateRejected, "AI registry rejects duplicate module IDs");
        RunTests.check(registry.unregister("vision") && registry.size() == 0,
            "AI registry unregisters a module");
        boolean invalidIdRejected = false;
        try {
            registry.register(new RecordingModule("Vision Module", "1.0.0"));
        } catch (IllegalArgumentException expected) {
            invalidIdRejected = true;
        }
        RunTests.check(invalidIdRejected, "AI registry rejects invalid module IDs");

        final List<String> lifecycle = new ArrayList<>();
        AIEngine engine = new AIEngine(configuration, new AIRegistry(), new AIErrorHandler());
        engine.register(new RecordingModule("vision", "1.0.0", lifecycle, false, false));
        engine.register(new RecordingModule("state", "1.0.0", lifecycle, false, false));
        RunTests.check(engine.getState() == AIEngine.State.NEW,
            "AI engine starts in NEW state");
        try {
            engine.initialize();
        } catch (AIException unexpected) {
            RunTests.check(false, "AI engine initializes healthy modules");
        }
        RunTests.check(engine.getState() == AIEngine.State.INITIALIZED,
            "AI engine enters INITIALIZED state");
        RunTests.check(lifecycle.size() == 2 && "init:vision".equals(lifecycle.get(0))
                && "init:state".equals(lifecycle.get(1)),
            "AI engine initializes modules in registration order");
        engine.start();
        RunTests.check(engine.isRunning() && engine.getState() == AIEngine.State.RUNNING,
            "AI engine enters RUNNING state");
        boolean lateRegistrationRejected = false;
        try {
            engine.register(new RecordingModule("late", "1.0.0"));
        } catch (IllegalStateException expected) {
            lateRegistrationRejected = true;
        }
        RunTests.check(lateRegistrationRejected,
            "AI engine rejects registration after initialization begins");
        engine.shutdown();
        RunTests.check(engine.getState() == AIEngine.State.STOPPED,
            "AI engine enters STOPPED state");
        RunTests.check(lifecycle.size() == 4 && "stop:state".equals(lifecycle.get(2))
                && "stop:vision".equals(lifecycle.get(3)),
            "AI engine shuts modules down in reverse order");

        final List<String> rollbackEvents = new ArrayList<>();
        AIErrorHandler errorHandler = new AIErrorHandler(5, null);
        AIEngine failingEngine = new AIEngine(configuration, new AIRegistry(), errorHandler);
        failingEngine.register(new RecordingModule("good", "1.0.0", rollbackEvents, false, false));
        failingEngine.register(new RecordingModule("broken", "1.0.0", rollbackEvents, true, false));
        boolean initializationFailed = false;
        try {
            failingEngine.initialize();
        } catch (AIException expected) {
            initializationFailed = true;
        }
        RunTests.check(initializationFailed && failingEngine.getState() == AIEngine.State.FAILED,
            "AI engine reports initialization failure");
        RunTests.check(rollbackEvents.size() == 4
                && "init:good".equals(rollbackEvents.get(0))
                && "init:broken".equals(rollbackEvents.get(1))
                && "stop:broken".equals(rollbackEvents.get(2))
                && "stop:good".equals(rollbackEvents.get(3)),
            "AI engine rolls back attempted modules in reverse order");
        RunTests.check(errorHandler.getHistory().size() == 1
                && errorHandler.getHistory().get(0).getComponentId().equals("broken"),
            "AI error handler records module initialization failures");
        failingEngine.shutdown();
        RunTests.check(failingEngine.getState() == AIEngine.State.STOPPED,
            "failed AI engine can be shut down cleanly");

        final List<String> shutdownEvents = new ArrayList<>();
        AIErrorHandler shutdownErrors = new AIErrorHandler(5, null);
        AIEngine shutdownEngine = new AIEngine(configuration, new AIRegistry(), shutdownErrors);
        shutdownEngine.register(new RecordingModule("first", "1.0.0", shutdownEvents, false, false));
        shutdownEngine.register(new RecordingModule("second", "1.0.0", shutdownEvents, false, true));
        try {
            shutdownEngine.initialize();
            shutdownEngine.start();
        } catch (AIException unexpected) {
            RunTests.check(false, "shutdown error test initializes modules");
        }
        shutdownEngine.shutdown();
        RunTests.check(shutdownEngine.getState() == AIEngine.State.STOPPED
                && shutdownEvents.size() == 4
                && "stop:second".equals(shutdownEvents.get(2))
                && "stop:first".equals(shutdownEvents.get(3)),
            "AI engine continues shutting down after a module cleanup error");
        RunTests.check(shutdownErrors.getHistory().size() == 1
                && "shutdown".equals(shutdownErrors.getHistory().get(0).getOperation()),
            "AI engine records module shutdown errors");

        AIErrorHandler boundedErrors = new AIErrorHandler(2, null);
        boundedErrors.report("core", "one", AIErrorHandler.Severity.WARNING,
            new IllegalStateException("first"));
        boundedErrors.report("core", "two", AIErrorHandler.Severity.ERROR,
            new IllegalStateException("second"));
        boundedErrors.report("core", "three", AIErrorHandler.Severity.ERROR,
            new IllegalStateException("third"));
        RunTests.check(boundedErrors.getHistory().size() == 2
                && "two".equals(boundedErrors.getHistory().get(0).getOperation()),
            "AI error history remains bounded");
    }

    private static final class RecordingModule implements AIInterface {
        private final String id;
        private final String version;
        private final List<String> events;
        private final boolean failInitialization;
        private final boolean failShutdown;

        RecordingModule(String id, String version) {
            this(id, version, new ArrayList<String>(), false, false);
        }

        RecordingModule(String id, String version, List<String> events,
                        boolean failInitialization, boolean failShutdown) {
            this.id = id;
            this.version = version;
            this.events = events;
            this.failInitialization = failInitialization;
            this.failShutdown = failShutdown;
        }

        @Override public String getId() { return id; }
        @Override public String getVersion() { return version; }
        @Override public Set<String> getCapabilities() {
            Set<String> capabilities = new LinkedHashSet<>();
            capabilities.add("analysis");
            return Collections.unmodifiableSet(capabilities);
        }
        @Override public void onInitialize(AIConfiguration configuration) throws Exception {
            events.add("init:" + id);
            if (failInitialization) throw new IllegalStateException("expected test failure");
        }
        @Override public void onShutdown() throws Exception {
            events.add("stop:" + id);
            if (failShutdown) throw new IllegalStateException("expected shutdown failure");
        }
    }
}
