package com.hiveminemobile;

import com.hiveminemobile.ai.farming.AdaptiveAdvisor;
import com.hiveminemobile.ai.farming.AdaptiveAdvisor.Action;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/** JVM-only tests for Phase 059 AdaptiveAdvisor. */
public final class AdaptiveAdvisorTests {
    private AdaptiveAdvisorTests() { }

    public static void run() {
        AdaptiveAdvisor advisor = new AdaptiveAdvisor(3, 0.10);
        Map<String, java.util.List<Double>> results = new HashMap<>();
        results.put("current", Arrays.asList(10.0, 10.0, 10.0));
        results.put("better", Arrays.asList(12.0, 12.0, 12.0));
        RunTests.check(advisor.advise("current", results).getAction() == Action.SWITCH
                && "better".equals(advisor.advise("current", results).getTarget()),
            "phase 059: a candidate that beats the current strategy by the margin is recommended");

        results.put("better", Arrays.asList(10.5, 10.5, 10.5));
        RunTests.check(advisor.advise("current", results).getAction() == Action.KEEP,
            "phase 059: a candidate inside the margin does not trigger a switch");

        results.put("current", Arrays.asList(10.0, 10.0));
        RunTests.check(advisor.advise("current", results).getAction() == Action.NEEDS_EVIDENCE,
            "phase 059: the current strategy needs the minimum number of verified runs");

        results.put("current", Arrays.asList(10.0, 10.0, 10.0));
        results.put("better", Arrays.asList(12.0));
        RunTests.check(advisor.advise("current", results).getAction() == Action.NEEDS_EVIDENCE,
            "phase 059: a candidate without enough verified runs is never recommended");
        boolean bad = false;
        try { new AdaptiveAdvisor(0, 0.1); } catch (IllegalArgumentException expected) { bad = true; }
        RunTests.check(bad, "phase 059: the minimum run count must be at least 1");
    }
}
