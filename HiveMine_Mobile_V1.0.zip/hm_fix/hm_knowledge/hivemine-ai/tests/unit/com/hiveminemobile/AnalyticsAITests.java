package com.hiveminemobile;

import com.hiveminemobile.ai.modules.AnalyticsAI;
import com.hiveminemobile.ai.modules.AnalyticsAI.Summary;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** JVM-only tests for Phase 028 AnalyticsAI. */
public final class AnalyticsAITests {
    private AnalyticsAITests() { }

    public static void run() {
        AnalyticsAI analytics = new AnalyticsAI();
        RunTests.check(analytics.getCapabilities().contains("analyze.statistics"), "phase 028 exposes analyze.statistics");

        Summary even = analytics.summarize(Arrays.asList(4.0, 1.0, 3.0, 2.0));
        RunTests.check(even.getCount() == 4 && even.getMean() == 2.5 && even.getMedian() == 2.5,
            "mean and median of an even-sized set are computed");
        RunTests.check(even.getMin() == 1.0 && even.getMax() == 4.0 && even.getP90() == 4.0,
            "min, max and the nearest-rank 90th percentile are computed");
        RunTests.check(analytics.summarize(Arrays.asList(5.0, 1.0, 3.0)).getMedian() == 3.0,
            "the median of an odd-sized set is the middle value");

        List<Double> ten = new ArrayList<>();
        for (int i = 1; i <= 10; i++) ten.add((double) i);
        RunTests.check(analytics.summarize(ten).getP90() == 9.0, "the 90th percentile of 1-10 is 9");

        RunTests.check(analytics.efficiency(120.0, 60.0) == 2.0, "efficiency is output per minute");
        boolean noMinutes = false;
        try { analytics.efficiency(10.0, 0.0); } catch (IllegalArgumentException expected) { noMinutes = true; }
        RunTests.check(noMinutes, "efficiency needs a positive duration");
        boolean empty = false;
        try { analytics.summarize(Collections.<Double>emptyList()); } catch (IllegalArgumentException expected) { empty = true; }
        RunTests.check(empty, "an empty value set is rejected");
        boolean nan = false;
        try { analytics.summarize(Arrays.asList(1.0, Double.NaN)); } catch (IllegalArgumentException expected) { nan = true; }
        RunTests.check(nan, "non-finite values are rejected");
    }
}
