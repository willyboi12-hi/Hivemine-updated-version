package com.hiveminemobile;

import com.hiveminemobile.ai.automation.*;
import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;

/** Phases 061–070 automation infrastructure checks. */
public final class AutomationInfrastructureTests {
    private AutomationInfrastructureTests() {}

    private static final class FakePort implements MacroPort {
        boolean connected = true;
        boolean running;
        int starts;
        int stops;
        int recovers;

        @Override public void start() { starts++; running = true; }
        @Override public void stop() { stops++; running = false; }
        @Override public void recover() { recovers++; running = false; }
        @Override public MacroStatus readStatus() {
            return connected ? MacroStatus.connected(running, running ? "farming" : "idle") : MacroStatus.disconnected("not bound");
        }
    }

    public static void run() {
        // 061 session
        AutomationSession s = new AutomationSession("s1", 1000);
        RunTests.check(s.phase() == AutomationSession.Phase.CREATED, "061 session starts CREATED");
        s.markActive(1500);
        RunTests.check(s.phase() == AutomationSession.Phase.ACTIVE, "061 session ACTIVE");
        RunTests.check(s.activeDurationMs(2500) == 1000, "061 active duration");
        s.markEnded(3000, "done");
        RunTests.check(s.phase() == AutomationSession.Phase.ENDED, "061 session ENDED");
        RunTests.check("done".equals(s.endReason()), "061 end reason");

        // 062 scheduler
        AutomationScheduler sch = new AutomationScheduler(100);
        RunTests.check(sch.due(0), "062 due initially");
        sch.markTick(0);
        RunTests.check(!sch.due(50), "062 not due before interval");
        RunTests.check(sch.due(100), "062 due at interval");
        sch.markTick(100);
        RunTests.check(sch.tickCount() == 2, "062 tick count");

        // 063 planner
        ActionPlanner planner = new ActionPlanner();
        FakePort port = new FakePort();
        MacroStatus idle = port.readStatus();
        RunTests.check(planner.plan(ActionPlanner.Goal.FARM, idle, false) == AutomationAction.START,
                "063 plan start when idle");
        port.running = true;
        RunTests.check(planner.plan(ActionPlanner.Goal.FARM, port.readStatus(), false) == AutomationAction.NONE,
                "063 no start when already running");
        RunTests.check(planner.plan(ActionPlanner.Goal.IDLE, port.readStatus(), false) == AutomationAction.STOP,
                "063 stop when goal idle");
        RunTests.check(planner.plan(ActionPlanner.Goal.FARM, port.readStatus(), true) == AutomationAction.STOP,
                "063 fault forces stop");

        // 064 queue
        CommandQueue q = new CommandQueue(3);
        RunTests.check(q.enqueue(AutomationAction.START), "064 enqueue start");
        RunTests.check(!q.enqueue(AutomationAction.START), "064 collapse duplicate start");
        RunTests.check(q.enqueue(AutomationAction.RECOVER), "064 enqueue recover");
        RunTests.check(q.enqueue(AutomationAction.STOP), "064 stop preempts");
        RunTests.check(q.size() == 1 && q.poll() == AutomationAction.STOP, "064 only stop remains");

        // 065 recovery
        RecoveryPolicy rp = new RecoveryPolicy(2);
        port.running = false;
        port.connected = true;
        RunTests.check(rp.shouldRecover(port.readStatus(), true), "065 recover when disconnected hint");
        rp.recordRecoveryAttempt();
        rp.recordRecoveryAttempt();
        RunTests.check(!rp.shouldRecover(port.readStatus(), true), "065 max recoveries");

        // 066 safety
        SafetyInterlock safety = new SafetyInterlock(5000, 2);
        safety.recordFailure("a");
        RunTests.check(!safety.isTripped(), "066 not tripped after 1");
        safety.recordFailure("b");
        RunTests.check(safety.isTripped(), "066 tripped after max failures");
        SafetyInterlock safety2 = new SafetyInterlock(1000, 5);
        safety2.checkSessionDuration(1001);
        RunTests.check(safety2.isTripped(), "066 max session trips");

        // 067 state machine
        AutomationStateMachine fsm = new AutomationStateMachine();
        RunTests.check(fsm.arm(), "067 arm from idle");
        RunTests.check(fsm.startRunning(), "067 running from armed");
        RunTests.check(fsm.beginStop(), "067 stopping");
        fsm.toIdle();
        RunTests.check(fsm.state() == AutomationState.IDLE, "067 back to idle");

        // 068 metrics
        AutomationMetrics m = new AutomationMetrics();
        m.tick(); m.startRequested(); m.stopRequested();
        RunTests.check(m.ticks() == 1 && m.startsRequested() == 1 && m.stopsRequested() == 1, "068 metrics");

        // 069/070 orchestrator integration
        FakePort fp = new FakePort();
        AutomationController ac = new AutomationController(fp);
        ac.setAiControlEnabled(true);
        AutomationOrchestrator orch = new AutomationOrchestrator(ac, fp, 100, 60_000L, 3, 5);
        RunTests.check(orch.arm("sess-1", 0), "069 arm session");
        orch.setGoal(ActionPlanner.Goal.FARM);
        RunTests.check(orch.tick(0), "069 first tick");
        RunTests.check(fp.starts >= 1, "069 start requested through port");
        RunTests.check(fp.running, "069 port running");
        orch.setGoal(ActionPlanner.Goal.IDLE);
        orch.tick(100);
        RunTests.check(!fp.running || fp.stops >= 1, "069 stop on idle goal");

        // Refuse path when AI control disabled
        FakePort fp2 = new FakePort();
        AutomationController ac2 = new AutomationController(fp2);
        // AI control left disabled
        AutomationOrchestrator orch2 = new AutomationOrchestrator(ac2, fp2, 100, 60_000L, 3, 5);
        orch2.arm("s2", 0);
        orch2.setGoal(ActionPlanner.Goal.FARM);
        orch2.tick(0);
        RunTests.check(fp2.starts == 0, "069 no start without AI control");
        RunTests.check(orch2.metrics().refusedCount() >= 1, "069 refused counted");

        // Emergency stop always works
        fp2.running = true;
        orch2.emergencyStop(50, "user");
        RunTests.check(fp2.stops >= 1, "069 emergency stop");

        // Max session safety
        FakePort fp3 = new FakePort();
        AutomationController ac3 = new AutomationController(fp3);
        ac3.setAiControlEnabled(true);
        AutomationOrchestrator orch3 = new AutomationOrchestrator(ac3, fp3, 100, 500L, 3, 5);
        orch3.arm("s3", 0);
        orch3.setGoal(ActionPlanner.Goal.FARM);
        orch3.tick(0);
        orch3.tick(100);
        orch3.tick(600);
        RunTests.check(orch3.safety().isTripped() || orch3.state() == AutomationState.FAULT
                        || !fp3.running,
                "069 session limit eventually stops or faults");
    }
}
