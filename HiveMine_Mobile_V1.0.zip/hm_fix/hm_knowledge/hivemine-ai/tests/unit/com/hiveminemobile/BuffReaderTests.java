package com.hiveminemobile;

import com.hiveminemobile.ai.observation.BuffReader;
import com.hiveminemobile.ai.observation.BuffReader.Buff;
import java.util.Arrays;
import java.util.List;

/** JVM-only tests for Phase 047 BuffReader. */
public final class BuffReaderTests {
    private BuffReaderTests() { }

    public static void run() {
        List<Buff> buffs = new BuffReader().read(Arrays.asList("Haste 3:20", "Honey Boost 1:00:00", "nonsense", "Bad 9:99"));
        RunTests.check(buffs.size() == 2, "phase 047: only lines with a valid time are buffs");
        RunTests.check("Honey Boost".equals(buffs.get(0).getName()) && buffs.get(0).getRemainingMillis() == 3_600_000L,
            "phase 047: multi-word buff names keep their full name");
        RunTests.check(buffs.get(1).getRemainingMillis() == 200_000L,
            "phase 047: buffs are ordered longest remaining first");
    }
}
