package com.hiveminemobile;

import com.hiveminemobile.ai.modules.CompatibilityAI;
import com.hiveminemobile.ai.modules.CompatibilityAI.Device;
import com.hiveminemobile.ai.modules.CompatibilityAI.Issue;
import com.hiveminemobile.ai.modules.CompatibilityAI.Requirements;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/** JVM-only tests for Phase 025 CompatibilityAI. */
public final class CompatibilityAITests {
    private CompatibilityAITests() { }

    private static final Set<String> PERMISSIONS =
        new java.util.LinkedHashSet<>(Arrays.asList("android.permission.INTERNET", "android.permission.FOREGROUND_SERVICE"));
    private static final Set<String> FEATURES = Collections.singleton("accessibility");

    public static void run() {
        CompatibilityAI compatibility = new CompatibilityAI();
        RunTests.check(compatibility.getCapabilities().contains("analyze.compatibility"),
            "phase 025 exposes analyze.compatibility");
        Requirements requirements = new Requirements(26, 2048, PERMISSIONS, FEATURES);

        List<Issue> fit = compatibility.check(new Device(30, 4096, PERMISSIONS, FEATURES), requirements);
        RunTests.check(fit.isEmpty() && CompatibilityAI.isCompatible(fit), "a device that meets every requirement is compatible");

        List<Issue> old = compatibility.check(new Device(24, 1024,
            Collections.singleton("android.permission.INTERNET"), Collections.<String>emptySet()), requirements);
        long blocking = old.stream().filter(Issue::isBlocking).count();
        RunTests.check(blocking == 3 && old.size() == 4 && !CompatibilityAI.isCompatible(old),
            "an old API, a missing permission and a missing feature are blocking; low memory is a warning");

        List<Issue> lowMemory = compatibility.check(new Device(30, 1024, PERMISSIONS, FEATURES), requirements);
        RunTests.check(lowMemory.size() == 1 && !lowMemory.get(0).isBlocking() && CompatibilityAI.isCompatible(lowMemory),
            "low memory alone is a warning and keeps the device compatible");

        boolean badApi = false;
        try { new Device(0, 0, PERMISSIONS, FEATURES); } catch (IllegalArgumentException expected) { badApi = true; }
        RunTests.check(badApi, "an Android API level must be positive");
    }
}
