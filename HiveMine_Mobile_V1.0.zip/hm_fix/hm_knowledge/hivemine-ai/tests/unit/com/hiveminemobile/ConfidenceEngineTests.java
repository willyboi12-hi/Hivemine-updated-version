package com.hiveminemobile;

import com.hiveminemobile.ai.shared.ConfidenceEngine;
import com.hiveminemobile.ai.shared.ConfidenceEngine.Evidence;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 038 ConfidenceEngine. */
public final class ConfidenceEngineTests {
    private ConfidenceEngineTests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        ConfidenceEngine engine = new ConfidenceEngine(60_000L);
        RunTests.check(engine.combine(Collections.singletonList(new Evidence("vision", 0.8, now)), now) == 0.8,
            "phase 038: a single fresh reading keeps its confidence");
        double two = engine.combine(Arrays.asList(new Evidence("vision", 0.5, now), new Evidence("ocr", 0.5, now)), now);
        RunTests.check(Math.abs(two - 0.75) < 1e-9, "phase 038: independent sources combine as 1 - product(1 - c)");
        double repeated = engine.combine(Arrays.asList(new Evidence("vision", 0.5, now), new Evidence("vision", 0.5, now)), now);
        RunTests.check(Math.abs(repeated - 0.5) < 1e-9, "phase 038: one source counts once, however many readings it gives");
        double aged = engine.combine(Collections.singletonList(new Evidence("vision", 0.8, now - 60_000L)), now);
        RunTests.check(Math.abs(aged - 0.4) < 1e-9, "phase 038: confidence halves after one half-life");
        RunTests.check(engine.combine(Collections.<Evidence>emptyList(), now) == 0.0,
            "phase 038: no evidence gives zero confidence");
        RunTests.check(ConfidenceEngine.shouldAct(0.8, 0.7) && !ConfidenceEngine.shouldAct(0.6, 0.7),
            "phase 038: the act decision compares against the threshold");
        boolean bad = false;
        try { new Evidence("vision", 1.1, now); } catch (IllegalArgumentException expected) { bad = true; }
        RunTests.check(bad, "phase 038: confidence must be between 0 and 1");
    }
}
