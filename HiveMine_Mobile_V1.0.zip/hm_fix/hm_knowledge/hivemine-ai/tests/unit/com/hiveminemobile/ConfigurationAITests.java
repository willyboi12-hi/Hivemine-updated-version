package com.hiveminemobile;

import com.hiveminemobile.ai.modules.ConfigurationAI;
import com.hiveminemobile.ai.modules.ConfigurationAI.Problem;
import com.hiveminemobile.ai.modules.ConfigurationAI.Rule;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** JVM-only tests for Phase 022 ConfigurationAI. */
public final class ConfigurationAITests {
    private ConfigurationAITests() { }

    public static void run() {
        ConfigurationAI configuration = new ConfigurationAI();
        RunTests.check(configuration.getCapabilities().contains("analyze.configuration"),
            "phase 022 exposes analyze.configuration");
        List<Rule> schema = Arrays.asList(
            Rule.integer("pollen-target", 0, 100),
            Rule.bool("auto-convert"),
            Rule.text("profile-name", 20));

        Map<String, String> good = new HashMap<>();
        good.put("pollen-target", "90");
        good.put("auto-convert", "true");
        good.put("profile-name", "main");
        RunTests.check(configuration.validate(good, schema).isEmpty(), "a complete, valid configuration has no problems");

        Map<String, String> bad = new HashMap<>();
        bad.put("pollen-target", "150");
        bad.put("auto-convert", "yes");
        List<Problem> problems = configuration.validate(bad, schema);
        RunTests.check(problems.size() == 3, "out-of-range, non-boolean and missing values are all reported");

        bad.put("profile-name", "main");
        bad.put("mystery", "x");
        List<Problem> unknown = configuration.validate(bad, schema);
        RunTests.check(unknown.stream().anyMatch(p -> "mystery".equals(p.getKey()) && "unknown key".equals(p.getMessage())),
            "unknown keys are reported, not kept");

        Map<String, String> words = new HashMap<>(good);
        words.put("pollen-target", "ninety");
        RunTests.check(configuration.validate(words, schema).get(0).getMessage().equals("must be a whole number"),
            "a non-numeric integer is reported as such");

        Map<String, String> base = new HashMap<>();
        base.put("a", "1");
        base.put("b", "2");
        Map<String, String> overrides = Collections.singletonMap("b", "3");
        Map<String, String> merged = configuration.merge(base, overrides);
        RunTests.check("1".equals(merged.get("a")) && "3".equals(merged.get("b")) && merged.size() == 2,
            "profile overrides replace base values and keep the rest");
        boolean badKey = false;
        try { configuration.merge(base, Collections.singletonMap("Bad Key", "x")); }
        catch (IllegalArgumentException expected) { badKey = true; }
        RunTests.check(badKey, "override keys must be valid identifiers");
        boolean badRange = false;
        try { Rule.integer("x", 5, 1); } catch (IllegalArgumentException expected) { badRange = true; }
        RunTests.check(badRange, "an integer rule with min above max is rejected");
    }
}
