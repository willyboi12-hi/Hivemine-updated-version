package com.hiveminemobile;

import com.hiveminemobile.ai.shared.ContextCompressor;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 036 ContextCompressor. */
public final class ContextCompressorTests {
    private ContextCompressorTests() { }

    public static void run() {
        ContextCompressor compressor = new ContextCompressor(10);
        ContextCompressor.Result collapsed = compressor.compress(Arrays.asList("a", "a", "a", "b", "a"));
        RunTests.check(collapsed.getLines().equals(Arrays.asList("a (x3)", "b", "a")),
            "phase 036: consecutive identical lines collapse into one counted line");
        RunTests.check(collapsed.getCollapsed() == 2 && collapsed.getInputCount() == 5,
            "phase 036: the compression is accounted for");

        ContextCompressor tight = new ContextCompressor(2);
        ContextCompressor.Result trimmed = tight.compress(Arrays.asList("one", "two", "three", "four"));
        RunTests.check(trimmed.getLines().equals(Arrays.asList("three", "four")) && trimmed.getOverflowDropped() == 2,
            "phase 036: when still too long, the newest lines are kept");
        RunTests.check(compressor.compress(Collections.<String>emptyList()).getLines().isEmpty(),
            "phase 036: an empty log compresses to nothing");
        boolean bad = false;
        try { new ContextCompressor(0); } catch (IllegalArgumentException expected) { bad = true; }
        RunTests.check(bad, "phase 036: a non-positive line limit is rejected");
    }
}
