package com.hiveminemobile;

import com.hiveminemobile.ai.shared.ContextEngine;

/** JVM-only tests for Phase 031 ContextEngine. */
public final class ContextEngineTests {
    private ContextEngineTests() { }

    public static void run() {
        long t0 = 1_800_000_000_000L;
        ContextEngine context = new ContextEngine();
        context.publish("field.current", "Pine Tree", "vision", t0, 60_000L);
        RunTests.check(context.query("field.current", t0 + 30_000L).getValue().equals("Pine Tree"),
            "phase 031: a fresh value is returned with its source");
        RunTests.check(context.query("field.current", t0 + 61_000L) == null,
            "phase 031: a value past its time-to-live is not returned");
        context.publish("field.current", "Sunflower", "state", t0 - 5_000L, 60_000L);
        RunTests.check(context.query("field.current", t0).getValue().equals("Pine Tree"),
            "phase 031: an older observation never replaces a newer one");
        context.publish("pollen.percent", "72", "vision", t0, 1_000L);
        RunTests.check(context.snapshot(t0 + 5_000L).containsKey("field.current")
                && !context.snapshot(t0 + 5_000L).containsKey("pollen.percent"),
            "phase 031: the snapshot holds only unexpired values");
        RunTests.check(context.expire(t0 + 5_000L) == 1, "phase 031: expire removes expired entries and reports the count");
        boolean blank = false;
        try { context.publish(" ", "x", "vision", t0, 1L); } catch (IllegalArgumentException expected) { blank = true; }
        RunTests.check(blank, "phase 031: a blank key is rejected");
    }
}
