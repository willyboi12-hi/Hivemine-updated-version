package com.hiveminemobile;

import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.AutomationController.Decision;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;

/** JVM-only tests for the HiveMineAI control boundary that the HiveMine Mobile merge relies on. */
public final class ControlTests {
    private ControlTests() { }

    /** Fake macro: records every request so tests can prove what did or did not reach it. */
    static final class FakePort implements MacroPort {
        boolean connected = true;
        boolean running = false;
        int starts;
        int stops;
        int recovers;

        @Override public void start() { starts++; if (connected) running = true; }
        @Override public void stop() { stops++; running = false; }
        @Override public void recover() { recovers++; }
        @Override public MacroStatus readStatus() {
            return connected ? MacroStatus.connected(running, "fake") : MacroStatus.disconnected("not bound");
        }
    }

    public static void run() {
        FakePort port = new FakePort();
        AutomationController control = new AutomationController(port);

        RunTests.check(control.requestStart() == Decision.REFUSED_NOT_ENABLED && port.starts == 0,
            "control boundary: AI cannot start the macro before the user enables AI control");
        RunTests.check(control.requestRecover() == Decision.REFUSED_NOT_ENABLED && port.recovers == 0,
            "control boundary: AI cannot recover the macro before the user enables AI control");

        control.setAiControlEnabled(true);
        RunTests.check(control.requestStart() == Decision.START_REQUESTED && port.starts == 1,
            "control boundary: once enabled, a start is forwarded to the macro");
        RunTests.check(control.requestStart() == Decision.REFUSED_ALREADY_RUNNING && port.starts == 1,
            "control boundary: a second start is refused while the macro is running");

        control.setAiControlEnabled(false);
        RunTests.check(control.requestStop() == Decision.STOP_REQUESTED && port.stops == 1 && !port.running,
            "control boundary: stop is forwarded even after the user disables AI control");

        control.setAiControlEnabled(true);
        port.connected = false;
        RunTests.check(control.requestStart() == Decision.REFUSED_NOT_CONNECTED && port.starts == 1,
            "control boundary: nothing is sent to a macro that is not connected");
        RunTests.check(control.requestStop() == Decision.REFUSED_NOT_CONNECTED && port.stops == 2,
            "control boundary: stop is still delivered when disconnected, but reported as not connected");

        port.connected = true;
        port.running = true;
        RunTests.check(control.requestRecover() == Decision.RECOVER_REQUESTED && port.recovers == 1,
            "control boundary: recover is forwarded once enabled and connected");
        RunTests.check(control.getAuditTrail().stream().anyMatch(e -> e.contains("REFUSED_NOT_ENABLED")),
            "control boundary: refusals are recorded in the audit trail");

        boolean nullPort = false;
        try { new AutomationController(null); } catch (IllegalArgumentException expected) { nullPort = true; }
        RunTests.check(nullPort, "control boundary: a controller needs a macro port");
    }
}
