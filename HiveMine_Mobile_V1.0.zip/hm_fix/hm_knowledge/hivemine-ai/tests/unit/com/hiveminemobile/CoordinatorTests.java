package com.hiveminemobile;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIException;
import com.hiveminemobile.ai.comm.AIMessage;
import com.hiveminemobile.ai.comm.MessageBus;
import com.hiveminemobile.ai.health.HealthMonitor;
import com.hiveminemobile.ai.manager.ManagerCoordinator;
import com.hiveminemobile.ai.task.Priority;
import com.hiveminemobile.ai.task.Task;
import com.hiveminemobile.ai.task.TaskCategory;
import com.hiveminemobile.ai.task.TaskManager;
import com.hiveminemobile.ai.task.TaskManager.Outcome;
import com.hiveminemobile.ai.task.TaskManager.Result;
import com.hiveminemobile.ai.task.TaskStatus;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** JVM-only integration tests: phases 005 through 010 working together through the coordinator. */
public final class CoordinatorTests {
    private CoordinatorTests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        AIConfiguration config = AIConfiguration.builder()
            .putInt("tasks.maxAttempts", 2)
            .putInt("health.errorThreshold", 3)
            .putInt("health.heartbeatTimeoutMillis", 30_000)
            .build();
        ManagerCoordinator core = new ManagerCoordinator(config);
        core.registerSpecialist(new StubAI("vision", "observe"));
        core.registerSpecialist(new StubAI("state", "analyze"));

        RunTests.check(core.createTask("Read bag", "observe", Priority.NORMAL, TaskCategory.OBSERVATION, now)
            .getOutcome() == Outcome.NOT_RUNNING, "stage 1: work is refused before the manager starts");
        RunTests.check(core.send("vision", "state", "observation.field", null, now).getStatus()
            == MessageBus.Status.REJECTED_NOT_RUNNING, "stage 1: messages are refused before the manager starts");

        try { core.start(); } catch (AIException failure) { RunTests.check(false, "stage 1 coordinator starts with valid specialists"); }
        RunTests.check(core.getManager().canCoordinate(), "stage 1 manager is running after start");

        Map<String, String> payload = new LinkedHashMap<>();
        payload.put("field", "Pine Tree");
        RunTests.check(core.send("vision", "state", "observation.field", payload, now).isAccepted(),
            "a running manager delivers messages between specialists");
        List<AIMessage> inbox = core.drain("state", 5);
        RunTests.check(inbox.size() == 1 && "Pine Tree".equals(inbox.get(0).getPayload().get("field")),
            "the recipient receives the message through its mailbox");

        Task task = core.createTask("Read bag", "observe", Priority.NORMAL, TaskCategory.OBSERVATION, now).getTask();
        Result refused = core.assignTask(task.getId(), now);
        RunTests.check(refused.getOutcome() == Outcome.REFUSED && refused.getMessage().contains("not granted"),
            "a capability the user has not granted cannot be assigned");
        core.getPolicy().grant("observe", now);
        core.heartbeat("vision", now);
        core.heartbeat("state", now);
        Result assigned = core.assignTask(task.getId(), now);
        RunTests.check(assigned.isOk() && "vision".equals(assigned.getTask().getAssignee()),
            "a granted capability is assigned to the specialist that offers it");
        RunTests.check(core.startTask(task.getId(), "vision", now).isOk(), "the assignee starts the task");
        RunTests.check(core.completeTask(task.getId(), "vision", "Pine Tree at 72%", now + 1_000L).isOk(),
            "the assignee completes the task");
        RunTests.check(core.getMemory().successRate("observe").isPresent()
                && core.getMemory().successRate("observe").getAsDouble() == 1.0,
            "completed work is recorded as a success in manager memory");

        Task flaky = core.createTask("Read quest", "observe", Priority.HIGH, TaskCategory.OBSERVATION, now).getTask();
        core.assignTask(flaky.getId(), now);
        Result attempt1 = core.failTask(flaky.getId(), "vision", "quest text blurred", now + 2_000L);
        RunTests.check(attempt1.isOk() && attempt1.getTask().getStatus() == TaskStatus.PENDING,
            "the first failed attempt returns the task to the queue");
        RunTests.check(core.assignTask(flaky.getId(), now + 3_000L).isOk(), "the retry is assigned");
        Result attempt2 = core.failTask(flaky.getId(), "vision", "quest text blurred", now + 4_000L);
        RunTests.check(attempt2.getTask().getStatus() == TaskStatus.FAILED,
            "a task fails permanently after its maximum attempts");
        RunTests.check(core.getMemory().forTask(flaky.getId()).size() == 2,
            "each failed attempt is written to manager memory");
        RunTests.check(core.getMemory().successRate("observe").isPresent()
                && Math.abs(core.getMemory().successRate("observe").getAsDouble() - 1.0 / 3) < 1e-9,
            "one success and two failures give a one-third success rate");

        Task urgent = core.createTask("Recover from disconnect", "observe", Priority.CRITICAL,
            TaskCategory.RECOVERY, now + 5_000L).getTask();
        Task routine = core.createTask("Log pollen", "observe", Priority.LOW,
            TaskCategory.MAINTENANCE, now + 5_000L).getTask();
        List<Task> next = core.nextTasks(now + 5_000L, 2);
        RunTests.check(next.size() == 2 && next.get(0).getId().equals(urgent.getId())
                && next.get(1).getId().equals(routine.getId()),
            "the most urgent pending work is ranked first");

        HealthMonitor.Report stale = core.checkHealth(now + 200_000L);
        RunTests.check(stale.getOverall() == HealthMonitor.Level.UNAVAILABLE,
            "missed heartbeats make the overall status unavailable");
        Result blocked = core.assignTask(urgent.getId(), now + 200_000L);
        RunTests.check(blocked.getOutcome() == Outcome.REFUSED && blocked.getMessage().contains("unavailable"),
            "a specialist with missed heartbeats is not given new work");
        core.heartbeat("vision", now + 201_000L);
        Result recovered = core.assignTask(urgent.getId(), now + 202_000L);
        RunTests.check(recovered.isOk() && "vision".equals(recovered.getTask().getAssignee()),
            "a specialist that resumes heartbeats is assigned work again");
        RunTests.check(core.checkHealth(now + 202_000L).getComponent("vision").getLevel()
                == HealthMonitor.Level.HEALTHY, "the resumed specialist reports healthy");

        Result cancelled = core.cancelTask(routine.getId(), now + 203_000L);
        RunTests.check(cancelled.isOk() && core.getMemory().recent(1).get(0).getDecision().equals("task cancelled"),
            "cancelling work is recorded in manager memory");

        core.shutdown();
        RunTests.check(core.send("vision", "state", "observation.field", null, now + 300_000L).getStatus()
            == MessageBus.Status.REJECTED_NOT_RUNNING, "shutdown stops message delivery");
        RunTests.check(core.checkHealth(now + 300_000L).getOverall() == HealthMonitor.Level.UNAVAILABLE,
            "a stopped manager reports unavailable overall");
        RunTests.check(core.createTask("Late", "observe", Priority.NORMAL, TaskCategory.OBSERVATION, now + 300_000L)
            .getOutcome() == Outcome.NOT_RUNNING, "shutdown stops new work");
    }
}
