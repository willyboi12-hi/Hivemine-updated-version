package com.hiveminemobile;

import com.hiveminemobile.ai.shared.DecisionTracker;
import com.hiveminemobile.ai.shared.DecisionTracker.State;
import java.util.Collections;

/** JVM-only tests for Phase 039 DecisionTracker. */
public final class DecisionTrackerTests {
    private DecisionTrackerTests() { }

    public static void run() {
        long t0 = 1_800_000_000_000L;
        DecisionTracker tracker = new DecisionTracker(60_000L);
        DecisionTracker.Decision sent = tracker.open("move", "walk to field", t0);
        RunTests.check(sent.getState() == State.PENDING,
            "phase 039: a decision that was sent is PENDING, never a success");
        RunTests.check(tracker.verifiedSuccessRate("move").isPresent() == false,
            "phase 039: pending decisions do not affect any success rate");
        RunTests.check(tracker.verify(sent.getId(), true).getState() == State.VERIFIED_SUCCESS,
            "phase 039: a verified outcome is recorded");
        boolean reverify = false;
        try { tracker.verify(sent.getId(), false); } catch (IllegalStateException expected) { reverify = true; }
        RunTests.check(reverify, "phase 039: a decision can be resolved only once");

        DecisionTracker.Decision stale = tracker.open("move", "rejoin server", t0);
        java.util.List<DecisionTracker.Decision> expired = tracker.expire(t0 + 61_000L);
        RunTests.check(expired.size() == 1 && expired.get(0).getState() == State.UNVERIFIED_TIMEOUT,
            "phase 039: an unverified decision past its deadline times out");
        RunTests.check(tracker.verifiedSuccessRate("move").getAsDouble() == 1.0,
            "phase 039: timed-out decisions stay out of the success rate");
        tracker.verify(tracker.open("move", "walk again", t0).getId(), false);
        RunTests.check(Math.abs(tracker.verifiedSuccessRate("move").getAsDouble() - 0.5) < 1e-9,
            "phase 039: the success rate is computed over verified outcomes only");
        RunTests.check(tracker.snapshot().get(stale.getId()).getState() == State.UNVERIFIED_TIMEOUT,
            "phase 039: the snapshot reflects the timed-out state");
        boolean unknown = false;
        try { tracker.verify(999L, true); } catch (IllegalArgumentException expected) { unknown = true; }
        RunTests.check(unknown, "phase 039: verifying an unknown decision is rejected");
        RunTests.check(Collections.unmodifiableMap(tracker.snapshot()).size() == 3,
            "phase 039: every decision is kept for history");
    }
}
