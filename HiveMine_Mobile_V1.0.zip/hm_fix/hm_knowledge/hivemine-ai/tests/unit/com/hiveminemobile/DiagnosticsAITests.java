package com.hiveminemobile;

import com.hiveminemobile.ai.AIErrorHandler;
import com.hiveminemobile.ai.health.HealthMonitor;
import com.hiveminemobile.ai.manager.ManagerHealth;
import com.hiveminemobile.ai.modules.DiagnosticsAI;
import com.hiveminemobile.ai.modules.DiagnosticsAI.Diagnostic;
import com.hiveminemobile.ai.specialist.SpecialistRegistry;
import com.hiveminemobile.ai.specialist.SpecialistStatus;
import java.util.Collections;
import java.util.List;

/** JVM-only tests for Phase 020 DiagnosticsAI. */
public final class DiagnosticsAITests {
    private DiagnosticsAITests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        DiagnosticsAI diagnostics = new DiagnosticsAI();
        RunTests.check(diagnostics.getCapabilities().contains("analyze.diagnostics"), "phase 020 exposes analyze.diagnostics");
        HealthMonitor monitor = new HealthMonitor(10_000L, 3);

        SpecialistRegistry healthy = TaskTests.registry();
        AIErrorHandler noErrors = new AIErrorHandler();
        List<Diagnostic> clear = diagnostics.diagnose(
            monitor.evaluate(ManagerHealth.Status.HEALTHY, healthy, noErrors, now),
            noErrors.getHistory(), 100, 0, 0);
        RunTests.check(clear.size() == 1 && "ALL_CLEAR".equals(clear.get(0).getCode()),
            "a healthy application reports a single all-clear");

        SpecialistRegistry broken = TaskTests.registry();
        broken.updateStatus("vision2", SpecialistStatus.FAILED);
        broken.updateStatus("state", SpecialistStatus.DEGRADED);
        AIErrorHandler errors = new AIErrorHandler();
        errors.report("state", "analyze", AIErrorHandler.Severity.CRITICAL, new RuntimeException("read failed"));
        List<Diagnostic> found = diagnostics.diagnose(
            monitor.evaluate(ManagerHealth.Status.HEALTHY, broken, errors, now),
            errors.getHistory(), 5, 5, 3);

        RunTests.check(hasCode(found, "COMPONENT_UNAVAILABLE", "vision2", DiagnosticsAI.Severity.CRITICAL),
            "an unavailable specialist is a critical finding for that component");
        RunTests.check(hasCode(found, "COMPONENT_DEGRADED", "state", DiagnosticsAI.Severity.WARNING),
            "a degraded specialist is a warning for that component");
        RunTests.check(hasCode(found, "CRITICAL_ERRORS", "state", DiagnosticsAI.Severity.CRITICAL),
            "critical errors are counted per component");
        RunTests.check(hasCode(found, "MESSAGE_REJECTIONS", "manager", DiagnosticsAI.Severity.WARNING),
            "a high share of refused messages is flagged");
        RunTests.check(hasCode(found, "STATE_STALE", null, DiagnosticsAI.Severity.WARNING),
            "several stale state values are flagged");
        RunTests.check(found.get(0).getSeverity() == DiagnosticsAI.Severity.CRITICAL
                && found.get(found.size() - 1).getSeverity() == DiagnosticsAI.Severity.WARNING,
            "findings are ordered most severe first");

        List<Diagnostic> small = diagnostics.diagnose(
            monitor.evaluate(ManagerHealth.Status.HEALTHY, healthy, noErrors, now),
            Collections.<AIErrorHandler.AIError>emptyList(), 2, 2, 2);
        RunTests.check(small.size() == 1 && "ALL_CLEAR".equals(small.get(0).getCode()),
            "too few messages or stale values to judge are not flagged");
    }

    private static boolean hasCode(List<Diagnostic> found, String code, String component,
                                   DiagnosticsAI.Severity severity) {
        for (Diagnostic diagnostic : found) {
            boolean sameComponent = component == null ? diagnostic.getComponent() == null
                : component.equals(diagnostic.getComponent());
            if (code.equals(diagnostic.getCode()) && sameComponent && diagnostic.getSeverity() == severity) return true;
        }
        return false;
    }
}
