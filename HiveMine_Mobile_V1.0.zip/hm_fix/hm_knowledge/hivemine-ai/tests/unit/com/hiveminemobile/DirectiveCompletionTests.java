package com.hiveminemobile;

import com.hiveminemobile.ai.comm.MessageBus;
import com.hiveminemobile.ai.communication.CommunicationFailureHandler;
import com.hiveminemobile.ai.communication.RequestValidator;
import com.hiveminemobile.ai.decision.DecisionEngine;
import com.hiveminemobile.ai.manager.*;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.manager.intel.ManagerPolicyEngine;

import java.util.Collections;
import java.util.HashMap;

public final class DirectiveCompletionTests {
    private DirectiveCompletionTests() {}

    public static void run() {
        MessageBus bus = new MessageBus(16);
        bus.register("manager");
        bus.register("farming");
        ManagerMessageRouter router = new ManagerMessageRouter(bus);
        HashMap<String, String> payload = new HashMap<String, String>();
        payload.put("k", "v");
        MessageBus.Receipt r = router.route("manager", "farming", "status", payload);
        RunTests.check(r.isAccepted(), "router send accepted");
        RunTests.check(router.audit().size() == 1, "router audit");

        ManagerTaskScheduler sched = new ManagerTaskScheduler();
        sched.submit(new ManagerTaskScheduler.WorkItem("1", "low", 1));
        sched.submit(new ManagerTaskScheduler.WorkItem("2", "high", 5));
        RunTests.check("2".equals(sched.pollNext().id), "scheduler priority");

        ManagerStateController st = new ManagerStateController();
        st.ready(); st.active();
        RunTests.check(st.state() == ManagerStateController.State.ACTIVE, "state active");

        ManagerFailureCoordinator fail = new ManagerFailureCoordinator();
        fail.record(ManagerFailureCoordinator.Kind.TRANSIENT, "blip", 1);
        RunTests.check(fail.count() == 1 && !fail.hasFatal(), "failure coord");

        ManagerSpecialistRegistry reg = new ManagerSpecialistRegistry();
        reg.loadDefaults();
        RunTests.check(reg.size() >= 20, "manager specialist registry " + reg.size());

        ManagerPerformanceMonitor perf = new ManagerPerformanceMonitor();
        perf.recordMs(10); perf.recordMs(30);
        RunTests.check(perf.samples() == 2 && perf.avgMs() == 20.0, "perf monitor");

        RequestValidator v = new RequestValidator();
        RunTests.check(v.valid("abc", "payload"), "request validator");
        RunTests.check(!v.valid("", "x"), "request validator reject empty id");

        CommunicationFailureHandler cfh = new CommunicationFailureHandler();
        for (int i = 0; i < 5; i++) cfh.onFailure("x");
        RunTests.check(cfh.shouldDegrade(), "comm failure degrade");

        DecisionEngine engine = new DecisionEngine(null);
        ManagerPolicyEngine.WorldFlags flags = new ManagerPolicyEngine.WorldFlags();
        flags.userWantsFarm = true;
        ManagerGoal g = engine.decide(flags, Collections.emptyList());
        RunTests.check(g == ManagerGoal.FARM_POLLEN, "decision engine farm");
        RunTests.check(!engine.explanations().isEmpty(), "decision explanations");

        ManagerDecisionCoordinator coord = new ManagerDecisionCoordinator(null);
        RunTests.check(coord.decide(flags, Collections.emptyList()) == ManagerGoal.FARM_POLLEN, "decision coordinator");
    }
}
