package com.hiveminemobile;

import com.hiveminemobile.ai.AIInterface;
import com.hiveminemobile.ai.modules.AnalyticsAI;
import com.hiveminemobile.ai.modules.DocumentationAI;
import com.hiveminemobile.ai.modules.DocumentationAI.Entry;
import com.hiveminemobile.ai.modules.StrategyAI;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** JVM-only tests for Phase 030 DocumentationAI. */
public final class DocumentationAITests {
    private DocumentationAITests() { }

    public static void run() {
        DocumentationAI documentation = new DocumentationAI();
        RunTests.check(documentation.getCapabilities().contains("document.report"), "phase 030 exposes document.report");

        List<Entry> entries = documentation.describe(Arrays.<AIInterface>asList(new StrategyAI(), new AnalyticsAI()));
        RunTests.check(entries.get(0).getId().equals("analytics") && entries.get(1).getId().equals("strategy"),
            "modules are described in id order");

        Map<String, String> phases = new HashMap<>();
        phases.put("021", "done");
        phases.put("020", "done");
        String report = documentation.buildReport("HiveMine AI", entries, phases);
        RunTests.check(report.startsWith("# HiveMine AI") && report.contains("## Modules") && report.contains("## Phase status"),
            "the report has a title and both sections");
        RunTests.check(report.indexOf("`analytics`") < report.indexOf("`strategy`"),
            "modules appear in sorted order in the report");
        RunTests.check(report.contains("analyze.statistics") && report.indexOf("- 020: done") < report.indexOf("- 021: done"),
            "capabilities and phase status are listed, phases in order");
        RunTests.check(report.equals(documentation.buildReport("HiveMine AI", entries, phases)),
            "the same inputs produce the same report");

        boolean badTitle = false;
        try { documentation.buildReport("  ", entries, phases); } catch (IllegalArgumentException expected) { badTitle = true; }
        RunTests.check(badTitle, "a blank report title is rejected");
        boolean badId = false;
        try { new Entry("Bad Id", "1.0.0", Collections.<String>emptySet()); } catch (IllegalArgumentException expected) { badId = true; }
        RunTests.check(badId, "module ids must be valid identifiers");
    }
}
