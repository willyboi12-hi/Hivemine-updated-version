package com.hiveminemobile;

import com.hiveminemobile.ai.shared.EventBus;
import com.hiveminemobile.ai.shared.EventBus.PublishResult;
import java.util.ArrayList;
import java.util.List;

/** JVM-only tests for Phase 032 EventBus. */
public final class EventBusTests {
    private EventBusTests() { }

    public static void run() {
        EventBus bus = new EventBus(2);
        List<String> seen = new ArrayList<>();
        bus.subscribe("state.changed", event -> seen.add("typed:" + event.getId()));
        bus.subscribe(EventBus.ANY, event -> seen.add("any:" + event.getId()));
        bus.subscribe("state.changed", event -> { throw new IllegalStateException("broken subscriber"); });

        RunTests.check(bus.publish("e1", "state.changed", "a", 1L) == PublishResult.QUEUED,
            "phase 032: an event is queued");
        RunTests.check(bus.publish("e1", "state.changed", "a", 1L) == PublishResult.DUPLICATE,
            "phase 032: a repeated event id is not processed twice");
        RunTests.check(bus.publish("e2", "state.changed", "b", 2L) == PublishResult.QUEUED
                && bus.publish("e3", "state.changed", "c", 3L) == PublishResult.FULL,
            "phase 032: a full queue refuses new events and counts them");
        RunTests.check(bus.dispatch() == 2, "phase 032: dispatch delivers every queued event");
        RunTests.check(seen.equals(java.util.Arrays.asList("typed:e1", "any:e1", "typed:e2", "any:e2")),
            "phase 032: events reach subscribers in publish order, typed before wildcard");
        RunTests.check(bus.getFailed() == 2 && bus.getDelivered() == 4,
            "phase 032: a failing subscriber is counted and does not stop the others");
        RunTests.check(bus.publish("e3", "state.changed", "c", 3L) == PublishResult.QUEUED,
            "phase 032: a dropped event can be published again once there is room");

        boolean wildcardPublish = false;
        try { bus.publish("e4", "*", "x", 4L); } catch (IllegalArgumentException expected) { wildcardPublish = true; }
        RunTests.check(wildcardPublish, "phase 032: '*' cannot be published as an event type");
    }
}
