package com.hiveminemobile;

import com.hiveminemobile.ai.modules.FarmingAI;
import com.hiveminemobile.ai.modules.FarmingAI.Report;
import com.hiveminemobile.ai.modules.FarmingAI.Sample;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** JVM-only tests for Phase 013 FarmingAI. */
public final class FarmingAITests {
    private FarmingAITests() { }

    public static void run() {
        FarmingAI farming = new FarmingAI();
        RunTests.check(farming.getCapabilities().contains("analyze.farming"), "phase 013 exposes analyze.farming");

        List<Sample> run = Arrays.asList(
            new Sample(0L, 0, 100L),
            new Sample(60_000L, 30, 100L),
            new Sample(120_000L, 60, 100L),
            new Sample(180_000L, 100, 130L),
            new Sample(240_000L, 100, 130L),
            new Sample(300_000L, 100, 130L),
            new Sample(360_000L, 10, 140L));
        Report report = farming.analyze(run);
        RunTests.check(Math.abs(report.getPollenPerMinute() - 100.0 / 3.0) < 1e-9,
            "pollen rate is points gained per minute while filling");
        RunTests.check(report.getConversions() == 1, "a drop of 50 points or more counts as one conversion");
        RunTests.check(report.getFullMillis() == 120_000L, "time spent at 100% is measured");
        RunTests.check(report.getHoneyChange() != null && report.getHoneyChange() == 40L,
            "honey change is taken between the first and last readings that show honey");
        RunTests.check(report.getRecommendations().size() == 1
                && report.getRecommendations().get(0).contains("sat at 100%"),
            "a bag left full for a minute or more gets a conversion recommendation");

        List<Sample> reversed = new ArrayList<>(run);
        Collections.reverse(reversed);
        Report unordered = farming.analyze(reversed);
        RunTests.check(Math.abs(unordered.getPollenPerMinute() - report.getPollenPerMinute()) < 1e-9
                && unordered.getConversions() == 1,
            "readings are ordered by time before analysis");

        Report single = farming.analyze(Collections.singletonList(new Sample(0L, 40, null)));
        RunTests.check(single.getPollenPerMinute() == 0.0 && single.getHoneyChange() == null
                && single.getRecommendations().get(0).contains("Not enough samples"),
            "a single reading reports no rate and asks for more samples");

        boolean badPollen = false;
        try { new Sample(0L, 101, null); } catch (IllegalArgumentException expected) { badPollen = true; }
        RunTests.check(badPollen, "pollen above 100 is rejected");
        boolean badHoney = false;
        try { new Sample(0L, 10, -1L); } catch (IllegalArgumentException expected) { badHoney = true; }
        RunTests.check(badHoney, "negative honey is rejected");
    }
}
