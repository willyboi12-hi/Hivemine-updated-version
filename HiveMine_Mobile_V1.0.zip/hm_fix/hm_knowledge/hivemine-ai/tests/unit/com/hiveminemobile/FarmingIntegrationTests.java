package com.hiveminemobile;

import com.hiveminemobile.ai.farming.AdaptiveAdvisor;
import com.hiveminemobile.ai.farming.FarmingReport;
import com.hiveminemobile.ai.farming.FarmingSimulation;
import com.hiveminemobile.ai.farming.FieldPerformance;
import com.hiveminemobile.ai.farming.PollenTracker;
import com.hiveminemobile.ai.farming.StrategyComparer;
import com.hiveminemobile.ai.modules.FarmingAI.Sample;
import com.hiveminemobile.ai.modules.SimulationAI.Scenario;
import com.hiveminemobile.ai.modules.SimulationAI.Strategy;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/** JVM-only pipeline for phases 051–060: rank, track, simulate, advise and report. */
public final class FarmingIntegrationTests {
    private FarmingIntegrationTests() { }

    public static void run() {
        StrategyComparer.Ranked best = new StrategyComparer().rank(Arrays.asList(
            new StrategyComparer.Option("pine-route", 2.0, 0.5), new StrategyComparer.Option("sun-route", 1.0, 0.5))).get(0);
        RunTests.check("pine-route".equals(best.getName()), "farming pipeline: the stronger approach ranks first");

        FieldPerformance.Ranked field = new FieldPerformance(1).rank(Arrays.asList(
            new FieldPerformance.Session("Pine Tree", 10, 40))).get(0);
        PollenTracker.Summary pollen = new PollenTracker().summarize(Arrays.asList(
            new Sample(0L, 0, null), new Sample(60_000L, 40, null)));
        RunTests.check(Math.abs(pollen.getRatePerMinute() - 40.0) < 1e-9 && "Pine Tree".equals(field.getField()),
            "farming pipeline: field and pollen figures are produced from recorded runs");

        FarmingSimulation.Result sim = new FarmingSimulation().run(
            Arrays.asList(new Strategy("pine-route", 2.0, 10.0, 5.0), new Strategy("sun-route", 1.0, 20.0, 0.0)),
            Collections.singletonList(new Scenario("calm", 0.0, 5.0)));
        Map<String, java.util.List<Double>> results = new HashMap<>();
        results.put("pine-route", Arrays.asList(60.0, 60.0, 60.0));
        results.put("sun-route", Arrays.asList(90.0, 90.0, 90.0));
        AdaptiveAdvisor.Recommendation advice = new AdaptiveAdvisor(3, 0.1).advise("pine-route", results);
        RunTests.check(advice.getAction() == AdaptiveAdvisor.Action.SWITCH && "sun-route".equals(advice.getTarget()),
            "farming pipeline: verified results drive a switch recommendation");

        String report = new FarmingReport().build("Run summary",
            Collections.singletonList(best), Collections.singletonList(field), pollen, null, sim, advice);
        RunTests.check(report.contains("pine-route") && report.contains("Pine Tree") && report.contains("SWITCH"),
            "farming pipeline: the report carries every supplied section");
    }
}
