package com.hiveminemobile;

import com.hiveminemobile.ai.farming.AdaptiveAdvisor;
import com.hiveminemobile.ai.farming.FarmingReport;
import com.hiveminemobile.ai.farming.FieldPerformance;
import com.hiveminemobile.ai.farming.StrategyComparer;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 060 FarmingReport. */
public final class FarmingReportTests {
    private FarmingReportTests() { }

    public static void run() {
        FarmingReport report = new FarmingReport();
        String partial = report.build("Farming report", null, null, null, null, null, null);
        RunTests.check(partial.startsWith("# Farming report") && partial.contains("Not available."),
            "phase 060: a missing section is shown as not available");
        String complete = report.build("Farming report",
            Collections.singletonList(new StrategyComparer.Ranked("A", 60.0)),
            Collections.singletonList(new FieldPerformance.Ranked("Pine Tree", 4.0, 2)),
            null, null, null,
            new AdaptiveAdvisor.Recommendation(AdaptiveAdvisor.Action.KEEP, null, "no change"));
        RunTests.check(complete.contains("- A: 60.0") && complete.contains("Pine Tree: 4.00 (2 sessions)")
                && complete.contains("KEEP: no change"),
            "phase 060: supplied sections appear with their values");
        RunTests.check(report.build("Again", null, null, null, null, null, null).equals(
                report.build("Again", null, null, null, null, null, null)),
            "phase 060: the same inputs produce the same report");
        boolean blank = false;
        try { report.build(" ", null, null, null, null, null, null); } catch (IllegalArgumentException expected) { blank = true; }
        RunTests.check(blank, "phase 060: a report needs a title");
    }
}
