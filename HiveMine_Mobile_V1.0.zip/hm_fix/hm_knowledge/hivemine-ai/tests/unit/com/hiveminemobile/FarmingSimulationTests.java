package com.hiveminemobile;

import com.hiveminemobile.ai.farming.FarmingSimulation;
import com.hiveminemobile.ai.modules.SimulationAI.Scenario;
import com.hiveminemobile.ai.modules.SimulationAI.Strategy;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 058 FarmingSimulation. */
public final class FarmingSimulationTests {
    private FarmingSimulationTests() { }

    public static void run() {
        FarmingSimulation simulation = new FarmingSimulation();
        FarmingSimulation.Result result = simulation.run(
            Arrays.asList(new Strategy("pollen-first", 2.0, 10.0, 5.0), new Strategy("quick", 1.0, 20.0, 0.0)),
            Collections.singletonList(new Scenario("calm", 0.0, 5.0)));
        RunTests.check("pollen-first".equals(result.getBestStrategy()) && Math.abs(result.getBestUnitsPerHour() - 80.0) < 1e-9,
            "phase 058: the best strategy in the simulation is selected");
        RunTests.check(Math.abs(result.getMarginOverNext() - 20.0) < 1e-9,
            "phase 058: the margin over the next strategy is reported");
        FarmingSimulation.Result single = simulation.run(
            Collections.singletonList(new Strategy("only", 1.0, 10.0, 0.0)),
            Collections.singletonList(new Scenario("calm", 0.0, 0.0)));
        RunTests.check(single.getMarginOverNext() == 0.0, "phase 058: a single strategy has no margin");
        boolean empty = false;
        try { simulation.run(Collections.<Strategy>emptyList(), Collections.singletonList(new Scenario("calm", 0.0, 0.0))); }
        catch (IllegalArgumentException expected) { empty = true; }
        RunTests.check(empty, "phase 058: at least one strategy is required");
    }
}
