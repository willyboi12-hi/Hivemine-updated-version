package com.hiveminemobile;

import com.hiveminemobile.ai.farming.FieldPerformance;
import com.hiveminemobile.ai.farming.FieldPerformance.Session;
import java.util.Arrays;
import java.util.List;

/** JVM-only tests for Phase 052 FieldPerformance. */
public final class FieldPerformanceTests {
    private FieldPerformanceTests() { }

    public static void run() {
        FieldPerformance performance = new FieldPerformance(2);
        List<FieldPerformance.Ranked> ranked = performance.rank(Arrays.asList(
            new Session("Pine Tree", 10, 50), new Session("Pine Tree", 10, 30),
            new Session("Sunflower", 5, 40),
            new Session("Dandelion", 10, 20), new Session("Dandelion", 10, 25)));
        RunTests.check(ranked.size() == 2 && ranked.get(0).getField().equals("Pine Tree")
                && Math.abs(ranked.get(0).getPollenPerMinute() - 4.0) < 1e-9,
            "phase 052: a field's rate is total pollen over total minutes, best first");
        RunTests.check(ranked.stream().noneMatch(r -> r.getField().equals("Sunflower")),
            "phase 052: a field with too few sessions is not ranked");
        boolean bad = false;
        try { new Session("x", 0, 1); } catch (IllegalArgumentException expected) { bad = true; }
        RunTests.check(bad, "phase 052: sessions must have positive duration");
    }
}
