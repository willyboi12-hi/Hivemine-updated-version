package com.hiveminemobile;

import com.hiveminemobile.ai.observation.FieldRecognizer;
import java.util.Arrays;

/** JVM-only tests for Phase 044 FieldRecognizer. */
public final class FieldRecognizerTests {
    private FieldRecognizerTests() { }

    public static void run() {
        FieldRecognizer fields = new FieldRecognizer(Arrays.asList("Pine Tree", "Sunflower Field", "Dandelion"));
        FieldRecognizer.Match typo = fields.match("Pine Tre");
        RunTests.check(typo != null && "Pine Tree".equals(typo.getField()) && typo.getDistance() == 1,
            "phase 044: a one-letter reading error still matches the field");
        RunTests.check(fields.match("  SUNFLOWER   field ") != null && fields.match("  SUNFLOWER   field ").getDistance() == 0,
            "phase 044: matching ignores case and extra spaces");
        RunTests.check(fields.match("Banana") == null, "phase 044: text that is not close to any field matches nothing");
        RunTests.check(fields.match("Pine") == null, "phase 044: a partial name too far from the full name is rejected");
        RunTests.check(new FieldRecognizer(Arrays.asList("ab", "ac")).match("ad") == null,
            "phase 044: two fields tying for the best match are rejected rather than guessed");
        boolean empty = false;
        try { new FieldRecognizer(Arrays.<String>asList()); } catch (IllegalArgumentException expected) { empty = true; }
        RunTests.check(empty, "phase 044: at least one known field is required");
    }
}
