package com.hiveminemobile;

import com.hiveminemobile.ai.state.GlobalStateManager;
import com.hiveminemobile.ai.state.StateDomain;
import com.hiveminemobile.ai.state.StateFact;
import com.hiveminemobile.ai.state.StateSnapshot;

/** JVM-only tests for Phase 004 Bee Swarm session-state aggregation. */
public final class GlobalStateTests {
    private GlobalStateTests() { }
    public static void run() {
        long now = 1_800_000_000_000L;
        GlobalStateManager state = new GlobalStateManager(2, 60_000L);
        StateFact field = fact("field.current", "Pine Tree", StateDomain.FIELD, "vision", now - 1000, .94);
        RunTests.check(state.update(field, now).getStatus() == GlobalStateManager.UpdateStatus.ACCEPTED,
            "phase 004 accepts a fresh recognized Bee Swarm field");
        RunTests.check("Pine Tree".equals(state.get("field.current").getValue()),
            "global state exposes current field observation");
        RunTests.check(state.isFresh("field.current", now), "freshness check accepts recent observation");
        RunTests.check(!state.isFresh("field.current", now + 120_000), "freshness check expires old observation");
        RunTests.check(state.getStaleKeys(now + 120_000).contains("field.current"),
            "stale state report identifies expired field fact");
        RunTests.check(state.update(fact("pollen.percent", "72", StateDomain.POLLEN, "vision", now - 500, .98), now).getStatus()
            == GlobalStateManager.UpdateStatus.ACCEPTED, "pollen capacity observation enters shared state");
        RunTests.check(state.update(fact("quest.active", "Brown Bear: collect pollen", StateDomain.QUEST, "vision", now - 400, .85), now).getStatus()
            == GlobalStateManager.UpdateStatus.ACCEPTED, "visible quest observation enters shared state");
        RunTests.check(Math.abs(state.getAverageConfidence(now) - ((.94 + .98 + .85) / 3.0)) < .0001,
            "average confidence uses fresh facts only");
        StateSnapshot snapshot = state.createSnapshot(now);
        RunTests.check(snapshot.getFacts().size() == 3, "snapshot captures the current Bee Swarm state");
        state.update(fact("field.current", "Sunflower Field", StateDomain.FIELD, "vision", now + 100, .99), now + 100);
        RunTests.check(state.getConflicts().size() == 1, "disagreeing fresh field observation is recorded as conflict");
        RunTests.check("Sunflower Field".equals(state.get("field.current").getValue()),
            "newer higher-confidence field observation becomes current while conflict remains recorded");
        state.restore(snapshot);
        RunTests.check("Pine Tree".equals(state.get("field.current").getValue()), "snapshot restore recovers prior state");
        RunTests.check(!state.getCurrentState().containsKey("missing"), "unknown state key returns no fabricated value");
        RunTests.check(state.update(fact("bad", "x", StateDomain.UI, "vision", now + 1, .5), now).getStatus()
            == GlobalStateManager.UpdateStatus.REJECTED, "future-dated observations are rejected");
        RunTests.check(state.update(fact("bad.conf", "x", StateDomain.UI, "vision", now, 1.5), now).getStatus()
            == GlobalStateManager.UpdateStatus.REJECTED, "out-of-range confidence is rejected");
        RunTests.check(state.update(fact("old", "x", StateDomain.UI, "vision", now - 90_000, .5), now).getStatus()
            == GlobalStateManager.UpdateStatus.REJECTED, "expired incoming observations are rejected");
        state.createSnapshot(now + 200); state.createSnapshot(now + 300);
        RunTests.check(state.getHistory().size() == 2, "snapshot history obeys configured retention limit");
        state.clearCurrentState();
        RunTests.check(state.getCurrentState().isEmpty(), "user-requested state clear empties current state");
    }
    private static StateFact fact(String key, String value, StateDomain domain, String source, long time, double confidence) {
        return new StateFact(key, value, domain, source, time, confidence);
    }
}
