package com.hiveminemobile;

import com.hiveminemobile.ai.AIErrorHandler;
import com.hiveminemobile.ai.health.HealthMonitor;
import com.hiveminemobile.ai.health.HealthMonitor.Level;
import com.hiveminemobile.ai.manager.ManagerHealth;
import com.hiveminemobile.ai.specialist.SpecialistRegistry;
import com.hiveminemobile.ai.specialist.SpecialistStatus;

/** JVM-only tests for Phase 010 health monitoring. */
public final class HealthTests {
    private HealthTests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        SpecialistRegistry registry = TaskTests.registry();
        AIErrorHandler errors = new AIErrorHandler();
        HealthMonitor monitor = new HealthMonitor(10_000L, 3);

        HealthMonitor.Report quiet = monitor.evaluate(ManagerHealth.Status.HEALTHY, registry, errors, now);
        RunTests.check(quiet.getOverall() == Level.HEALTHY, "phase 010 reports healthy when everything is normal");
        RunTests.check(quiet.getComponents().size() == 3 && quiet.getComponent("state").getLevel() == Level.HEALTHY,
            "every registered specialist gets a component report");

        monitor.heartbeat("vision", now);
        RunTests.check(monitor.evaluate(ManagerHealth.Status.HEALTHY, registry, errors, now + 5_000L)
                .getComponent("vision").getLevel() == Level.HEALTHY,
            "a fresh heartbeat keeps a specialist healthy");
        HealthMonitor.Report late = monitor.evaluate(ManagerHealth.Status.HEALTHY, registry, errors, now + 15_000L);
        RunTests.check(late.getComponent("vision").getLevel() == Level.DEGRADED && late.getOverall() == Level.DEGRADED,
            "a late heartbeat degrades the specialist and the overall status");
        HealthMonitor.Report silent = monitor.evaluate(ManagerHealth.Status.HEALTHY, registry, errors, now + 40_000L);
        RunTests.check(silent.getComponent("vision").getLevel() == Level.UNAVAILABLE
                && silent.getOverall() == Level.UNAVAILABLE,
            "a heartbeat missing for three timeouts marks the specialist unavailable");
        monitor.heartbeat("vision", now + 41_000L);
        RunTests.check(monitor.evaluate(ManagerHealth.Status.HEALTHY, registry, errors, now + 42_000L)
                .getComponent("vision").getLevel() == Level.HEALTHY,
            "a resumed heartbeat restores the specialist on the next check");
        monitor.forget("vision");
        RunTests.check(monitor.evaluate(ManagerHealth.Status.HEALTHY, registry, errors, now + 999_000L)
                .getComponent("vision").getLevel() == Level.HEALTHY,
            "a forgotten specialist is no longer judged by heartbeat");

        for (int i = 0; i < 3; i++) {
            errors.report("state", "analyze", AIErrorHandler.Severity.ERROR, new RuntimeException("read failed"));
        }
        HealthMonitor.Report erroring = monitor.evaluate(ManagerHealth.Status.HEALTHY, registry, errors, now);
        RunTests.check(erroring.getComponent("state").getLevel() == Level.DEGRADED
                && erroring.getComponent("state").getErrorCount() == 3,
            "repeated errors degrade the component that raised them");
        RunTests.check(erroring.getComponent("vision").getLevel() == Level.HEALTHY,
            "errors are attributed to their own component only");

        registry.updateStatus("vision2", SpecialistStatus.FAILED);
        RunTests.check(monitor.evaluate(ManagerHealth.Status.HEALTHY, registry, errors, now)
                .getComponent("vision2").getLevel() == Level.UNAVAILABLE,
            "a failed specialist is reported unavailable");
        registry.updateStatus("vision2", SpecialistStatus.AVAILABLE);
        RunTests.check(monitor.evaluate(ManagerHealth.Status.UNAVAILABLE, registry, errors, now).getOverall()
                == Level.UNAVAILABLE, "an unavailable manager makes the overall status unavailable");
        RunTests.check(monitor.evaluate(ManagerHealth.Status.DEGRADED, registry, errors, now).getOverall()
                == Level.DEGRADED, "a degraded manager maps to a degraded overall status");

        boolean badId = false;
        try { monitor.heartbeat("Bad Id", now); } catch (IllegalArgumentException expected) { badId = true; }
        RunTests.check(badId, "heartbeats from invalid component ids are rejected");
        boolean badTimeout = false;
        try { new HealthMonitor(0L, 3); } catch (IllegalArgumentException expected) { badTimeout = true; }
        RunTests.check(badTimeout, "a non-positive heartbeat timeout is rejected");
    }
}
