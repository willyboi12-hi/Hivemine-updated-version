package com.hiveminemobile;

import com.hiveminemobile.ai.farming.HoneyAnalysis;
import com.hiveminemobile.ai.farming.HoneyAnalysis.Point;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 054 HoneyAnalysis. */
public final class HoneyAnalysisTests {
    private HoneyAnalysisTests() { }

    private static final long HOUR = 3_600_000L;

    public static void run() {
        HoneyAnalysis honey = new HoneyAnalysis();
        HoneyAnalysis.Summary gain = honey.summarize(Arrays.asList(new Point(0L, 1000L), new Point(HOUR, 1500L)));
        RunTests.check(Math.abs(gain.getHoneyPerHour() - 500.0) < 1e-9 && gain.getNetChange() == 500L,
            "phase 054: honey per hour is the net change over the span");
        HoneyAnalysis.Summary spent = honey.summarize(Arrays.asList(
            new Point(0L, 1000L), new Point(HOUR, 900L), new Point(2 * HOUR, 1400L)));
        RunTests.check(spent.getDecreases() == 1 && spent.getNetChange() == 400L
                && Math.abs(spent.getHoneyPerHour() - 200.0) < 1e-9,
            "phase 054: decreases from spending are counted and included in the net change");
        boolean one = false;
        try { honey.summarize(Collections.singletonList(new Point(0L, 1L))); } catch (IllegalArgumentException expected) { one = true; }
        RunTests.check(one, "phase 054: at least two readings are needed");
        boolean negative = false;
        try { new Point(0L, -1L); } catch (IllegalArgumentException expected) { negative = true; }
        RunTests.check(negative, "phase 054: honey readings cannot be negative");
    }
}
