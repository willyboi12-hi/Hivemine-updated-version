package com.hiveminemobile;

import com.hiveminemobile.ai.integration.*;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;

public final class IntegrationTests {
    private IntegrationTests() {}
    public static void run() {
        IntegrationManifest m = new IntegrationManifest();
        m.put("automation", "0.70");
        m.put("manager-intel", "0.80");
        m.put("optimize", "0.90");
        RunTests.check(m.has("automation") && m.size() == 3, "091 manifest");

        IntegrationBus bus = new IntegrationBus(10);
        final int[] hits = new int[1];
        bus.subscribe(new IntegrationBus.Listener() {
            @Override public void onEvent(IntegrationEvent e) { hits[0]++; }
        });
        bus.publish(new IntegrationEvent("goal", "FARM", 1));
        RunTests.check(hits[0] == 1 && bus.history().size() == 1, "092 bus");

        RunTests.check(HiveMineMobileContract.hasCapability("start"), "093 contract start");
        RunTests.check(HiveMineMobileContract.summary().contains("MacroPort"), "093 contract text");

        IntegrationSmoke smoke = new IntegrationSmoke();
        RunTests.check(smoke.smoke(m), "094 smoke pass");

        ConfigBridge bridge = new ConfigBridge();
        RunTests.check("humanMode".equals(bridge.macroKey("human.mode")), "095 config bridge");

        LifecycleIntegrator life = new LifecycleIntegrator();
        RunTests.check(life.warm() && life.ready() && life.start(), "096 lifecycle");
        RunTests.check(life.phase() == LifecycleIntegrator.Phase.RUNNING, "096 running");
        RunTests.check(life.stop(), "096 stop");

        IntegrationHealthCheck hc = new IntegrationHealthCheck();
        life = new LifecycleIntegrator();
        life.warm(); life.ready();
        IntegrationHealthCheck.Result hr = hc.check(m, life);
        RunTests.check(hr.ok, "097 health ok");

        EndToEndSimulation.Result e2e = new EndToEndSimulation().runFarmPath();
        RunTests.check(e2e.goal == ManagerGoal.FARM_POLLEN, "098 e2e goal farm");
        RunTests.check(e2e.starts >= 1 && e2e.running, "098 e2e started macro fake");

        IntegrationReport rep = new IntegrationReport();
        String md = rep.toMarkdown(m, life, hr);
        RunTests.check(md.contains("Integration report") && md.contains("automation"), "099 report");
    }
}
