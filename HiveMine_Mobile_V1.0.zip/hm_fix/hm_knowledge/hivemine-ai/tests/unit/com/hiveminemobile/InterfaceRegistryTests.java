package com.hiveminemobile;

import com.hiveminemobile.ai.modules.VisionAI;
import com.hiveminemobile.ai.modules.VisionAI.Frame;
import com.hiveminemobile.ai.modules.VisionAI.Region;
import com.hiveminemobile.ai.modules.VisionAI.Signature;
import com.hiveminemobile.ai.observation.InterfaceRegistry;
import java.util.Collections;

/** JVM-only tests for Phase 042 InterfaceRegistry. */
public final class InterfaceRegistryTests {
    private InterfaceRegistryTests() { }

    private static Frame frame(boolean red, boolean green) {
        int w = 10;
        int h = 4;
        int[] pixels = new int[w * h];
        if (red) paint(pixels, w, 1, 2, 3, 2, 0xFF0000);
        if (green) paint(pixels, w, 6, 2, 2, 2, 0x00FF00);
        return new Frame(w, h, pixels);
    }

    private static void paint(int[] pixels, int w, int x, int y, int rw, int rh, int rgb) {
        for (int dy = 0; dy < rh; dy++) for (int dx = 0; dx < rw; dx++) pixels[(y + dy) * w + x + dx] = rgb;
    }

    public static void run() {
        InterfaceRegistry registry = new InterfaceRegistry();
        registry.define("hive", Collections.singletonList(new Signature("hive-marker", new Region(1, 2, 3, 2), 0xFF0000, 0, 0.9)), 1);
        registry.define("field", Collections.singletonList(new Signature("field-marker", new Region(6, 2, 2, 2), 0x00FF00, 0, 0.9)), 1);

        InterfaceRegistry.Identification hive = registry.identify(frame(true, false));
        RunTests.check("hive".equals(hive.getScreen()) && !hive.isAmbiguous(),
            "phase 042: a frame showing only the hive marker is identified as the hive");
        RunTests.check(registry.identify(frame(false, false)).getScreen() == null,
            "phase 042: a frame with no markers identifies no screen");
        InterfaceRegistry.Identification tie = registry.identify(frame(true, true));
        RunTests.check(tie.getScreen() == null && tie.isAmbiguous(),
            "phase 042: two screens qualifying equally is ambiguous and chooses nothing");

        boolean duplicate = false;
        try { registry.define("hive", Collections.singletonList(new Signature("x", new Region(0, 0, 1, 1), 0, 0, 0.5)), 1); }
        catch (IllegalArgumentException expected) { duplicate = true; }
        RunTests.check(duplicate, "phase 042: a screen can be defined only once");
        boolean badRequired = false;
        try { registry.define("shop", Collections.singletonList(new Signature("s", new Region(0, 0, 1, 1), 0, 0, 0.5)), 2); }
        catch (IllegalArgumentException expected) { badRequired = true; }
        RunTests.check(badRequired, "phase 042: a screen cannot require more markers than it defines");
    }
}
