package com.hiveminemobile;

import com.hiveminemobile.ai.modules.InventoryAI;
import com.hiveminemobile.ai.modules.InventoryAI.Change;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** JVM-only tests for Phase 015 InventoryAI. */
public final class InventoryAITests {
    private InventoryAITests() { }

    public static void run() {
        InventoryAI inventory = new InventoryAI();
        RunTests.check(inventory.getCapabilities().contains("analyze.inventory"), "phase 015 exposes analyze.inventory");

        Map<String, Integer> before = counts("honey", 100, "royal-jelly", 2);
        Map<String, Integer> after = counts("honey", 80, "royal-jelly", 5, "bee-tokens", 3);
        Map<String, Integer> spends = counts("honey", 20);
        List<Change> changes = inventory.compare(before, after, spends);
        RunTests.check(changes.size() == 3 && "bee-tokens".equals(changes.get(0).getItem()),
            "only changed items are reported, sorted by name");
        Change honey = changes.get(1);
        RunTests.check(honey.getDelta() == -20 && !honey.isUnexplained(),
            "a drop that matches a declared spend is explained");
        RunTests.check(changes.get(2).getDelta() == 3 && changes.get(0).getBefore() == 0,
            "a new item counts from zero");

        List<Change> unexplained = inventory.compare(before, counts("honey", 80, "royal-jelly", 2), null);
        RunTests.check(unexplained.size() == 1 && unexplained.get(0).isUnexplained(),
            "a drop with no declared spend is flagged as unexplained");
        RunTests.check(inventory.compare(before, before, null).isEmpty(), "identical readings show no changes");

        boolean badItem = false;
        try { inventory.compare(counts("Royal Jelly", 1), counts(), null); }
        catch (IllegalArgumentException expected) { badItem = true; }
        RunTests.check(badItem, "item names must be valid identifiers");
        boolean negative = false;
        try { inventory.compare(counts("honey", -1), counts(), null); }
        catch (IllegalArgumentException expected) { negative = true; }
        RunTests.check(negative, "negative counts are rejected");
    }

    private static Map<String, Integer> counts(Object... pairs) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < pairs.length; i += 2) map.put((String) pairs[i], (Integer) pairs[i + 1]);
        return map;
    }
}
