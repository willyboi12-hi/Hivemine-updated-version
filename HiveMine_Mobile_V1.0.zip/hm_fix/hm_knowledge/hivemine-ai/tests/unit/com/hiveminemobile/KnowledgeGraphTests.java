package com.hiveminemobile;

import com.hiveminemobile.ai.shared.KnowledgeGraph;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 035 KnowledgeGraph. */
public final class KnowledgeGraphTests {
    private KnowledgeGraphTests() { }

    public static void run() {
        KnowledgeGraph graph = new KnowledgeGraph();
        graph.relate("sunflower-field", "yields", "pollen");
        graph.relate("pollen", "converts-to", "honey");
        graph.relate("sunflower-field", "contains", "token-x");
        RunTests.check(graph.neighbors("sunflower-field", "yields").equals(Collections.singletonList("pollen")),
            "phase 035: neighbours are filtered by relation type");
        RunTests.check(graph.path("sunflower-field", "honey").equals(Arrays.asList("sunflower-field", "pollen", "honey")),
            "phase 035: the shortest directed path is found");
        RunTests.check(graph.path("honey", "sunflower-field").isEmpty(),
            "phase 035: edges are directed, so no reverse path exists");
        RunTests.check(graph.path("sunflower-field", "nowhere").isEmpty() && graph.nodeCount() == 4,
            "phase 035: unknown nodes give no path, and the node count is correct");
        RunTests.check(graph.path("pollen", "pollen").equals(Collections.singletonList("pollen")),
            "phase 035: a path from a node to itself is that node");
    }
}
