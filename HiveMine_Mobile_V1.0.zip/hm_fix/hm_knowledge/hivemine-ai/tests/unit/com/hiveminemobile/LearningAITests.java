package com.hiveminemobile;

import com.hiveminemobile.ai.memory.DecisionRecord.Outcome;
import com.hiveminemobile.ai.memory.ManagerMemory;
import com.hiveminemobile.ai.modules.LearningAI;
import com.hiveminemobile.ai.modules.LearningAI.Insight;
import java.util.List;

/** JVM-only tests for Phase 019 LearningAI. */
public final class LearningAITests {
    private LearningAITests() { }

    public static void run() {
        LearningAI learning = new LearningAI();
        RunTests.check(learning.getCapabilities().contains("analyze.history"), "phase 019 exposes analyze.history");

        ManagerMemory memory = new ManagerMemory(100);
        record(memory, "observe", Outcome.SUCCESS, 4);
        record(memory, "observe", Outcome.FAILURE, 1);
        record(memory, "observe", Outcome.UNKNOWN, 1);
        record(memory, "navigate", Outcome.FAILURE, 3);
        record(memory, "navigate", Outcome.SUCCESS, 3);
        record(memory, "analyze", Outcome.FAILURE, 4);
        record(memory, "recover", Outcome.FAILURE, 5);

        List<Insight> insights = learning.learn(memory.recent(100));
        RunTests.check(insights.size() == 3, "capabilities with fewer than five results get no insight");
        Insight observe = find(insights, "observe");
        RunTests.check(observe != null && observe.getEvidence() == 5 && observe.getSuccessRate() == 0.8,
            "unknown results do not count as evidence; the rate is successes over decided results");
        RunTests.check(observe.getAdvice().startsWith("reliable"), "a high success rate is advised as reliable");
        RunTests.check("declining".equals(observe.getTrend()),
            "a drop between the first and second halves of the history is reported as declining");

        Insight navigate = find(insights, "navigate");
        RunTests.check(navigate != null && "improving".equals(navigate.getTrend())
                && navigate.getAdvice().startsWith("mixed"),
            "a rise across the history is reported as improving, with mixed advice");

        Insight recover = find(insights, "recover");
        RunTests.check(recover != null && recover.getAdvice().startsWith("unreliable")
                && "steady".equals(recover.getTrend()),
            "a consistently failing capability is advised as unreliable");

        boolean badMinimum = false;
        try { new LearningAI(0); } catch (IllegalArgumentException expected) { badMinimum = true; }
        RunTests.check(badMinimum, "a non-positive evidence minimum is rejected");
    }

    private static void record(ManagerMemory memory, String capability, Outcome outcome, int times) {
        for (int i = 0; i < times; i++) {
            memory.record("task", capability, "vision", "decision", outcome, "", 1_000L + i);
        }
    }

    private static Insight find(List<Insight> insights, String capability) {
        for (Insight insight : insights) {
            if (insight.getCapability().equals(capability)) return insight;
        }
        return null;
    }
}
