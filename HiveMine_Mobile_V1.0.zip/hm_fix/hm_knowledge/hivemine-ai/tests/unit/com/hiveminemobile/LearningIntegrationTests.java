package com.hiveminemobile;

import com.hiveminemobile.ai.learning.LearningIntegrationBridge;
import com.hiveminemobile.ai.learning.LearningIntelligenceManager;
import com.hiveminemobile.ai.learning.Recommendation;
import com.hiveminemobile.ai.memory.DecisionRecord;
import com.hiveminemobile.ai.memory.ManagerMemory;
import com.hiveminemobile.ai.modules.LearningAI;
import java.util.ArrayList;
import java.util.List;

/** Phase 080 checks: Learning AI integration. */
public final class LearningIntegrationTests {
    private LearningIntegrationTests() {}

    static ManagerMemory history(String capability, int successes, int failures, String decision) {
        ManagerMemory m = new ManagerMemory(100);
        for (int i = 0; i < successes; i++) m.record("t" + i, capability, "farming", decision, DecisionRecord.Outcome.SUCCESS, "", i);
        for (int i = 0; i < failures; i++) m.record("f" + i, capability, "farming", decision, DecisionRecord.Outcome.FAILURE, "", 1000 + i);
        return m;
    }

    public static void run() {
        ManagerMemory m = history("farm.pollen", 8, 0, "farm-field-a");
        LearningIntelligenceManager mgr = new LearningIntelligenceManager(new LearningAI());
        List<Recommendation> recs = mgr.refresh(m.recent(100));
        RunTests.check(!recs.isEmpty(), "phase 080: learning produces at least one recommendation from history");
        RunTests.check(recs.get(0).getStatus() == Recommendation.Status.PROPOSED, "phase 080: recommendations start as PROPOSED, never applied");
        RunTests.check(recs.get(0).getEvidence() >= 5 && recs.get(0).getSuccessRate() >= 0.0 && recs.get(0).getSuccessRate() <= 1.0,
            "phase 080: recommendation carries valid evidence and success rate");

        ManagerMemory junk = new ManagerMemory(100);
        junk.record("x", "", "farming", "something", DecisionRecord.Outcome.SUCCESS, "", 1);
        boolean blankRefused = false;
        try { junk.record("y", "farm.pollen", "farming", "  ", DecisionRecord.Outcome.SUCCESS, "", 2); }
        catch (IllegalArgumentException expected) { blankRefused = true; }
        RunTests.check(blankRefused, "phase 080: blank decision is refused at record time");
        LearningIntelligenceManager mgr2 = new LearningIntelligenceManager(new LearningAI());
        RunTests.check(mgr2.refresh(junk.recent(100)).isEmpty() && mgr2.lastRejectedRecords() == 1,
            "phase 080: records with blank capability are rejected and counted");
        RunTests.check(mgr2.refresh(null).isEmpty(), "phase 080: null history is handled");

        List<Recommendation> again = mgr.refresh(m.recent(100));
        RunTests.check(again.size() == recs.size(), "phase 080: refreshing twice does not duplicate recommendations");

        String id = recs.get(0).getId();
        RunTests.check(mgr.reject(id) && mgr.recommendations().get(0).getStatus() == Recommendation.Status.REJECTED,
            "phase 080: user can reject a recommendation");
        List<Recommendation> afterRefresh = mgr.refresh(m.recent(100));
        RunTests.check(afterRefresh.get(0).getStatus() == Recommendation.Status.REJECTED,
            "phase 080: a rejection survives a refresh");
        RunTests.check(!mgr.reportOutcome(id, true), "phase 080: outcome cannot be reported for a rejected recommendation");

        LearningIntelligenceManager mgr3 = new LearningIntelligenceManager(new LearningAI());
        String id3 = mgr3.refresh(history("farm.pollen", 8, 0, "farm-field-a").recent(100)).get(0).getId();
        RunTests.check(mgr3.reportOutcome(id3, true) && mgr3.reportOutcome(id3, false),
            "phase 080: outcomes are recorded for a proposed recommendation");
        RunTests.check(Math.abs(mgr3.improvementRate(id3).getAsDouble() - 0.5) < 1e-9,
            "phase 080: improvement rate is computed from recorded outcomes");

        RunTests.check(new LearningIntegrationBridge().connectedSystems().containsAll(
            java.util.Arrays.asList("farming", "quest", "configuration", "analytics")),
            "phase 080: Learning AI is connected to farming, quest, configuration, and analytics");
        RunTests.check(mgr3.routeFor(mgr3.recommendations().get(0)).contains("analytics"),
            "phase 080: recommendations are always routed to analytics");
        RunTests.check(!mgr3.reject("no-such-id") && !mgr3.reportOutcome(null, true),
            "phase 080: unknown or null ids are refused");
    }
}
