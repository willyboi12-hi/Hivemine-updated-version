package com.hiveminemobile;

import com.hiveminemobile.ai.bss.BssMacroSettings;
import com.hiveminemobile.ai.loot.BlenderCatalog;
import com.hiveminemobile.ai.loot.CraftMaterial;
import com.hiveminemobile.ai.loot.LootManager;
import com.hiveminemobile.ai.ui.nav.UiController;

public final class LootManagerTests {
    private LootManagerTests() {}

    public static void run() {
        RunTests.check(BlenderCatalog.all().size() >= 18, "blender recipes loaded");
        RunTests.check(BlenderCatalog.get("Glue") != null, "glue recipe");
        RunTests.check(BlenderCatalog.get("Enzymes") != null, "enzymes recipe");
        RunTests.check(BlenderCatalog.scaleIngredients(BlenderCatalog.get("Glue"), 2).get("Gumdrops") == 100,
                "glue scales gumdrops");

        LootManager loot = new LootManager();
        loot.selectRecipe("Glue", 3);
        RunTests.check(loot.activeRecipe() != null && "Glue".equals(loot.activeRecipe().displayName), "active glue");
        RunTests.check(loot.craftQty() == 3, "qty 3");
        BssMacroSettings settings = new BssMacroSettings();
        loot.applyTo(settings);
        RunTests.check(settings.get("field") != null, "field applied");

        loot.setGoal("enzymes", 5);
        RunTests.check(loot.activeRecipe() != null, "enzymes via setGoal");

        UiController ui = new UiController();
        String report = ui.runAction("Recipe: Glue x2");
        RunTests.check(report.contains("Glue") || report.contains("Gumdrop") || report.contains("field"),
                "ui recipe glue");
        RunTests.check(ui.state().currentTask.toLowerCase().contains("glue")
                        || ui.state().settings.get("field") != null,
                "task or field set");
    }
}
