package com.hiveminemobile;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIErrorHandler;
import com.hiveminemobile.ai.AIException;
import com.hiveminemobile.ai.AIInterface;
import com.hiveminemobile.ai.manager.ManagerController;
import com.hiveminemobile.ai.manager.ManagerHealth;
import com.hiveminemobile.ai.manager.ManagerRuntime;
import com.hiveminemobile.ai.specialist.SpecialistStatus;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** JVM-only tests for Phase 002 HiveMineManagerAI lifecycle supervision. */
public final class ManagerArchitectureTests {
    private ManagerArchitectureTests() { }

    public static void run() {
        final List<String> events = new ArrayList<>();
        ManagerController manager = new ManagerController(AIConfiguration.empty());
        manager.registerSpecialist(new TestSpecialist("vision", events));
        manager.registerSpecialist(new TestSpecialist("state", events),
            new LinkedHashSet<>(Collections.singletonList("vision")));
        RunTests.check(manager.getRuntime().getState() == ManagerRuntime.State.NEW,
            "manager begins in NEW state");
        RunTests.check(!manager.isAvailable() && !manager.canCoordinate(),
            "manager is unavailable before startup");
        try {
            manager.start();
        } catch (AIException failure) {
            RunTests.check(false, "manager starts with valid specialists");
        }
        RunTests.check(manager.getRuntime().getState() == ManagerRuntime.State.RUNNING
                && manager.isAvailable() && manager.canCoordinate(),
            "manager enters RUNNING and becomes available after startup");
        RunTests.check(events.size() == 2 && "init:vision".equals(events.get(0))
                && "init:state".equals(events.get(1)),
            "manager initializes dependencies before dependent specialists");
        RunTests.check(manager.getSpecialistRegistry().getStatus("vision") == SpecialistStatus.AVAILABLE
                && manager.getSpecialistRegistry().findByCapability("observe").contains("vision"),
            "manager exposes registered specialists through capability-aware catalog");
        ManagerHealth health = manager.checkHealth();
        RunTests.check(health.getStatus() == ManagerHealth.Status.HEALTHY
                && health.getRegisteredModules() == 2 && health.getInitializedModules() == 2,
            "manager health reports all specialists initialized");
        boolean lateRegistrationRejected = false;
        try {
            manager.registerSpecialist(new TestSpecialist("late", events));
        } catch (IllegalStateException expected) { lateRegistrationRejected = true; }
        RunTests.check(lateRegistrationRejected,
            "manager rejects specialist registration while running");
        manager.shutdown();
        RunTests.check(manager.getRuntime().getState() == ManagerRuntime.State.STOPPED
                && !manager.isAvailable(), "manager shutdown makes it unavailable");
        RunTests.check(manager.getSpecialistRegistry().getStatus("vision") == SpecialistStatus.UNAVAILABLE,
            "manager marks registered specialists unavailable after shutdown");
        RunTests.check("stop:state".equals(events.get(2)) && "stop:vision".equals(events.get(3)),
            "manager shuts specialists down in reverse dependency order");
        try {
            manager.start();
        } catch (AIException failure) {
            RunTests.check(false, "manager supports clean restart after shutdown");
        }
        RunTests.check(manager.canCoordinate(), "restarted manager coordinates after initialization");
        manager.shutdown();

        ManagerController missingDependency = new ManagerController(AIConfiguration.empty());
        missingDependency.registerSpecialist(new TestSpecialist("quest", new ArrayList<String>()),
            new LinkedHashSet<>(Collections.singletonList("vision")));
        boolean missingRejected = false;
        try { missingDependency.start(); }
        catch (AIException expected) { missingRejected = true; }
        RunTests.check(missingRejected
                && missingDependency.getRuntime().getState() == ManagerRuntime.State.FAILED,
            "manager rejects missing specialist dependencies");
        RunTests.check(!missingDependency.isAvailable()
                && missingDependency.checkHealth().getStatus() == ManagerHealth.Status.UNAVAILABLE,
            "manager remains unavailable after dependency validation failure");

        ManagerController cyclic = new ManagerController(AIConfiguration.empty());
        cyclic.registerSpecialist(new TestSpecialist("vision", new ArrayList<String>()),
            new LinkedHashSet<>(Collections.singletonList("state")));
        cyclic.registerSpecialist(new TestSpecialist("state", new ArrayList<String>()),
            new LinkedHashSet<>(Collections.singletonList("vision")));
        boolean cycleRejected = false;
        try { cyclic.start(); }
        catch (AIException expected) { cycleRejected = true; }
        RunTests.check(cycleRejected, "manager rejects circular specialist dependencies");

        ManagerController duplicate = new ManagerController(AIConfiguration.empty());
        duplicate.registerSpecialist(new TestSpecialist("vision", new ArrayList<String>()));
        boolean duplicateRejected = false;
        try { duplicate.registerSpecialist(new TestSpecialist("vision", new ArrayList<String>())); }
        catch (IllegalArgumentException expected) { duplicateRejected = true; }
        RunTests.check(duplicateRejected, "manager rejects duplicate specialist IDs");

        AIErrorHandler errors = new AIErrorHandler(10, null);
        ManagerController failedModule = new ManagerController(AIConfiguration.empty(), errors);
        failedModule.registerSpecialist(new TestSpecialist("broken", new ArrayList<String>(), true));
        boolean startupFailure = false;
        try { failedModule.start(); }
        catch (AIException expected) { startupFailure = true; }
        RunTests.check(startupFailure && failedModule.checkHealth().getStatus()
                == ManagerHealth.Status.UNAVAILABLE,
            "manager reports failed specialist startup as unavailable");
    }

    private static final class TestSpecialist implements AIInterface {
        private final String id;
        private final List<String> events;
        private final boolean fail;
        TestSpecialist(String id, List<String> events) { this(id, events, false); }
        TestSpecialist(String id, List<String> events, boolean fail) {
            this.id = id; this.events = events; this.fail = fail;
        }
        @Override public String getId() { return id; }
        @Override public String getVersion() { return "1.0.0"; }
        @Override public Set<String> getCapabilities() {
            return Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList("observe", "analyze")));
        }
        @Override public void onInitialize(AIConfiguration configuration) throws Exception {
            events.add("init:" + id);
            if (fail) throw new IllegalStateException("intentional startup failure for test");
        }
        @Override public void onShutdown() { events.add("stop:" + id); }
    }
}
