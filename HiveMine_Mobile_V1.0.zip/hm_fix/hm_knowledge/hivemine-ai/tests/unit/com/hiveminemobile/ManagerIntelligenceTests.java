package com.hiveminemobile;

import com.hiveminemobile.ai.automation.ActionPlanner;
import com.hiveminemobile.ai.automation.AutomationOrchestrator;
import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.manager.intel.*;

import java.util.Arrays;
import java.util.Collections;

/** Phases 071–080 advanced manager intelligence. */
public final class ManagerIntelligenceTests {
    private ManagerIntelligenceTests() {}

    private static final class FakePort implements MacroPort {
        boolean connected = true;
        boolean running;
        @Override public void start() { running = true; }
        @Override public void stop() { running = false; }
        @Override public void recover() { running = false; }
        @Override public MacroStatus readStatus() {
            return connected ? MacroStatus.connected(running, "ok") : MacroStatus.disconnected("x");
        }
    }

    public static void run() {
        // 071 hierarchy
        GoalHierarchy h = new GoalHierarchy();
        RunTests.check(h.active() == ManagerGoal.STANDBY, "071 default standby");
        h.push(ManagerGoal.FARM_POLLEN);
        RunTests.check(h.active() == ManagerGoal.FARM_POLLEN, "071 push farm");
        h.push(ManagerGoal.SHUTDOWN);
        RunTests.check(h.active() == ManagerGoal.SHUTDOWN, "071 shutdown on top");
        h.completeActive();
        RunTests.check(h.active() == ManagerGoal.FARM_POLLEN, "071 complete pops");

        // 072 arbiter
        SpecialistArbiter arb = new SpecialistArbiter();
        SpecialistVote v1 = new SpecialistVote("Farming", ManagerGoal.FARM_POLLEN, 0.6, "farm");
        SpecialistVote v2 = new SpecialistVote("Quest", ManagerGoal.TURN_IN_QUEST, 0.6, "quest");
        SpecialistVote best = arb.arbitrate(Arrays.asList(v1, v2));
        RunTests.check(best.specialistId.equals("Quest"), "072 quest wins tie over farming");
        SpecialistVote v3 = new SpecialistVote("Farming", ManagerGoal.FARM_POLLEN, 0.9, "strong");
        best = arb.arbitrate(Arrays.asList(v2, v3));
        RunTests.check(best.goal == ManagerGoal.FARM_POLLEN, "072 higher confidence wins");

        // 073 fusion
        DecisionFusion fuse = new DecisionFusion();
        DecisionFusion.Result fr = fuse.fuse(Arrays.asList(
                new SpecialistVote("A", ManagerGoal.FARM_POLLEN, 0.4, ""),
                new SpecialistVote("B", ManagerGoal.FARM_POLLEN, 0.3, ""),
                new SpecialistVote("C", ManagerGoal.CONVERT_HONEY, 0.5, "")
        ));
        RunTests.check(fr.goal == ManagerGoal.FARM_POLLEN && fr.score >= 0.7 - 1e-6,
                "073 fusion sums farm votes");

        // 074 conflicts
        ConflictResolver cr = new ConflictResolver();
        RunTests.check(cr.resolve(ManagerGoal.FARM_POLLEN, ManagerGoal.SHUTDOWN) == ManagerGoal.SHUTDOWN,
                "074 shutdown wins");
        RunTests.check(cr.resolve(ManagerGoal.FARM_POLLEN, ManagerGoal.TURN_IN_QUEST) == ManagerGoal.TURN_IN_QUEST,
                "074 quest over farm");
        RunTests.check(cr.resolve(ManagerGoal.FARM_POLLEN, ManagerGoal.CONVERT_HONEY) == ManagerGoal.CONVERT_HONEY,
                "074 convert over farm");

        // 075 plan graph
        PlanGraph pg = new PlanGraph();
        pg.setPlan(Arrays.asList(
                new PlanNode("1", ManagerGoal.FARM_POLLEN, "farm"),
                new PlanNode("2", ManagerGoal.CONVERT_HONEY, "convert")
        ));
        RunTests.check(pg.current().goal == ManagerGoal.FARM_POLLEN, "075 first node");
        pg.advance();
        RunTests.check(pg.current().goal == ManagerGoal.CONVERT_HONEY, "075 second node");
        pg.advance();
        RunTests.check(pg.isComplete(), "075 complete");

        // 076 policy
        ManagerPolicyEngine pol = new ManagerPolicyEngine();
        ManagerPolicyEngine.WorldFlags f = new ManagerPolicyEngine.WorldFlags();
        f.userWantsFarm = true;
        RunTests.check(pol.evaluate(f) == ManagerGoal.FARM_POLLEN, "076 farm flag");
        f.bagFull = true;
        RunTests.check(pol.evaluate(f) == ManagerGoal.CONVERT_HONEY, "076 bag full");
        f.questComplete = true;
        RunTests.check(pol.evaluate(f) == ManagerGoal.TURN_IN_QUEST, "076 quest complete");
        f.disconnected = true;
        RunTests.check(pol.evaluate(f) == ManagerGoal.RECOVER_SESSION, "076 disconnect");
        f.faulted = true;
        RunTests.check(pol.evaluate(f) == ManagerGoal.SHUTDOWN, "076 fault");

        // 077 escalation
        EscalationManager esc = new EscalationManager(1, 2, 3);
        RunTests.check(esc.level() == EscalationManager.Level.NONE, "077 none");
        esc.recordSoftFailure();
        RunTests.check(esc.level() == EscalationManager.Level.WARN, "077 warn");
        esc.recordSoftFailure();
        RunTests.check(esc.goalOverride() == ManagerGoal.RECOVER_SESSION, "077 recover override");
        esc.recordSoftFailure();
        RunTests.check(esc.goalOverride() == ManagerGoal.SHUTDOWN, "077 shutdown override");

        // 078/079 loop + report + automation bind
        ManagerIntelligenceLoop loop = new ManagerIntelligenceLoop(new EscalationManager(2, 4, 7));
        ManagerPolicyEngine.WorldFlags world = new ManagerPolicyEngine.WorldFlags();
        world.userWantsFarm = true;
        ManagerGoal g = loop.step(world, Collections.singletonList(
                new SpecialistVote("Farming", ManagerGoal.FARM_POLLEN, 0.8, "go")
        ));
        RunTests.check(g == ManagerGoal.FARM_POLLEN, "078 step chooses farm");
        RunTests.check(loop.report().lastChosen() == ManagerGoal.FARM_POLLEN, "079 report chosen");
        RunTests.check(loop.report().toMarkdown().contains("chosen:"), "079 markdown");

        FakePort port = new FakePort();
        AutomationController ac = new AutomationController(port);
        ac.setAiControlEnabled(true);
        AutomationOrchestrator orch = new AutomationOrchestrator(ac, port, 100, 60_000L, 3, 5);
        orch.arm("m1", 0);
        loop.bindAutomation(orch);
        world = new ManagerPolicyEngine.WorldFlags();
        world.userWantsFarm = true;
        loop.step(world, Collections.<SpecialistVote>emptyList());
        RunTests.check(orch.goal() == ActionPlanner.Goal.FARM, "078 maps farm to automation FARM");
        world.faulted = true;
        loop.step(world, Collections.<SpecialistVote>emptyList());
        RunTests.check(orch.goal() == ActionPlanner.Goal.IDLE, "078 fault maps to IDLE");
    }
}
