package com.hiveminemobile;

import com.hiveminemobile.ai.memory.DecisionRecord;
import com.hiveminemobile.ai.memory.DecisionRecord.Outcome;
import com.hiveminemobile.ai.memory.ManagerMemory;
import java.util.List;
import java.util.OptionalDouble;

/** JVM-only tests for Phase 008 manager memory. */
public final class MemoryTests {
    private MemoryTests() { }

    public static void run() {
        ManagerMemory memory = new ManagerMemory(3);
        DecisionRecord first = memory.record("task-1", "observe", "vision", "task completed",
            Outcome.SUCCESS, "72%", 1_000L);
        RunTests.check(first.getSequence() == 1L && first.getOutcome() == Outcome.SUCCESS,
            "phase 008 records a decision with a sequence and outcome");
        memory.record("task-2", "observe", "vision", "attempt failed", Outcome.FAILURE, "blurred frame", 2_000L);
        memory.record("task-3", "analyze", "state", "task completed", Outcome.SUCCESS, "", 3_000L);
        RunTests.check(memory.size() == 3, "memory holds records up to its capacity");

        List<DecisionRecord> recent = memory.recent(2);
        RunTests.check(recent.size() == 2 && "task-3".equals(recent.get(0).getTaskId())
                && "task-2".equals(recent.get(1).getTaskId()),
            "recent returns the newest records first");

        memory.record("task-4", "observe", "vision2", "task completed", Outcome.SUCCESS, "", 4_000L);
        RunTests.check(memory.size() == 3 && memory.forTask("task-1").isEmpty(),
            "the oldest record is evicted when capacity is reached");
        RunTests.check(memory.recent(10).get(0).getSequence() == 4L, "sequence numbers keep increasing through eviction");
        RunTests.check(memory.forTask("task-2").size() == 1, "history can be retrieved by task id");

        OptionalDouble rate = memory.successRate("observe");
        RunTests.check(rate.isPresent() && Math.abs(rate.getAsDouble() - 0.5) < 1e-9,
            "success rate is computed per capability (one failure, one success)");

        memory.record("task-5", "observe", "vision", "task cancelled", Outcome.UNKNOWN, "", 5_000L);
        rate = memory.successRate("observe");
        RunTests.check(rate.isPresent() && Math.abs(rate.getAsDouble() - 1.0) < 1e-9,
            "eviction and UNKNOWN results change the rate as expected");
        RunTests.check(!memory.successRate("navigate").isPresent(), "a capability with no outcomes has no rate");

        DecisionRecord long600 = memory.record("task-6", "observe", "vision", "note", Outcome.SUCCESS,
            repeat('x', 600), 6_000L);
        RunTests.check(long600.getDetail().length() == DecisionRecord.MAX_DETAIL_LENGTH,
            "detail text is capped at the maximum length");

        boolean blankRejected = false;
        try { memory.record("task-7", "observe", "vision", "  ", Outcome.SUCCESS, "", 7_000L); }
        catch (IllegalArgumentException expected) { blankRejected = true; }
        RunTests.check(blankRejected, "a blank decision is rejected");
        boolean nullOutcomeRejected = false;
        try { memory.record("task-7", "observe", "vision", "decision", null, "", 7_000L); }
        catch (IllegalArgumentException expected) { nullOutcomeRejected = true; }
        RunTests.check(nullOutcomeRejected, "a missing outcome is rejected");
        boolean limitRejected = false;
        try { memory.recent(0); } catch (IllegalArgumentException expected) { limitRejected = true; }
        RunTests.check(limitRejected, "recent rejects a non-positive limit");
    }

    private static String repeat(char c, int count) {
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < count; i++) text.append(c);
        return text.toString();
    }
}
