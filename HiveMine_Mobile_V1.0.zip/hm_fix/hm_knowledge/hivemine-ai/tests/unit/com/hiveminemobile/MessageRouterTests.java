package com.hiveminemobile;

import com.hiveminemobile.ai.shared.MessageRouter;
import com.hiveminemobile.ai.shared.MessageRouter.Result;
import java.util.ArrayList;
import java.util.List;

/** JVM-only tests for Phase 033 MessageRouter. */
public final class MessageRouterTests {
    private MessageRouterTests() { }

    public static void run() {
        MessageRouter router = new MessageRouter();
        List<String> calls = new ArrayList<>();
        router.register("task.", (type, body) -> calls.add("task:" + body));
        router.register("task.assign.", (type, body) -> calls.add("assign:" + body));
        router.register("bad.", (type, body) -> { throw new IllegalStateException("handler failed"); });

        RunTests.check(router.route("task.assign.farm", "x") == Result.ROUTED && calls.get(0).equals("assign:x"),
            "phase 033: the longest matching prefix wins");
        RunTests.check(router.route("task.report", "y") == Result.ROUTED && calls.get(1).equals("task:y"),
            "phase 033: a shorter prefix handles what the longer one does not claim");
        RunTests.check(router.route("unknown.thing", "z") == Result.UNROUTABLE,
            "phase 033: a message no route claims is unroutable");
        RunTests.check(router.route("bad.one", "q") == Result.HANDLER_FAILED && router.getFailed() == 1,
            "phase 033: a failing handler is reported and counted");
        RunTests.check(router.getRouted() == 2 && router.getUnroutable() == 1,
            "phase 033: routed and unroutable messages are counted");

        boolean duplicate = false;
        try { router.register("task.", (type, body) -> { }); } catch (IllegalArgumentException expected) { duplicate = true; }
        RunTests.check(duplicate, "phase 033: a prefix can be registered only once");
    }
}
