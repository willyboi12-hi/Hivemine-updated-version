package com.hiveminemobile;

import com.hiveminemobile.ai.comm.AIMessage;
import com.hiveminemobile.ai.comm.MessageBus;
import com.hiveminemobile.ai.comm.MessageBus.Receipt;
import com.hiveminemobile.ai.comm.MessageBus.Status;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** JVM-only tests for Phase 005 manager communication. */
public final class MessagingTests {
    private MessagingTests() { }

    public static void run() {
        MessageBus bus = new MessageBus(2);
        bus.register("manager");
        bus.register("vision");
        bus.register("state");
        RunTests.check(bus.getAddresses().size() == 3, "phase 005 registers addresses");

        boolean duplicateRejected = false;
        try { bus.register("vision"); } catch (IllegalArgumentException expected) { duplicateRejected = true; }
        RunTests.check(duplicateRejected, "duplicate address is rejected");

        Map<String, String> payload = new LinkedHashMap<>();
        payload.put("field", "Pine Tree");
        Receipt first = bus.send("vision", "state", "observation.field", payload, 1_000L);
        RunTests.check(first.isAccepted() && first.getMessage().getSequence() == 1L,
            "accepts a message between registered modules with sequence 1");
        payload.put("field", "Sunflower Field");
        RunTests.check("Pine Tree".equals(first.getMessage().getPayload().get("field")),
            "message keeps its own copy of the payload");
        boolean readOnly = false;
        try { first.getMessage().getPayload().put("x", "y"); } catch (UnsupportedOperationException expected) { readOnly = true; }
        RunTests.check(readOnly, "delivered payload is read-only");

        RunTests.check(bus.send("ghost", "state", "observation.field", null, 1_000L).getStatus()
            == Status.REJECTED_UNKNOWN_SENDER, "unknown sender is rejected");
        RunTests.check(bus.send("vision", "nowhere", "observation.field", null, 1_000L).getStatus()
            == Status.REJECTED_UNKNOWN_RECIPIENT, "unknown recipient is rejected");
        RunTests.check(bus.send("vision", "vision", "observation.field", null, 1_000L).getStatus()
            == Status.REJECTED_INVALID, "self-addressed message is rejected");
        RunTests.check(bus.send("vision", "state", "Bad Type", null, 1_000L).getStatus()
            == Status.REJECTED_INVALID, "message type must be a valid identifier");
        RunTests.check(bus.send("Vision", "state", "observation.field", null, 1_000L).getStatus()
            == Status.REJECTED_INVALID, "sender identifiers are validated");

        Map<String, String> tooMany = new LinkedHashMap<>();
        for (int i = 0; i < AIMessage.MAX_PAYLOAD_ENTRIES + 1; i++) tooMany.put("k" + i, "v");
        RunTests.check(bus.send("vision", "state", "observation.field", tooMany, 1_000L).getStatus()
            == Status.REJECTED_INVALID, "payload with too many entries is rejected");
        Map<String, String> longText = Collections.singletonMap("text", repeat('x', AIMessage.MAX_PAYLOAD_TEXT + 1));
        RunTests.check(bus.send("vision", "state", "observation.field", longText, 1_000L).getStatus()
            == Status.REJECTED_INVALID, "oversized payload value is rejected");

        Receipt second = bus.send("vision", "state", "observation.pollen", null, 1_001L);
        RunTests.check(second.isAccepted() && second.getMessage().getSequence() == 2L,
            "second message fills the mailbox");
        Receipt third = bus.send("vision", "state", "observation.quest", null, 1_002L);
        RunTests.check(third.getStatus() == Status.REJECTED_MAILBOX_FULL,
            "full mailbox refuses instead of dropping older mail");
        RunTests.check(bus.pending("state") == 2, "full mailbox keeps both pending messages");

        List<AIMessage> firstBatch = bus.drain("state", 1);
        RunTests.check(firstBatch.size() == 1 && firstBatch.get(0).getSequence() == 1L,
            "drain returns the oldest message first and honors the limit");
        Receipt fourth = bus.send("vision", "state", "observation.quest", null, 1_003L);
        RunTests.check(fourth.isAccepted() && fourth.getMessage().getSequence() == 3L,
            "freed space accepts new mail with the next sequence number");
        RunTests.check(bus.drain("state", 10).size() == 2, "remaining messages drain in order");
        RunTests.check(bus.drain("state", 5).isEmpty(), "an empty mailbox drains to nothing");
        RunTests.check(bus.drain("nobody", 5).isEmpty(), "an unknown address drains to nothing");

        RunTests.check(bus.send("manager", "state", "task.assign", null, 1_004L).isAccepted(),
            "manager can message a specialist");
        RunTests.check(bus.unregister("state") && bus.pending("state") == 0,
            "unregister removes the address and clears its mailbox");
        RunTests.check(bus.send("vision", "state", "observation.field", null, 1_005L).getStatus()
            == Status.REJECTED_UNKNOWN_RECIPIENT, "messages to an unregistered address are refused");
        RunTests.check(bus.getAcceptedCount() == 4 && bus.getRejectedCount() == 9,
            "bus counts accepted and rejected messages");
    }

    private static String repeat(char c, int count) {
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < count; i++) text.append(c);
        return text.toString();
    }
}
