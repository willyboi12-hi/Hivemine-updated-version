package com.hiveminemobile;

import com.hiveminemobile.ai.shared.ModelRouter;
import com.hiveminemobile.ai.shared.ModelRouter.Model;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;

/** JVM-only tests for Phase 037 ModelRouter. */
public final class ModelRouterTests {
    private ModelRouterTests() { }

    public static void run() {
        ModelRouter router = new ModelRouter();
        router.register(new Model("fast-ocr", new HashSet<>(Arrays.asList("ocr")), 0.80, 1.0));
        router.register(new Model("careful-ocr", new HashSet<>(Arrays.asList("ocr")), 0.97, 5.0));
        router.register(new Model("cheap-ocr", new HashSet<>(Arrays.asList("ocr")), 0.92, 2.0));

        Optional<Model> lenient = router.select("ocr", 0.75);
        RunTests.check(lenient.isPresent() && "fast-ocr".equals(lenient.get().getName()),
            "phase 037: with a low accuracy bar, the cheapest model is chosen");
        Optional<Model> strict = router.select("ocr", 0.9);
        RunTests.check(strict.isPresent() && "cheap-ocr".equals(strict.get().getName()),
            "phase 037: the cheapest model that meets the accuracy bar is chosen");
        RunTests.check(!router.select("ocr", 0.99).isPresent(),
            "phase 037: no model is chosen when none meets the accuracy bar");
        RunTests.check(!router.select("audio", 0.5).isPresent(),
            "phase 037: no model is chosen for an unknown capability");

        boolean duplicate = false;
        try { router.register(new Model("cheap-ocr", Collections.singleton("ocr"), 0.5, 0.0)); }
        catch (IllegalArgumentException expected) { duplicate = true; }
        RunTests.check(duplicate, "phase 037: a model name can be registered only once");
        boolean badAccuracy = false;
        try { new Model("x", Collections.singleton("ocr"), 1.5, 0.0); } catch (IllegalArgumentException expected) { badAccuracy = true; }
        RunTests.check(badAccuracy, "phase 037: accuracy must be between 0 and 1");
    }
}
