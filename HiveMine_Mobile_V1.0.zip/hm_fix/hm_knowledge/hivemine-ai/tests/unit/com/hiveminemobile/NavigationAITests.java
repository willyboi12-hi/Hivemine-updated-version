package com.hiveminemobile;

import com.hiveminemobile.ai.modules.NavigationAI;
import com.hiveminemobile.ai.modules.NavigationAI.Assessment;
import com.hiveminemobile.ai.modules.NavigationAI.Status;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 014 NavigationAI. */
public final class NavigationAITests {
    private NavigationAITests() { }

    public static void run() {
        NavigationAI nav = new NavigationAI();
        RunTests.check(nav.getCapabilities().contains("analyze.location"), "phase 014 exposes analyze.location");
        java.util.List<String> route = Arrays.asList("Clover", "Sunflower", "Dandelion");

        Assessment onRoute = nav.assess(route, Arrays.asList("Clover", null, "Clover", "Sunflower"));
        RunTests.check(onRoute.getStatus() == Status.ON_ROUTE && "Sunflower".equals(onRoute.getLastSeen())
                && "Dandelion".equals(onRoute.getExpectedNext()),
            "a route advances when the next planned field is seen, skipping unrecognised frames");
        RunTests.check(nav.assess(route, Arrays.asList("Clover", "Sunflower", "Dandelion")).getStatus() == Status.COMPLETE,
            "reaching the last planned field completes the route");
        Assessment off = nav.assess(route, Arrays.asList("Clover", "Pine Tree"));
        RunTests.check(off.getStatus() == Status.OFF_ROUTE && "Sunflower".equals(off.getExpectedNext()),
            "one unexpected field is off route and still expects the next planned field");
        RunTests.check(nav.assess(route, Arrays.asList("Clover", "Pine Tree", "Pine Tree", "Pine Tree")).getStatus()
                == Status.LOST, "three unexpected fields in a row mean the character is lost");
        RunTests.check(nav.assess(route, Arrays.asList("Clover", "Pine Tree", "Sunflower")).getStatus() == Status.ON_ROUTE,
            "a recovered match resets the mismatch streak");
        Assessment unknown = nav.assess(route, Arrays.asList(null, null));
        RunTests.check(unknown.getStatus() == Status.UNKNOWN && unknown.getLastSeen() == null,
            "no recognised field means the status is unknown");

        boolean emptyRoute = false;
        try { nav.assess(Collections.<String>emptyList(), Arrays.asList("Clover")); }
        catch (IllegalArgumentException expected) { emptyRoute = true; }
        RunTests.check(emptyRoute, "an empty route is rejected");
        boolean badLimit = false;
        try { new NavigationAI(0); } catch (IllegalArgumentException expected) { badLimit = true; }
        RunTests.check(badLimit, "a non-positive lost threshold is rejected");
    }
}
