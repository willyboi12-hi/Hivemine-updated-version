package com.hiveminemobile;

import com.hiveminemobile.ai.modules.NotificationAI;
import com.hiveminemobile.ai.modules.NotificationAI.Decision;
import com.hiveminemobile.ai.modules.NotificationAI.Level;

/** JVM-only tests for Phase 026 NotificationAI. */
public final class NotificationAITests {
    private NotificationAITests() { }

    public static void run() {
        long t0 = 1_800_000_000_000L;
        NotificationAI alerts = new NotificationAI();
        RunTests.check(alerts.getCapabilities().contains("report.notify"), "phase 026 exposes report.notify");

        RunTests.check(alerts.notify(Level.WARNING, "stuck", "Field not recognised", t0) == Decision.DELIVERED,
            "a new alert is delivered");
        RunTests.check(alerts.notify(Level.WARNING, "stuck", "Field not recognised", t0 + 10_000L) == Decision.DUPLICATE,
            "a repeat on the same topic inside the de-duplication window is suppressed");
        RunTests.check(alerts.notify(Level.WARNING, "stuck", "Field not recognised", t0 + 61_000L) == Decision.DELIVERED,
            "the same topic is delivered again once the window has passed");

        NotificationAI limited = new NotificationAI(1L, 2, 10_000L);
        RunTests.check(limited.notify(Level.INFO, "a", "first", t0) == Decision.DELIVERED
                && limited.notify(Level.INFO, "b", "second", t0) == Decision.DELIVERED,
            "two alerts fit inside the rate limit");
        RunTests.check(limited.notify(Level.INFO, "c", "third", t0) == Decision.RATE_LIMITED,
            "a third ordinary alert inside the window is rate-limited");
        RunTests.check(limited.notify(Level.CRITICAL, "d", "critical", t0) == Decision.DELIVERED,
            "a critical alert skips the rate limit");
        RunTests.check(limited.notify(Level.INFO, "c", "third", t0 + 11_000L) == Decision.DELIVERED,
            "a rate-limited alert can be delivered once the window clears");
        RunTests.check(limited.inbox().size() == 4 && limited.inbox().get(0).getSequence() == 1L,
            "delivered alerts are kept in order in the inbox");

        boolean badTopic = false;
        try { alerts.notify(Level.INFO, "Bad Topic", "text", t0); } catch (IllegalArgumentException expected) { badTopic = true; }
        RunTests.check(badTopic, "alert topics must be valid identifiers");
        boolean emptyText = false;
        try { alerts.notify(Level.INFO, "ok", "  ", t0); } catch (IllegalArgumentException expected) { emptyText = true; }
        RunTests.check(emptyText, "blank alert text is rejected");
    }
}
