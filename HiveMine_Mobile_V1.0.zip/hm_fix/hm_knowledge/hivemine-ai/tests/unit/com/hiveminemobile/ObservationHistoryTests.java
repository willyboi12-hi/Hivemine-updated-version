package com.hiveminemobile;

import com.hiveminemobile.ai.observation.Observation;
import com.hiveminemobile.ai.observation.ObservationHistory;

/** JVM-only tests for Phase 050 ObservationHistory. */
public final class ObservationHistoryTests {
    private ObservationHistoryTests() { }

    public static void run() {
        ObservationHistory history = new ObservationHistory(2);
        history.record(new Observation("pollen", "10", "vision", 1_000L, 0.9));
        history.record(new Observation("pollen", "20", "vision", 2_000L, 0.9));
        history.record(new Observation("pollen", "30", "vision", 3_000L, 0.9));
        RunTests.check(history.size("pollen") == 2 && "30".equals(history.latest("pollen").getValue()),
            "phase 050: the history is bounded per key and keeps the newest entries");
        RunTests.check(history.between("pollen", 2_000L, 3_000L).size() == 2,
            "phase 050: time-range queries include both ends");
        RunTests.check(history.between("pollen", 0L, 1_500L).isEmpty(),
            "phase 050: entries evicted from the bounded history are no longer returned");
        RunTests.check(history.latest("unknown") == null && history.size("unknown") == 0,
            "phase 050: an unknown key has no history");
        boolean bad = false;
        try { new ObservationHistory(0); } catch (IllegalArgumentException expected) { bad = true; }
        RunTests.check(bad, "phase 050: the per-key limit must be at least 1");
    }
}
