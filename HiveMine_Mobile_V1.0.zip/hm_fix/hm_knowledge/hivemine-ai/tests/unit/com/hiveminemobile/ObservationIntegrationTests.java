package com.hiveminemobile;

import com.hiveminemobile.ai.modules.VisionAI;
import com.hiveminemobile.ai.observation.FieldRecognizer;
import com.hiveminemobile.ai.observation.InterfaceRegistry;
import com.hiveminemobile.ai.observation.Observation;
import com.hiveminemobile.ai.observation.ObservationHistory;
import com.hiveminemobile.ai.observation.ObservationSource;
import com.hiveminemobile.ai.observation.ObservationVerifier;
import com.hiveminemobile.ai.observation.StateReconstructor;
import com.hiveminemobile.ai.observation.TextReader;
import com.hiveminemobile.ai.shared.ConfidenceEngine;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only pipeline test for phases 041–050: capture, identify, read, match, reconstruct, verify, record. */
public final class ObservationIntegrationTests {
    private ObservationIntegrationTests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        int[] pixels = new int[10 * 4];
        for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 3; dx++) pixels[(2 + dy) * 10 + 1 + dx] = 0xFF0000;
        VisionAI.Frame frame = new VisionAI.Frame(10, 4, pixels);

        ObservationSource source = new ObservationSource(() -> frame);
        RunTests.check(source.observe(now).getStatus() == ObservationSource.Status.NOT_AUTHORIZED,
            "observation pipeline: capture stays blocked until authorized");
        source.setAuthorized(true);
        ObservationSource.Capture capture = source.observe(now);

        InterfaceRegistry screens = new InterfaceRegistry();
        screens.define("hive", Collections.singletonList(new VisionAI.Signature("hive-marker",
            new VisionAI.Region(1, 2, 3, 2), 0xFF0000, 0, 0.9)), 1);
        RunTests.check("hive".equals(screens.identify(capture.getFrame()).getScreen()),
            "observation pipeline: the authorized frame is identified as the hive screen");

        TextReader reader = new TextReader((f, region) -> new TextReader.OcrText("Pine Tre", 0.9), 0.8);
        String text = reader.readText(capture.getFrame(), new VisionAI.Region(0, 0, 5, 1));
        FieldRecognizer.Match field = new FieldRecognizer(Arrays.asList("Pine Tree", "Dandelion")).match(text);
        RunTests.check(field != null && "Pine Tree".equals(field.getField()),
            "observation pipeline: OCR text is matched to a known field");

        ObservationHistory history = new ObservationHistory(10);
        Observation seen = new Observation("field.current", field.getField(), "vision", now, 0.6);
        history.record(seen);
        java.util.Map<String, StateReconstructor.Estimate> state = new StateReconstructor(new ConfidenceEngine(60_000L), 0.5)
            .reconstruct(Arrays.asList(seen, new Observation("field.current", "Pine Tree", "ocr", now, 0.6)), now);
        RunTests.check("Pine Tree".equals(state.get("field.current").getValue()),
            "observation pipeline: two agreeing readings reconstruct the state");
        RunTests.check(new ObservationVerifier(60.0).verify(history.between("field.current", 0L, now), now).isEmpty(),
            "observation pipeline: the recorded observations pass verification");
    }
}
