package com.hiveminemobile;

import com.hiveminemobile.ai.modules.VisionAI;
import com.hiveminemobile.ai.observation.ObservationSource;
import com.hiveminemobile.ai.observation.ObservationSource.Status;

/** JVM-only tests for Phase 041 ObservationSource. */
public final class ObservationSourceTests {
    private ObservationSourceTests() { }

    public static void run() {
        final int[] calls = {0};
        VisionAI.Frame frame = new VisionAI.Frame(2, 2, new int[4]);
        ObservationSource source = new ObservationSource(() -> { calls[0]++; return frame; });
        ObservationSource.Capture refused = source.observe(1L);
        RunTests.check(refused.getStatus() == Status.NOT_AUTHORIZED && refused.getFrame() == null && calls[0] == 0,
            "phase 041: nothing is captured until the user authorizes screen observation");
        source.setAuthorized(true);
        ObservationSource.Capture captured = source.observe(2L);
        RunTests.check(captured.getStatus() == Status.CAPTURED && captured.getFrame() == frame && calls[0] == 1,
            "phase 041: an authorized capture returns the frame from the app layer");

        ObservationSource failing = new ObservationSource(() -> { throw new IllegalStateException("no permission"); });
        failing.setAuthorized(true);
        ObservationSource.Capture failed = failing.observe(3L);
        RunTests.check(failed.getStatus() == Status.CAPTURE_FAILED && "no permission".equals(failed.getReason()),
            "phase 041: a failing provider is reported, not thrown");
        ObservationSource empty = new ObservationSource(() -> null);
        empty.setAuthorized(true);
        RunTests.check(empty.observe(4L).getStatus() == Status.CAPTURE_FAILED,
            "phase 041: a provider that returns no frame is a failed capture");
        source.setAuthorized(false);
        RunTests.check(source.observe(5L).getStatus() == Status.NOT_AUTHORIZED && calls[0] == 1,
            "phase 041: withdrawing authorization stops capture at once");
    }
}
