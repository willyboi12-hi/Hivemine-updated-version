package com.hiveminemobile;

import com.hiveminemobile.ai.observation.Observation;
import com.hiveminemobile.ai.observation.ObservationVerifier;
import com.hiveminemobile.ai.observation.ObservationVerifier.Issue;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** JVM-only tests for Phase 049 ObservationVerifier. */
public final class ObservationVerifierTests {
    private ObservationVerifierTests() { }

    private static boolean has(List<Issue> issues, String code) {
        for (Issue issue : issues) if (issue.getCode().equals(code)) return true;
        return false;
    }

    public static void run() {
        long t = 1_800_000_000_000L;
        ObservationVerifier verifier = new ObservationVerifier(60.0);

        List<Issue> fast = verifier.verify(Arrays.asList(
            new Observation("pollen", "10", "vision", t, 0.9),
            new Observation("pollen", "100", "vision", t + 10_000L, 0.9)), t + 10_000L);
        RunTests.check(has(fast, "IMPLAUSIBLE_CHANGE"),
            "phase 049: a numeric change faster than the limit is flagged as implausible");

        List<Issue> normal = verifier.verify(Arrays.asList(
            new Observation("pollen", "10", "vision", t, 0.9),
            new Observation("pollen", "40", "vision", t + 60_000L, 0.9)), t + 60_000L);
        RunTests.check(normal.isEmpty(), "phase 049: a change within the rate limit is accepted");

        List<Issue> contradiction = verifier.verify(Arrays.asList(
            new Observation("field", "Pine Tree", "vision", t, 0.9),
            new Observation("field", "Sunflower", "ocr", t, 0.9)), t);
        RunTests.check(has(contradiction, "CONTRADICTION"),
            "phase 049: two values for one key at one instant are a contradiction");

        List<Issue> future = verifier.verify(Collections.singletonList(
            new Observation("field", "Pine Tree", "vision", t + 5_000L, 0.9)), t);
        RunTests.check(has(future, "FUTURE_TIMESTAMP"), "phase 049: an observation dated after now is flagged");

        RunTests.check(verifier.verify(Collections.<Observation>emptyList(), t).isEmpty(),
            "phase 049: no observations give no issues");
        boolean bad = false;
        try { new ObservationVerifier(0.0); } catch (IllegalArgumentException expected) { bad = true; }
        RunTests.check(bad, "phase 049: the rate limit must be positive");
    }
}
