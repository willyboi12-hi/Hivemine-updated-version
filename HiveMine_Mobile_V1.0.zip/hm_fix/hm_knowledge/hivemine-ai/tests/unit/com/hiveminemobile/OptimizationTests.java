package com.hiveminemobile;

import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.optimize.*;

import java.util.Arrays;

public final class OptimizationTests {
    private OptimizationTests() {}
    public static void run() {
        PerformanceProfiler p = new PerformanceProfiler();
        p.record(new PerfSample("tick", 10));
        p.record(new PerfSample("tick", 30));
        RunTests.check(p.count("tick") == 2 && p.avgMs("tick") == 20.0, "081 profiler avg");
        RunTests.check(p.maxMs("tick") == 30, "081 profiler max");

        PathCostModel path = new PathCostModel();
        double c1 = path.cost(100, 0, 50);
        double c2 = path.cost(100, 5, 50);
        RunTests.check(c2 > c1, "082 jumps cost more");
        RunTests.check("A".equals(path.betterField("A", 1.0, "B", 2.0)), "082 better field");

        CooldownOptimizer cd = new CooldownOptimizer(0.9, 1.1);
        long next = cd.nextAllowedMs(1000, 1000, 0.0);
        RunTests.check(next == 1000 + 900, "083 min factor");
        RunTests.check(cd.ready(1900, next), "083 ready");

        ResourceBudget b = new ResourceBudget(5);
        RunTests.check(b.trySpend(3) && b.remaining() == 2, "084 spend");
        RunTests.check(!b.trySpend(3), "084 deny overspend");
        b.refill();
        RunTests.check(b.remaining() == 5, "084 refill");

        ObservationCache<String> cache = new ObservationCache<String>(100);
        cache.put("x", 0);
        RunTests.check("x".equals(cache.get(50)), "085 hit");
        RunTests.check(cache.get(150) == null, "085 ttl expire");

        BatchDecisionOptimizer batch = new BatchDecisionOptimizer();
        RunTests.check(batch.collapse(Arrays.asList(ManagerGoal.FARM_POLLEN, ManagerGoal.FARM_POLLEN))
                        == ManagerGoal.FARM_POLLEN, "086 streak farm");
        RunTests.check(batch.collapse(Arrays.asList(ManagerGoal.STANDBY, ManagerGoal.FARM_POLLEN))
                        == ManagerGoal.STANDBY, "086 single farm stays standby noise");

        LoadShedder shed = new LoadShedder(0.7, 0.9);
        RunTests.check(shed.allow(LoadShedder.Priority.CRITICAL, 0.99), "087 critical always");
        RunTests.check(!shed.allow(LoadShedder.Priority.LOW, 0.6), "087 drop low");

        OptimizationEngine eng = new OptimizationEngine(new OptimizationPolicy());
        eng.optimizeGoalStream(ManagerGoal.FARM_POLLEN);
        ManagerGoal g = eng.optimizeGoalStream(ManagerGoal.FARM_POLLEN);
        RunTests.check(g == ManagerGoal.FARM_POLLEN, "089 engine batch");
        RunTests.check(eng.allowWork(LoadShedder.Priority.HIGH, 0.5), "089 allow high");
    }
}
