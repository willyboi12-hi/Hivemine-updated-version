package com.hiveminemobile;

import com.hiveminemobile.ai.modules.PerformanceAI;
import com.hiveminemobile.ai.modules.PerformanceAI.Report;
import com.hiveminemobile.ai.modules.PerformanceAI.Sample;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 021 PerformanceAI. */
public final class PerformanceAITests {
    private PerformanceAITests() { }

    public static void run() {
        PerformanceAI performance = new PerformanceAI();
        RunTests.check(performance.getCapabilities().contains("analyze.performance"), "phase 021 exposes analyze.performance");

        Report memory = performance.analyze(Arrays.asList(new Sample(0L, 50.0, 800L, 5.0), new Sample(1L, 90.0, 1200L, 10.0)));
        RunTests.check(Math.abs(memory.getAverageCpu() - 70.0) < 1e-9 && memory.getPeakCpu() == 90.0,
            "CPU average and peak are computed from the samples");
        RunTests.check(memory.getFindings().size() == 1 && memory.getFindings().get(0).startsWith("Memory peaked"),
            "only the memory limit is breached in this sample set");

        Report cpu = performance.analyze(Collections.singletonList(new Sample(0L, 95.0, 100L, 1.0)));
        RunTests.check(cpu.getFindings().get(0).startsWith("CPU averages"), "an average CPU above the limit is reported");

        Report fine = performance.analyze(Collections.singletonList(new Sample(0L, 30.0, 100L, 2.0)));
        RunTests.check(fine.getFindings().size() == 1 && fine.getFindings().get(0).equals("Within limits"),
            "samples inside every limit report within limits");

        boolean empty = false;
        try { performance.analyze(Collections.<Sample>emptyList()); } catch (IllegalArgumentException expected) { empty = true; }
        RunTests.check(empty, "an empty sample set is rejected");
        boolean badCpu = false;
        try { new Sample(0L, 101.0, 0L, 0.0); } catch (IllegalArgumentException expected) { badCpu = true; }
        RunTests.check(badCpu, "CPU above 100 percent is rejected");
    }
}
