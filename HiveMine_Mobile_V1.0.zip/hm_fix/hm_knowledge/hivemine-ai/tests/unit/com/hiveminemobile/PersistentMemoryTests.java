package com.hiveminemobile;

import com.hiveminemobile.ai.shared.PersistentMemoryStore;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** JVM-only tests for Phase 034 PersistentMemoryStore. */
public final class PersistentMemoryTests {
    private PersistentMemoryTests() { }

    public static void run() {
        try {
            Path file = Files.createTempFile("hivemine_memory", ".txt");
            PersistentMemoryStore store = new PersistentMemoryStore();
            store.put("note.tabs", "a\tb\nc\\d\re", 100L);
            store.put("field.current", "Pine Tree", 200L);
            store.save(file);

            PersistentMemoryStore loaded = PersistentMemoryStore.load(file);
            RunTests.check(loaded.size() == 2 && "a\tb\nc\\d\re".equals(loaded.get("note.tabs").getValue()),
                "phase 034: text with tabs, newlines, backslashes and carriage returns round-trips");
            RunTests.check(loaded.get("field.current").getSavedAtMillis() == 200L,
                "phase 034: the save time is kept with each record");

            Files.write(file, Arrays.asList("good\tvalue\t300", "broken line", "bad\\q\tv\t1", "k\tv\tnotanumber"),
                StandardCharsets.UTF_8, java.nio.file.StandardOpenOption.APPEND);
            PersistentMemoryStore damaged = PersistentMemoryStore.load(file);
            RunTests.check(damaged.getCorruptLines() == 3 && damaged.get("good") != null,
                "phase 034: malformed lines are skipped and counted, and valid lines still load");
            Files.deleteIfExists(file);
        } catch (java.io.IOException failure) {
            RunTests.check(false, "phase 034: memory file I/O succeeded: " + failure.getMessage());
        }
        boolean blank = false;
        try { new PersistentMemoryStore().put("", "x", 1L); } catch (IllegalArgumentException expected) { blank = true; }
        RunTests.check(blank, "phase 034: a blank memory key is rejected");
    }
}
