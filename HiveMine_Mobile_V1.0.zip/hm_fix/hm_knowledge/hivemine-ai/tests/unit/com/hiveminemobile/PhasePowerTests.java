package com.hiveminemobile;

import com.hiveminemobile.ai.decision.PowerDecisionEngine;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.manager.intel.ManagerIntelligenceLoop;
import com.hiveminemobile.ai.manager.intel.ManagerPolicyEngine;
import com.hiveminemobile.ai.manager.intel.SpecialistVote;
import com.hiveminemobile.ai.modules.FieldAI;
import com.hiveminemobile.ai.modules.SignalIntelligence;
import com.hiveminemobile.ai.phases.PhaseCatalog;
import com.hiveminemobile.ai.phases.PhaseExecutor;

import java.util.Collections;
import java.util.HashMap;

public final class PhasePowerTests {
    private PhasePowerTests() {}

    public static void run() {
        RunTests.check(PhaseCatalog.count() == 250, "250 phases in catalog");
        RunTests.check(PhaseCatalog.implementedCount() == 250, "250 implemented markers");
        RunTests.check(PhaseCatalog.get(1) != null && PhaseCatalog.get(250) != null, "phase 1 and 250 exist");
        RunTests.check(PhaseCatalog.get(21).name.contains("Vision"), "phase 21 vision specialist");

        PhaseExecutor ex = new PhaseExecutor();
        int ok = ex.verifyAll();
        RunTests.check(ok == 250, "all 250 phases verify ok: " + ok);

        PowerDecisionEngine eng = new PowerDecisionEngine();
        PowerDecisionEngine.Factors f = new PowerDecisionEngine.Factors();
        f.userWantsFarm = true;
        f.pollenRate = 0.9;
        RunTests.check(eng.decide(f, null) == ManagerGoal.FARM_POLLEN, "power farm");
        f.questComplete = true;
        RunTests.check(eng.decide(f, null) == ManagerGoal.TURN_IN_QUEST, "power quest priority");
        f.faulted = true;
        RunTests.check(eng.decide(f, null) == ManagerGoal.SHUTDOWN, "power shutdown");

        HashMap<String, Double> sig = new HashMap<String, Double>();
        sig.put("pine", 10.0);
        sig.put("clover", 3.0);
        RunTests.check(SignalIntelligence.rankedKeys(sig).get(0).equals("pine"), "signal rank");
        RunTests.check(new FieldAI().rankedInsights(sig).get(0).equals("pine"), "field ranked insights");

        ManagerIntelligenceLoop loop = new ManagerIntelligenceLoop(null);
        loop.setUsePowerEngine(true);
        ManagerPolicyEngine.WorldFlags w = new ManagerPolicyEngine.WorldFlags();
        w.userWantsFarm = true;
        ManagerGoal g = loop.step(w, Collections.singletonList(
                new SpecialistVote("Farming", ManagerGoal.FARM_POLLEN, 0.9, "x")));
        RunTests.check(g == ManagerGoal.FARM_POLLEN, "powered loop farms");
    }
}
