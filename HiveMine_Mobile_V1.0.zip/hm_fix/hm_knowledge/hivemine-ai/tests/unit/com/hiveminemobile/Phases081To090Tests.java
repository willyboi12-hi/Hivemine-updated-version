package com.hiveminemobile;

import com.hiveminemobile.ai.adaptive.AdaptiveConfigurationEngine;
import com.hiveminemobile.ai.android.AndroidConfigurationSyncManager;
import com.hiveminemobile.ai.android.AndroidIntegrationManager;
import com.hiveminemobile.ai.android.AndroidLifecycleController;
import com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge;
import com.hiveminemobile.ai.android.AndroidPermissionManager;
import com.hiveminemobile.ai.android.ScreenObservationManager;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.feedback.LearningFeedbackController;
import com.hiveminemobile.ai.history.HistoricalPerformanceAnalyzer;
import com.hiveminemobile.ai.memory.DecisionRecord;
import com.hiveminemobile.ai.memory.ManagerMemory;
import com.hiveminemobile.ai.tuning.AIOptimizationManager;
import java.util.*;

/** Phases 081–090 checks. */
public final class Phases081To090Tests {
    private Phases081To090Tests() {}

    static final byte[] PNG = {(byte) 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0};

    static final class FakePort implements MacroPort {
        MacroStatus status = MacroStatus.connected(false, "idle");
        int starts, stops, recovers;
        public void start() { starts++; }
        public void stop() { stops++; }
        public void recover() { recovers++; }
        public MacroStatus readStatus() { return status; }
    }

    static ManagerMemory mem(String cap, String decision, int ok, int bad) {
        ManagerMemory m = new ManagerMemory(200);
        for (int i = 0; i < ok; i++) m.record("s" + i, cap, "farming", decision, DecisionRecord.Outcome.SUCCESS, "", i);
        for (int i = 0; i < bad; i++) m.record("f" + i, cap, "farming", decision, DecisionRecord.Outcome.FAILURE, "", 500 + i);
        return m;
    }

    public static void run() {
        // Phase 081
        HistoricalPerformanceAnalyzer an = new HistoricalPerformanceAnalyzer();
        ManagerMemory h = mem("farm.pollen", "field-a", 3, 0);
        for (int i = 0; i < 3; i++) h.record("b" + i, "farm.pollen", "farming", "field-b", DecisionRecord.Outcome.FAILURE, "", 900 + i);
        h.record("u", "farm.pollen", "farming", "field-a", DecisionRecord.Outcome.UNKNOWN, "", 1000);
        HistoricalPerformanceAnalyzer.Report r = an.analyze(h.recent(200));
        RunTests.check(r.byCapability.get("farm.pollen").success == 3, "phase 081: counts successes per capability");
        RunTests.check(r.byCapability.get("farm.pollen").failure == 3, "phase 081: counts failures per capability");
        RunTests.check(r.repeatedFailures.contains("field-b"), "phase 081: repeated failures are reported");
        RunTests.check(r.successfulDecisions.contains("field-a"), "phase 081: repeated successes are reported");
        RunTests.check(!r.byCapability.containsKey("unknown"), "phase 081: UNKNOWN outcomes are not counted as success or failure");
        RunTests.check(r.toMarkdown().contains("Performance report"), "phase 081: report renders to markdown");
        RunTests.check(an.rateOf(h.recent(200), "field-a") == 1.0, "phase 081: rateOf computes success rate per decision");
        RunTests.check(Double.isNaN(an.rateOf(h.recent(200), "missing")), "phase 081: rateOf is NaN for unknown decisions");
        RunTests.check(an.analyze(null).incomplete == 0, "phase 081: null list analyzes to empty report");
        RunTests.check(an.analyze(Collections.singletonList((DecisionRecord) null)).incomplete == 1, "phase 081: null records are counted as incomplete");

        // Phase 082
        Map<String, String> initial = new TreeMap<>();
        initial.put("farm.speed", "1"); initial.put("ui.theme", "dark"); initial.put("safety.limit", "9");
        AdaptiveConfigurationEngine eng = new AdaptiveConfigurationEngine(initial,
            new HashSet<>(Arrays.asList("farm.speed", "ui.theme")), new HashSet<>(Collections.singletonList("ui.theme")));
        List<AdaptiveConfigurationEngine.Proposal> props = eng.propose(Arrays.asList(
            new String[]{"farm.speed", "2"}, new String[]{"ui.theme", "light"}, new String[]{"safety.limit", "1"},
            new String[]{"farm.speed", "3"}));
        RunTests.check(props.isEmpty(), "phase 082: conflicting duplicate suggestions for one key are all refused");
        props = eng.propose(Arrays.asList(new String[]{"farm.speed", "2"}, new String[]{"ui.theme", "light"}, new String[]{"safety.limit", "1"}));
        RunTests.check(props.size() == 1 && props.get(0).key.equals("farm.speed"), "phase 082: only adjustable, unlocked keys are proposed");
        RunTests.check(eng.active().get("farm.speed").equals("1"), "phase 082: proposals do not change the active configuration");
        RunTests.check(eng.approve(props.get(0).id) && eng.active().get("farm.speed").equals("2"), "phase 082: approved proposal is applied");
        RunTests.check(!eng.approve(props.get(0).id), "phase 082: an approved proposal cannot be approved twice");
        RunTests.check(eng.rollback() && eng.active().get("farm.speed").equals("1"), "phase 082: rollback restores the previous value");
        RunTests.check(!eng.rollback() && eng.historyDepth() == 0, "phase 082: rollback with no history returns false");
        Map<String, String> other = new TreeMap<>(initial); other.put("farm.speed", "5"); other.remove("ui.theme");
        Map<String, String[]> d = eng.diff(other);
        RunTests.check(d.containsKey("farm.speed") && d.containsKey("ui.theme"), "phase 082: diff reports changed and missing keys");
        RunTests.check(!d.containsKey("safety.limit"), "phase 082: diff ignores unchanged keys");

        // Phase 083
        LearningFeedbackController fb = new LearningFeedbackController();
        List<LearningFeedbackController.Feedback> seen = new ArrayList<>();
        fb.subscribe(seen::add);
        fb.subscribe(f -> { throw new RuntimeException("bad listener"); });
        fb.subscribe(f -> seen.add(f));
        RunTests.check(fb.submit("t1", "v1", "SUCCESS", 1), "phase 083: valid feedback is accepted");
        RunTests.check(fb.submit("t2", "v1", "FAILURE", 2), "phase 083: failure feedback is accepted");
        RunTests.check(!fb.submit("", "v1", "SUCCESS", 3) && !fb.submit("t3", "v1", "MAYBE", 3), "phase 083: incomplete or unknown feedback is refused");
        RunTests.check(fb.rejectedCount() == 2, "phase 083: refused feedback is counted");
        RunTests.check(seen.size() == 4, "phase 083: a throwing listener does not stop the other listeners");
        RunTests.check(fb.successRate("v1").getAsDouble() == 0.5, "phase 083: success rate per config version");
        RunTests.check(!fb.successRate("v9").isPresent(), "phase 083: unknown config version has no success rate");
        RunTests.check(fb.history().size() == 2, "phase 083: history holds only accepted feedback");

        // Phase 084
        AIOptimizationManager opt = new AIOptimizationManager(100, 1000);
        opt.recordSubsystem("vision", 300); opt.recordSubsystem("vision", 500);
        opt.recordSubsystem("nav", 10);
        opt.recordTask("scan"); opt.recordTask("scan");
        opt.sampleMemory(5000);
        RunTests.check(opt.averageMillis("vision") == 400.0, "phase 084: average subsystem time");
        RunTests.check(Double.isNaN(opt.averageMillis("none")), "phase 084: no samples gives NaN");
        List<String> recs = opt.recommendations();
        RunTests.check(recs.stream().anyMatch(s -> s.startsWith("Slow subsystem vision")), "phase 084: slow subsystem is recommended");
        RunTests.check(recs.stream().noneMatch(s -> s.contains("nav")), "phase 084: fast subsystem is not recommended");
        RunTests.check(recs.stream().anyMatch(s -> s.startsWith("Repeated work scan")), "phase 084: repeated work is recommended");
        RunTests.check(recs.stream().anyMatch(s -> s.startsWith("Peak memory")), "phase 084: memory over limit is recommended");
        boolean badArgs = false;
        try { new AIOptimizationManager(10, 0); } catch (IllegalArgumentException e) { badArgs = true; }
        RunTests.check(badArgs, "phase 084: non-positive memory limit is refused");

        // Phase 085
        AndroidIntegrationManager ai = new AndroidIntegrationManager();
        RunTests.check(!ai.canInitialize() && ai.missing().size() == 3, "phase 085: nothing registered means nothing can initialize");
        RunTests.check(ai.statusOf("macro-port") == AndroidIntegrationManager.Status.UNKNOWN, "phase 085: unreported component is UNKNOWN");
        ai.register("macro-port", AndroidIntegrationManager.Status.AVAILABLE);
        ai.register("accessibility-service", AndroidIntegrationManager.Status.UNKNOWN);
        ai.register("configuration-storage", AndroidIntegrationManager.Status.AVAILABLE);
        RunTests.check(!ai.canInitialize() && ai.missing().equals(Collections.singletonList("accessibility-service")),
            "phase 085: UNKNOWN is never treated as available");
        ai.update("accessibility-service", AndroidIntegrationManager.Status.AVAILABLE);
        RunTests.check(ai.canInitialize(), "phase 085: all required components available allows initialization");
        RunTests.check(!ai.register("macro-port", AndroidIntegrationManager.Status.UNAVAILABLE), "phase 085: duplicate registration is refused");

        // Phase 086
        AndroidLifecycleController life = new AndroidLifecycleController(ai);
        RunTests.check(life.start() && life.state() == AndroidLifecycleController.State.RUNNING, "phase 086: start works when integration is ready");
        RunTests.check(!life.start(), "phase 086: duplicate start is refused");
        life.interrupt();
        RunTests.check(life.state() == AndroidLifecycleController.State.STOPPED && life.wasInterrupted(), "phase 086: interrupt stops and records it");
        RunTests.check(life.start(), "phase 086: start works again after interruption");
        RunTests.check(life.stop() && !life.stop(), "phase 086: stop works once; second stop is a no-op");
        Map<String, String> snap = new TreeMap<>(); snap.put("k", "v");
        life.persist(snap);
        RunTests.check(life.restoreAfterRestart().get("k").equals("v"), "phase 086: persisted state is restored when integration is ready");
        AndroidIntegrationManager notReady = new AndroidIntegrationManager();
        AndroidLifecycleController blocked = new AndroidLifecycleController(notReady);
        RunTests.check(!blocked.start() && blocked.restoreAfterRestart().isEmpty(), "phase 086: start and restore are refused when integration is not ready");

        // Phase 087
        Set<String> granted = new HashSet<>(Collections.singletonList("accessibility"));
        AndroidPermissionManager perm = new AndroidPermissionManager(granted::contains);
        RunTests.check(perm.featureEnabled("macro-control"), "phase 087: feature enabled when its permission is granted");
        RunTests.check(!perm.featureEnabled("screen-observation"), "phase 087: feature disabled when its permission is missing");
        RunTests.check(perm.explain("screen-observation").contains("screen-capture"), "phase 087: explain names the missing permission");
        granted.remove("accessibility");
        RunTests.check(!perm.featureEnabled("macro-control") && perm.revoked().contains("accessibility"), "phase 087: revoked permission is detected");
        AndroidPermissionManager broken = new AndroidPermissionManager(p -> { throw new SecurityException("x"); });
        RunTests.check(broken.state("accessibility") == AndroidPermissionManager.State.UNKNOWN && !broken.featureEnabled("macro-control"),
            "phase 087: provider exception is UNKNOWN and not granted");
        RunTests.check(!perm.featureEnabled("no-such-feature") && perm.explain("no-such-feature").contains("unknown"), "phase 087: unknown feature is not enabled");

        // Phase 088
        Set<String> screenGranted = new HashSet<>(Collections.singletonList("screen-capture"));
        AndroidPermissionManager sp = new AndroidPermissionManager(screenGranted::contains);
        final byte[][] next = {PNG};
        ScreenObservationManager obs = new ScreenObservationManager(sp, () -> next[0], 1024, 2);
        RunTests.check(obs.observe(1) == ScreenObservationManager.Result.OBSERVED, "phase 088: valid PNG is observed when permitted");
        RunTests.check(obs.observe(2) == ScreenObservationManager.Result.OBSERVED && obs.observe(3) == ScreenObservationManager.Result.OBSERVED,
            "phase 088: buffer keeps accepting frames");
        RunTests.check(obs.observations().size() == 2 && obs.observations().get(0).atMillis == 2, "phase 088: buffer drops the oldest frame at capacity");
        next[0] = new byte[]{1, 2, 3};
        RunTests.check(obs.observe(4) == ScreenObservationManager.Result.INVALID_IMAGE, "phase 088: non-PNG image is rejected");
        next[0] = null;
        RunTests.check(obs.observe(5) == ScreenObservationManager.Result.NO_IMAGE, "phase 088: missing image is reported");
        ScreenObservationManager denied = new ScreenObservationManager(new AndroidPermissionManager(p -> false), () -> PNG, 1024, 2);
        RunTests.check(denied.observe(6) == ScreenObservationManager.Result.NOT_PERMITTED, "phase 088: no capture when screen observation is not permitted");
        ScreenObservationManager crash = new ScreenObservationManager(sp, () -> { throw new IllegalStateException("x"); }, 1024, 2);
        RunTests.check(crash.observe(7) == ScreenObservationManager.Result.FAILED, "phase 088: capture exception is reported as FAILED");

        // Phase 089
        FakePort port = new FakePort();
        com.hiveminemobile.ai.control.AutomationController auth = new com.hiveminemobile.ai.control.AutomationController(port);
        auth.setAiControlEnabled(true);
        AndroidMacroCommunicationBridge bridge = new AndroidMacroCommunicationBridge(auth, 1000);
        RunTests.check(bridge.send(AndroidMacroCommunicationBridge.Command.START, 0).status() == AndroidMacroCommunicationBridge.Status.ACCEPTED && port.starts == 1,
            "phase 089: start is forwarded to the port when the macro is connected");
        RunTests.check(bridge.send(AndroidMacroCommunicationBridge.Command.START, 1) == null && port.starts == 1,
            "phase 089: duplicate pending command is prevented");
        port.status = MacroStatus.connected(true, "running");
        bridge.observe(port.status, 50);
        AndroidMacroCommunicationBridge.Request first = bridge.requests().get(0);
        RunTests.check(first.status() == AndroidMacroCommunicationBridge.Status.COMPLETED, "phase 089: start completes once the macro reports running");
        port.status = MacroStatus.disconnected("gone");
        AndroidMacroCommunicationBridge.Request rej = bridge.send(AndroidMacroCommunicationBridge.Command.STOP, 60);
        RunTests.check(rej.status() == AndroidMacroCommunicationBridge.Status.REJECTED && port.stops == 1,
            "phase 089: emergency stop is forwarded even when the macro is disconnected");
        port.status = MacroStatus.connected(true, "running", 0);
        AndroidMacroCommunicationBridge.Request rec = bridge.send(AndroidMacroCommunicationBridge.Command.RECOVER, 100);
        RunTests.check(port.recovers == 1 && rec.status() == AndroidMacroCommunicationBridge.Status.ACCEPTED, "phase 089: recover is forwarded");
        bridge.observe(port.status, 500);
        RunTests.check(rec.status() == AndroidMacroCommunicationBridge.Status.EXECUTING, "phase 089: recover is not falsely completed from an unchanged running state");
        port.status = MacroStatus.connected(true, "Recovery: reset and walk to field", 1);
        bridge.observe(port.status, 700);
        RunTests.check(rec.status() == AndroidMacroCommunicationBridge.Status.COMPLETED, "phase 089: recover completes only after a new recovery generation and running state");
        AndroidMacroCommunicationBridge.Request rec2 = bridge.send(AndroidMacroCommunicationBridge.Command.RECOVER, 800);
        port.status = MacroStatus.connected(true, "running", 1);
        bridge.observe(port.status, 1901);
        RunTests.check(rec2.status() == AndroidMacroCommunicationBridge.Status.TIMED_OUT, "phase 089: unconfirmed recovery times out");
        RunTests.check(bridge.send(null, 0) == null, "phase 089: null command is ignored");

        // Phase 090
        Map<String, String> macro = new TreeMap<>(); macro.put("speed", "1");
        Map<String, String> stored = new TreeMap<>(macro);
        AndroidConfigurationSyncManager.Store store = new AndroidConfigurationSyncManager.Store() {
            public Map<String, String> read() { return new TreeMap<>(stored); }
            public void write(Map<String, String> s) { stored.clear(); stored.putAll(s); }
        };
        AndroidConfigurationSyncManager sync = new AndroidConfigurationSyncManager(store);
        Map<String, String> profile = new TreeMap<>(); profile.put("speed", "2");
        RunTests.check(sync.sync(profile) == AndroidConfigurationSyncManager.Result.SYNCED && stored.get("speed").equals("2"), "phase 090: profile is written to the store");
        RunTests.check(sync.backupCount() == 1, "phase 090: previous settings are backed up before writing");
        RunTests.check(sync.sync(profile) == AndroidConfigurationSyncManager.Result.NO_CHANGE, "phase 090: identical profile is not written again");
        stored.put("speed", "9");
        RunTests.check(sync.sync(profile) == AndroidConfigurationSyncManager.Result.CONFLICT && stored.get("speed").equals("9"),
            "phase 090: outside change is a conflict and nothing is written");
        RunTests.check(sync.differences(profile).containsKey("speed"), "phase 090: differences report the conflicting key");
        stored.put("speed", "2");
        RunTests.check(sync.restorePrevious() && stored.get("speed").equals("1"), "phase 090: restorePrevious brings back the backed-up settings");
        RunTests.check(!sync.restorePrevious(), "phase 090: restore with no backups returns false");
        AndroidConfigurationSyncManager failing = new AndroidConfigurationSyncManager(new AndroidConfigurationSyncManager.Store() {
            public Map<String, String> read() { throw new RuntimeException("io"); }
            public void write(Map<String, String> s) { }
        });
        RunTests.check(failing.sync(profile) == AndroidConfigurationSyncManager.Result.FAILED, "phase 090: read failure is reported as FAILED");
    }
}
