package com.hiveminemobile;

import com.hiveminemobile.ai.compat.AndroidCompatibilityValidator;
import com.hiveminemobile.ai.conflict.*;
import com.hiveminemobile.ai.crosssystem.*;
import com.hiveminemobile.ai.monitor.*;
import com.hiveminemobile.ai.monitor.ExecutionEventListener.ExecutionEvent;
import com.hiveminemobile.ai.performance.*;
import com.hiveminemobile.ai.registry.UnifiedAISystemRegistry;
import com.hiveminemobile.ai.reliability.*;
import com.hiveminemobile.ai.scheduling.*;
import com.hiveminemobile.ai.stabilize.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Phases 091–100 (spec numbering). Phase 096 is one suite in this file, not the five separate
 * test classes named in the spec. Phase 097 runs on fixture projects under build/, not the real repo.
 */
public final class Phases091To100Tests {
    private Phases091To100Tests() {}

    static List<String> l(String... s) { return Arrays.asList(s); }

    static UnifiedAISystemRegistry farmRegistry() {
        UnifiedAISystemRegistry reg = new UnifiedAISystemRegistry();
        reg.register("farm", l("farming"), 0);
        reg.markInitialized("farm", 0);
        return reg;
    }

    static void write(Path p, String text) throws Exception {
        Files.createDirectories(p.getParent());
        Files.write(p, text.getBytes(StandardCharsets.UTF_8));
    }

    static Path fixture(String name) throws Exception {
        Path root = Paths.get("build", "tests-fixtures", name);
        if (Files.exists(root)) deleteTree(root);
        Files.createDirectories(root);
        return root;
    }

    static void deleteTree(Path p) throws Exception {
        if (!Files.exists(p)) return;
        Files.walk(p).sorted(Comparator.reverseOrder()).forEach(q -> q.toFile().delete());
    }

    static final String APP_GRADLE = "plugins { id 'com.android.application' }\n"
        + "android {\n  compileSdk 35\n  defaultConfig { minSdk 26\n    targetSdk 35 }\n"
        + "  compileOptions { sourceCompatibility JavaVersion.VERSION_17\n    targetCompatibility JavaVersion.VERSION_17 }\n}\n"
        + "dependencies {\n  implementation 'androidx.core:core:1.13.1'\n}\n";
    static final String TOP_GRADLE = "plugins { id 'com.android.application' version '8.7.3' apply false }\n";
    static final String WRAPPER = "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.9-bin.zip\n";

    static Path cleanProject(String name) throws Exception {
        Path r = fixture(name);
        write(r.resolve("app/build.gradle"), APP_GRADLE);
        write(r.resolve("build.gradle"), TOP_GRADLE);
        write(r.resolve("gradle/wrapper/gradle-wrapper.properties"), WRAPPER);
        write(r.resolve("app/src/main/AndroidManifest.xml"),
            "<manifest><application><activity android:name=\".Main\" android:exported=\"true\"/></application></manifest>");
        write(r.resolve("app/src/main/res/values/strings.xml"), "<resources><string name=\"app_name\">X</string></resources>");
        write(r.resolve("app/src/main/res/layout/main.xml"), "<TextView android:text=\"@string/app_name\"/>");
        return r;
    }

    public static void run() {
        try { runAll(); } catch (Exception e) { RunTests.check(false, "phases 091-100: unexpected exception " + e); }
    }

    static void runAll() throws Exception {
        // ---- 091 registry
        UnifiedAISystemRegistry reg = new UnifiedAISystemRegistry();
        RunTests.check(reg.register("farm", l("farming"), 0) == UnifiedAISystemRegistry.Result.REGISTERED, "phase 091: valid system registers");
        RunTests.check(reg.register("farm", l("farming"), 1) == UnifiedAISystemRegistry.Result.DUPLICATE, "phase 091: duplicate registration is detected");
        RunTests.check(reg.register("", l("x"), 1) == UnifiedAISystemRegistry.Result.INVALID, "phase 091: blank id is refused");
        RunTests.check(reg.register("q", l(), 1) == UnifiedAISystemRegistry.Result.INVALID, "phase 091: no capabilities is refused");
        RunTests.check(!reg.isUsable("farm") && reg.availableFor("farming").isEmpty(), "phase 091: registered but not initialized is not usable");
        RunTests.check(reg.markInitialized("farm", 2) && reg.isUsable("farm"), "phase 091: initialized system becomes usable");
        RunTests.check(reg.usableCapabilities().contains("farming"), "phase 091: Manager AI sees the capability as usable");
        RunTests.check(reg.shutdown("farm", 3) && !reg.isUsable("farm"), "phase 091: shutdown makes the system unusable");
        RunTests.check(reg.statusReport().get(0).contains("SHUT_DOWN"), "phase 091: status report shows shutdown");

        // ---- 092 scheduling
        UnifiedAISystemRegistry r2 = farmRegistry();
        IntelligentTaskScheduler sch = new IntelligentTaskScheduler(r2, 10, 60_000);
        RunTests.check(sch.submit("low", "farming", 1, Collections.<String>emptyList(), 0) == TaskQueueManager.Result.QUEUED, "phase 092: task queues");
        RunTests.check(sch.submit("high", "farming", 9, Collections.<String>emptyList(), 0) == TaskQueueManager.Result.QUEUED, "phase 092: second task queues");
        RunTests.check("high".equals(sch.next(1).id), "phase 092: higher priority runs first");
        RunTests.check(sch.submit("high", "farming", 9, Collections.<String>emptyList(), 0) == TaskQueueManager.Result.DUPLICATE, "phase 092: duplicate task refused");
        RunTests.check(sch.submit("self", "farming", 1, l("self"), 0) == TaskQueueManager.Result.INVALID, "phase 092: self-dependency refused");
        Map<String, List<String>> cyc = new HashMap<>();
        cyc.put("a", l("b")); cyc.put("b", l("a"));
        RunTests.check(TaskDependencyResolver.hasCycle(cyc), "phase 092: dependency cycle is detected");
        RunTests.check(TaskDependencyResolver.unmet(l("x", "y"), new HashSet<>(l("x"))).equals(l("y")), "phase 092: unmet dependencies listed");
        RunTests.check(sch.submit("after", "farming", 5, l("low"), 0) == TaskQueueManager.Result.QUEUED, "phase 092: dependent task queues");
        RunTests.check(sch.next(2) != null && sch.state("after").state() == ScheduledTask.State.QUEUED, "phase 092: dependent task waits for its dependency");
        RunTests.check(sch.complete("low", true, "", 3), "phase 092: completion recorded");
        RunTests.check(sch.next(4) != null || sch.state("after").state() == ScheduledTask.State.QUEUED, "phase 092: scheduler continues");
        RunTests.check(sch.cancel("after", 5) == TaskCancellationController.Result.CANCELLED || sch.state("after").state() != ScheduledTask.State.QUEUED,
            "phase 092: queued task cancels or has already moved on");
        RunTests.check(sch.cancel("missing", 5) == TaskCancellationController.Result.NOT_FOUND, "phase 092: cancelling an unknown task says so");

        UnifiedAISystemRegistry r3 = farmRegistry();
        IntelligentTaskScheduler exp = new IntelligentTaskScheduler(r3, 10, 1000);
        exp.submit("old", "farming", 1, Collections.<String>emptyList(), 0);
        r3.setAvailable("farm", false, 1);
        RunTests.check(exp.next(5000) == null && exp.state("old").state() == ScheduledTask.State.EXPIRED, "phase 092: task that waited too long expires");
        RunTests.check(exp.report().lines().stream().anyMatch(s -> s.contains("EXPIRED")), "phase 092: expiry is reported, not silent");

        IntelligentTaskScheduler full = new IntelligentTaskScheduler(farmRegistry(), 1, 60_000);
        full.submit("one", "farming", 1, Collections.<String>emptyList(), 0);
        RunTests.check(full.submit("two", "farming", 1, Collections.<String>emptyList(), 0) == TaskQueueManager.Result.FULL, "phase 092: full queue refuses instead of dropping");

        // ---- 093 communication
        List<String> failures = new ArrayList<>();
        CrossSystemCommunicationManager comm = new CrossSystemCommunicationManager(1000, (id, why) -> failures.add(id + " " + why));
        int[] handled = {0};
        comm.register("farm", m -> handled[0]++);
        comm.register("manager", m -> { });
        RunTests.check(comm.send(new CrossSystemMessage("", null, "manager", "farm", "REQUEST", "p", 0), 0)
            == CrossSystemCommunicationManager.SendResult.MALFORMED, "phase 093: malformed message refused");
        RunTests.check(comm.send(new CrossSystemMessage("m1", null, "manager", "nope", "REQUEST", "p", 0), 0)
            == CrossSystemCommunicationManager.SendResult.UNKNOWN_DESTINATION, "phase 093: unknown destination refused");
        RunTests.check(comm.send(new CrossSystemMessage("m2", "ghost", "farm", "manager", "RESPONSE", "ok", 0), 0)
            == CrossSystemCommunicationManager.SendResult.UNKNOWN_REQUEST, "phase 093: response to unknown request refused");
        RunTests.check(comm.send(new CrossSystemMessage("m3", null, "manager", "farm", "REQUEST", "p", 0), 0)
            == CrossSystemCommunicationManager.SendResult.SENT, "phase 093: valid message sent");
        RunTests.check(comm.deliver("m3", 1) == CrossSystemCommunicationManager.DeliveryResult.DELIVERED, "phase 093: message delivered");
        RunTests.check(comm.deliver("m3", 2) == CrossSystemCommunicationManager.DeliveryResult.DUPLICATE_PROCESSED, "phase 093: no duplicate processing");
        RunTests.check(handled[0] == 1, "phase 093: handler ran exactly once");
        RunTests.check(comm.send(new CrossSystemMessage("m4", null, "manager", "farm", "REQUEST", "p", 0), 0) == CrossSystemCommunicationManager.SendResult.SENT
            && comm.tick(5000).contains("m4") && failures.contains("m4 timed out"), "phase 093: undelivered message times out and Manager AI is told");
        RunTests.check(comm.logEntries().stream().anyMatch(s -> s.contains("TIMED_OUT m4")), "phase 093: timeout is logged");

        // ---- 094 conflicts
        List<ConfigRequest> reqs = Arrays.asList(
            new ConfigRequest("farming", "field", "A"), new ConfigRequest("quest", "field", "B"), new ConfigRequest("farming", "speed", "2"));
        AIConflictResolutionEngine eng = new AIConflictResolutionEngine();
        RunTests.check(eng.checkBeforeExecution(reqs).size() == 1, "phase 094: conflict is identified before execution");
        Map<String, String> prefs = new HashMap<>(); prefs.put("field", "A");
        Map<String, String> applied = eng.resolve(reqs, prefs, (k, rs) -> "B", Collections.<String>emptySet(), 1);
        RunTests.check("A".equals(applied.get("field")), "phase 094: user preference wins over both systems");
        RunTests.check("2".equals(applied.get("speed")), "phase 094: non-conflicting key still applied");
        RunTests.check(eng.records().get(0).decision == ConflictResolutionRecord.Decision.USER_PREFERENCE && "USER".equals(eng.records().get(0).decidedBy),
            "phase 094: resolution record names the user as decider");
        AIConflictResolutionEngine eng2 = new AIConflictResolutionEngine();
        Map<String, String> none = eng2.resolve(reqs, Collections.<String, String>emptyMap(), (k, rs) -> "ZZZ", Collections.<String>emptySet(), 2);
        RunTests.check(!none.containsKey("field"), "phase 094: arbiter returning a value nobody requested is refused, nothing applied");
        RunTests.check(eng2.records().stream().anyMatch(r -> r.decision == ConflictResolutionRecord.Decision.REJECTED), "phase 094: unresolved conflict is rejected and recorded");
        Map<String, String> blocked = eng2.resolve(reqs, Collections.<String, String>emptyMap(), (k, rs) -> "A", Collections.singleton("field"), 3);
        RunTests.check(!blocked.containsKey("field"), "phase 094: dependency-blocked conflict is rejected, not guessed");
        RunTests.check(new TaskConflictDetector().detect(Arrays.asList(
            new TaskConflictDetector.TaskClaim("farming", "field-A", "t1"), new TaskConflictDetector.TaskClaim("quest", "field-A", "t2"))).size() == 1,
            "phase 094: two systems claiming one resource is detected");

        // ---- 095 monitoring
        List<String> recovered = new ArrayList<>();
        UnifiedExecutionMonitor mon = new UnifiedExecutionMonitor(1000, (id, at) -> recovered.add(id));
        mon.receive(new ExecutionEvent("t1", ExecutionEvent.Type.ACCEPTED, 0));
        RunTests.check("ACCEPTED".equals(mon.statusOf("t1")), "phase 095: accepted is not treated as completed");
        mon.receive(new ExecutionEvent("t1", ExecutionEvent.Type.STARTED, 1));
        RunTests.check("RUNNING".equals(mon.statusOf("t1")), "phase 095: started moves to running");
        mon.receive(new ExecutionEvent("t1", ExecutionEvent.Type.COMPLETED, 2));
        RunTests.check("COMPLETED".equals(mon.statusOf("t1")), "phase 095: completed event completes the task");
        RunTests.check(!mon.receive(new ExecutionEvent("t1", ExecutionEvent.Type.FAILED, 3)) && "COMPLETED".equals(mon.statusOf("t1")),
            "phase 095: terminal task ignores later events");
        mon.receive(new ExecutionEvent("t2", ExecutionEvent.Type.ACCEPTED, 0));
        mon.receive(new ExecutionEvent("t2", ExecutionEvent.Type.STARTED, 0));
        RunTests.check(mon.sweep(500).isEmpty(), "phase 095: no stall before the limit");
        RunTests.check(mon.sweep(2000).equals(l("t2")) && recovered.equals(l("t2")), "phase 095: stalled task is detected and Recovery AI is notified");
        RunTests.check("STALLED".equals(mon.statusOf("t2")), "phase 095: stalled status recorded");
        mon.setSystemAvailable("quest", false);
        RunTests.check(mon.systemsDown().equals(l("quest")), "phase 095: a system that is down is reported");
        RunTests.check(mon.summary().contains("COMPLETED: 1") && mon.summary().contains("ACCEPTED: 0"), "phase 095: summary counts states separately");

        // ---- 096 integration (one suite)
        integrationSuite();

        // ---- 097 compatibility
        AndroidCompatibilityValidator v = new AndroidCompatibilityValidator();
        Path clean = cleanProject("clean");
        Map<String, String> env = new HashMap<>();
        Path sdk = fixture("sdk");
        Files.createDirectories(sdk.resolve("platforms"));
        env.put("ANDROID_HOME", sdk.toString());
        AndroidCompatibilityValidator.Report ok = v.validate(clean, env, "17");
        RunTests.check(ok.count(AndroidCompatibilityValidator.Level.BLOCKER) == 0, "phase 097: clean project has no blockers: " + ok.findings);
        RunTests.check(v.validate(clean, Collections.<String, String>emptyMap(), "17").count(AndroidCompatibilityValidator.Level.BLOCKER) == 1,
            "phase 097: missing Android SDK is a blocker");
        RunTests.check(v.validate(clean, env, "11").count(AndroidCompatibilityValidator.Level.BLOCKER) >= 1, "phase 097: JDK below project Java level is a blocker");
        Path bad = cleanProject("bad");
        write(bad.resolve("app/src/main/AndroidManifest.xml"), "<manifest><application><service android:name=\".S\"/></application></manifest>");
        RunTests.check(v.validate(bad, env, "17").findings.stream().anyMatch(f -> f.message.contains("without android:exported")),
            "phase 097: component without android:exported is a blocker at targetSdk 31+");
        Path wrongGradle = cleanProject("gradle");
        write(wrongGradle.resolve("gradle/wrapper/gradle-wrapper.properties"), "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip\n");
        RunTests.check(v.validate(wrongGradle, env, "17").findings.stream().anyMatch(f -> f.message.contains("needs Gradle 8.9")),
            "phase 097: AGP 8.7 with Gradle 8.4 is a blocker");
        Path missingStr = cleanProject("strings");
        write(missingStr.resolve("app/src/main/res/layout/main.xml"), "<TextView android:text=\"@string/not_defined\"/>");
        RunTests.check(v.validate(missingStr, env, "17").findings.stream().anyMatch(f -> f.message.contains("@string/not_defined")),
            "phase 097: undefined resource reference is a blocker");
        Path dyn = cleanProject("dyn");
        write(dyn.resolve("app/build.gradle"), APP_GRADLE.replace("1.13.1", "+"));
        RunTests.check(v.validate(dyn, env, "17").findings.stream().anyMatch(f -> f.level == AndroidCompatibilityValidator.Level.WARN && f.message.contains("dynamic")),
            "phase 097: dynamic dependency version is a warning");

        // ---- 098 reliability
        List<RecoveryValidationSuite.Outcome> rel = new ReliabilityValidationManager().runStandard();
        RunTests.check(rel.size() == 11, "phase 098: all 11 standard scenarios ran");
        RunTests.check(new ReliabilityTestReporter().unresolved(rel).isEmpty(), "phase 098: every scenario passes: " + new ReliabilityTestReporter().unresolved(rel));
        RunTests.check(new ReliabilityTestReporter().toText(rel).contains("passed"), "phase 098: report renders");
        RunTests.check(new RecoveryValidationSuite().run(Collections.singletonList(
            new SystemFailureScenario("forced", "always fails", () -> RecoveryValidationSuite.require(false, "forced failure"))))
            .get(0).passed == false, "phase 098: a failing scenario is reported as failed, not hidden");

        // ---- 099 performance
        SystemPerformanceValidationManager perf = new SystemPerformanceValidationManager();
        SystemPerformanceValidationManager.Measurement workload = perf.measureWorkload("2000 tasks", () -> {
            UnifiedAISystemRegistry rr = farmRegistry();
            IntelligentTaskScheduler ss = new IntelligentTaskScheduler(rr, 5000, 600_000);
            for (int i = 0; i < 2000; i++) ss.submit("w" + i, "farming", i % 10, Collections.<String>emptyList(), 0);
            int done = 0;
            ScheduledTask t;
            while ((t = ss.next(1)) != null) { ss.complete(t.id, true, "", 2); done++; }
            return done == 2000;
        });
        RunTests.check(workload.correct, "phase 099: workload produced correct results");
        RunTests.check(workload.passed(), "phase 099: workload is within its documented target: " + workload);
        RunTests.check(perf.measureResponse("lookup", () -> farmRegistry().isUsable("farm"), 20).correct, "phase 099: response measurement keeps correctness");
        RunTests.check(PerformanceRegressionDetector.compare(10, 8.0, 0.1) == PerformanceRegressionDetector.Verdict.REGRESSION, "phase 099: regression detected");
        RunTests.check(PerformanceRegressionDetector.compare(10, null, 0.1) == PerformanceRegressionDetector.Verdict.NO_BASELINE, "phase 099: no baseline is not a pass");
        ResourceConsumptionTracker res = new ResourceConsumptionTracker();
        res.start("sync"); res.start("spam");
        RunTests.check(res.unnecessary(Collections.singleton("sync")).equals(l("spam")), "phase 099: unnecessary background work is reported");
        MemoryUsageAnalyzer mem = new MemoryUsageAnalyzer(() -> 100L);
        mem.sample();
        RunTests.check(mem.peak() == 100L, "phase 099: memory peak recorded");

        // ---- 100 stabilization
        List<StabilizationChecklist.Item> items = StabilizationChecklist.check(HiveMineAIStabilizationManager.requiredComponents());
        RunTests.check(items.stream().allMatch(i -> i.present), "phase 100: every required component is present: " + items);
        AndroidCompatibilityValidator.Report compatClean = v.validate(clean, env, "17");
        ReleaseReadinessEvaluator.Result notReady = new HiveMineAIStabilizationManager().stabilize(items, Collections.<String>emptyList(), compatClean, "NOT_RUN");
        RunTests.check(notReady.verdict == ReleaseReadinessEvaluator.Verdict.NOT_READY, "phase 100: unverified Android build means NOT_READY");
        RunTests.check(notReady.blockers.stream().anyMatch(b -> b.contains("not verified")), "phase 100: the unverified build is listed as a blocker");
        ReleaseReadinessEvaluator.Result ready = new ReleaseReadinessEvaluator().evaluate(items, Collections.<String>emptyList(), Collections.<String>emptyList(), "VERIFIED");
        RunTests.check(ready.verdict == ReleaseReadinessEvaluator.Verdict.READY, "phase 100: READY only with verified build and no blockers");
        String md = new HiveMineAIStabilizationReport().toMarkdown(notReady, new IntegrationHealthReporter().lines(items, Collections.<String>emptyList()), HiveMineAIStabilizationManager.INCOMPLETE);
        RunTests.check(md.contains("NOT_READY") && md.contains("not proof"), "phase 100: report states the verdict and that it is not proof of release readiness");
        RunTests.check(new SystemIntegrityValidator().failures(Collections.singletonMap("x", Boolean.FALSE)).equals(l("x")), "phase 100: a failing integrity check is listed");
    }

    static void integrationSuite() {
        // Manager AI -> registry -> scheduler -> messages -> monitor, end to end.
        UnifiedAISystemRegistry reg = new UnifiedAISystemRegistry();
        RunTests.check(reg.register("farm", l("farming"), 0) == UnifiedAISystemRegistry.Result.REGISTERED, "phase 096: specialist registration");
        RunTests.check(!reg.register("farm", l("farming"), 0).equals(UnifiedAISystemRegistry.Result.REGISTERED), "phase 096: duplicate specialist registration refused");
        reg.markInitialized("farm", 0);
        IntelligentTaskScheduler sch = new IntelligentTaskScheduler(reg, 10, 60_000);
        UnifiedExecutionMonitor mon = new UnifiedExecutionMonitor(60_000, (id, at) -> { });
        List<String> managerInbox = new ArrayList<>();
        CrossSystemCommunicationManager comm = new CrossSystemCommunicationManager(5000, (id, why) -> managerInbox.add(id));
        comm.register("manager", m -> managerInbox.add(m.id));
        comm.register("farm", m -> { });
        RunTests.check(sch.submit("job", "farming", 5, Collections.<String>emptyList(), 0) == TaskQueueManager.Result.QUEUED, "phase 096: Manager AI submits a task");
        ScheduledTask t = sch.next(1);
        RunTests.check(t != null && "job".equals(t.id), "phase 096: scheduler dispatches to the registered system");
        RunTests.check(comm.send(new CrossSystemMessage("c1", null, "manager", "farm", "REQUEST", "job", 1), 1)
            == CrossSystemCommunicationManager.SendResult.SENT, "phase 096: request routed to specialist");
        RunTests.check(comm.deliver("c1", 2) == CrossSystemCommunicationManager.DeliveryResult.DELIVERED, "phase 096: specialist receives request");
        mon.receive(new ExecutionEvent("job", ExecutionEvent.Type.ACCEPTED, 1));
        mon.receive(new ExecutionEvent("job", ExecutionEvent.Type.STARTED, 2));
        mon.receive(new ExecutionEvent("job", ExecutionEvent.Type.COMPLETED, 3));
        sch.complete("job", true, "", 3);
        RunTests.check("COMPLETED".equals(mon.statusOf("job")) && sch.state("job").state() == ScheduledTask.State.DONE,
            "phase 096: scheduler and monitor agree the task finished");
        RunTests.check(comm.send(new CrossSystemMessage("c1", null, "manager", "farm", "REQUEST", "x", 1), 1)
            == CrossSystemCommunicationManager.SendResult.DUPLICATE_ID, "phase 096: invalid repeat request refused");

        // Shutdown: nothing new is dispatched to a system that has shut down.
        reg.shutdown("farm", 4);
        sch.submit("late", "farming", 5, Collections.<String>emptyList(), 4);
        RunTests.check(sch.next(5) == null, "phase 096: no dispatch after shutdown");

        // Concurrent submissions from two threads all land, with no lost tasks.
        UnifiedAISystemRegistry reg2 = farmRegistry();
        IntelligentTaskScheduler conc = new IntelligentTaskScheduler(reg2, 5000, 600_000);
        Thread a = new Thread(() -> { for (int i = 0; i < 500; i++) conc.submit("A" + i, "farming", 1, Collections.<String>emptyList(), 0); });
        Thread b = new Thread(() -> { for (int i = 0; i < 500; i++) conc.submit("B" + i, "farming", 1, Collections.<String>emptyList(), 0); });
        a.start(); b.start();
        try { a.join(); b.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        RunTests.check(conc.queued() == 1000, "phase 096: concurrent submissions all kept (" + conc.queued() + ")");

        // Configuration synchronisation path: conflict resolved, then applied.
        AIConflictResolutionEngine eng = new AIConflictResolutionEngine();
        Map<String, String> applied = eng.resolve(Arrays.asList(new ConfigRequest("farming", "field", "A"), new ConfigRequest("quest", "field", "A")),
            Collections.<String, String>emptyMap(), null, Collections.<String>emptySet(), 1);
        RunTests.check("A".equals(applied.get("field")), "phase 096: identical requests are not a conflict and apply");

        // Failure handling: a dependency that fails blocks its dependents with a visible reason.
        IntelligentTaskScheduler fail = new IntelligentTaskScheduler(farmRegistry(), 10, 60_000);
        fail.submit("p", "farming", 5, Collections.<String>emptyList(), 0);
        fail.submit("c", "farming", 5, l("p"), 0);
        ScheduledTask p = fail.next(1);
        fail.complete(p.id, false, "crashed", 2);
        fail.next(3);
        RunTests.check(fail.state("c").state() == ScheduledTask.State.FAILED && fail.state("c").reason().contains("dependency p"),
            "phase 096: failed dependency fails its dependents with a reason");

        // Invalid request types are refused rather than guessed at.
        RunTests.check(fail.submit("bad", "farming", 99, Collections.<String>emptyList(), 0) == TaskQueueManager.Result.INVALID, "phase 096: out-of-range priority refused");
        RunTests.check(!new IntegrationHealthReporter().lines(Collections.<StabilizationChecklist.Item>emptyList(), Collections.<String>emptyList()).isEmpty(),
            "phase 096: integration report generated");
    }

    static UnifiedAISystemRegistry farmRegistryFresh() { return farmRegistry(); }
}
