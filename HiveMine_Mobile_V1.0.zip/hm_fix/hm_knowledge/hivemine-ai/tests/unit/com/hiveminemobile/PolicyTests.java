package com.hiveminemobile;

import com.hiveminemobile.ai.policy.PolicySupervisor;
import com.hiveminemobile.ai.task.AssignmentGate;
import com.hiveminemobile.ai.task.Priority;
import com.hiveminemobile.ai.task.Task;
import com.hiveminemobile.ai.task.TaskCategory;
import com.hiveminemobile.ai.task.TaskManager;

/** JVM-only tests for Phase 009 permission and policy supervision. */
public final class PolicyTests {
    private PolicyTests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        PolicySupervisor policy = new PolicySupervisor();
        TaskManager tasks = new TaskManager(TaskTests.registry(), AssignmentGate.ALLOW_ALL, 3, 100);
        Task observe = tasks.create("look", "observe", Priority.NORMAL, TaskCategory.OBSERVATION, now).getTask();
        Task input = tasks.create("tap", "input.tap", Priority.NORMAL, TaskCategory.OBSERVATION, now).getTask();

        RunTests.check(policy.refuse(observe, "vision") != null, "phase 009 is default-deny for ungranted capabilities");
        RunTests.check(policy.grant("observe", now) && policy.refuse(observe, "vision") == null,
            "a user-granted capability passes the gate");
        RunTests.check(!policy.grant("input.tap", now) && !policy.isGranted("input.tap"),
            "input capabilities can never be granted");
        RunTests.check(policy.refuse(input, "vision") != null
            && policy.refuse(input, "vision").contains("never permitted"),
            "a task naming a hard-denied capability is refused as never permitted");
        RunTests.check(!policy.grant("game.memory", now) && !policy.grant("android.permission", now)
                && !policy.grant("policy.edit", now) && !policy.grant("bypass.check", now),
            "every hard-denied prefix is refused");
        RunTests.check(!policy.grant("Bad Cap", now), "invalid capability names cannot be granted");
        RunTests.check(!PolicySupervisor.isHardDenied("observe.screen") && PolicySupervisor.isHardDenied(null),
            "ordinary names are not hard-denied; missing names are");
        RunTests.check(policy.getGranted().contains("observe") && policy.getGranted().size() == 1,
            "only ordinary capabilities appear in the granted set");

        RunTests.check(policy.revoke("observe") && policy.refuse(observe, "vision") != null,
            "revoking a grant makes the capability refused again");
        RunTests.check(!policy.revoke("observe"), "revoking an ungranted capability reports nothing removed");

        TaskManager gated = new TaskManager(TaskTests.registry(), policy, 3, 100);
        String id = gated.create("look again", "observe", Priority.NORMAL, TaskCategory.OBSERVATION, now).getTask().getId();
        RunTests.check(gated.assign(id, now).getOutcome() == TaskManager.Outcome.REFUSED,
            "the supervisor blocks assignment when nothing is granted");
        policy.grant("observe", now);
        RunTests.check(gated.assign(id, now).isOk(), "the same assignment succeeds once the user grants it");

        RunTests.check(policy.getAuditTrail().size() >= 5, "the audit trail records grants, refusals and revocations");
        RunTests.check(policy.getAuditTrail().stream().anyMatch(e -> e.startsWith("grant refused, hard-denied")),
            "the audit trail names hard-denied attempts");
    }
}
