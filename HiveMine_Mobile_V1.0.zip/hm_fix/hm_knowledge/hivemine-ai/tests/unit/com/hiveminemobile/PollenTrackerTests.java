package com.hiveminemobile;

import com.hiveminemobile.ai.farming.PollenTracker;
import com.hiveminemobile.ai.modules.FarmingAI.Sample;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 053 PollenTracker. */
public final class PollenTrackerTests {
    private PollenTrackerTests() { }

    public static void run() {
        PollenTracker tracker = new PollenTracker();
        PollenTracker.Summary s = tracker.summarize(Arrays.asList(
            new Sample(120_000L, 60, null), new Sample(0L, 0, null), new Sample(60_000L, 30, null)));
        RunTests.check(Math.abs(s.getRatePerMinute() - 30.0) < 1e-9 && s.getLatestPercent() == 60,
            "phase 053: readings are ordered by time and the rate comes from FarmingAI");
        RunTests.check(s.getMinutesToFull() != null && Math.abs(s.getMinutesToFull() - 40.0 / 30.0) < 1e-9,
            "phase 053: minutes to full are estimated from the latest reading and the rate");
        PollenTracker.Summary flat = tracker.summarize(Arrays.asList(new Sample(0L, 50, null), new Sample(60_000L, 50, null)));
        RunTests.check(flat.getMinutesToFull() == null, "phase 053: no estimate is made when the bag is not filling");
        boolean empty = false;
        try { tracker.summarize(Collections.<Sample>emptyList()); } catch (IllegalArgumentException expected) { empty = true; }
        RunTests.check(empty, "phase 053: no readings is rejected");
    }
}
