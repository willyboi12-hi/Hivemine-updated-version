package com.hiveminemobile;

import com.hiveminemobile.ai.modules.PredictionAI;
import com.hiveminemobile.ai.modules.PredictionAI.Fit;
import com.hiveminemobile.ai.modules.PredictionAI.Forecast;
import com.hiveminemobile.ai.modules.PredictionAI.Point;
import java.util.ArrayList;
import java.util.List;

/** JVM-only tests for Phase 017 PredictionAI. */
public final class PredictionAITests {
    private PredictionAITests() { }

    private static final long MINUTE = 60_000L;

    public static void run() {
        long base = 1_800_000_000_000L;
        PredictionAI prediction = new PredictionAI();
        RunTests.check(prediction.getCapabilities().contains("analyze.forecast"), "phase 017 exposes analyze.forecast");

        List<Point> linear = series(base, 0, 10, 20, 30);
        Fit fit = prediction.fit(linear);
        RunTests.check(fit != null && Math.abs(fit.getSlopePerMinute() - 10.0) < 1e-9 && fit.getRSquared() > 0.999999,
            "a perfectly linear series fits exactly");
        Forecast forecast = prediction.timeToTarget(linear, 100.0);
        RunTests.check(forecast.getMinutesToTarget() != null && Math.abs(forecast.getMinutesToTarget() - 7.0) < 1e-9,
            "minutes to target are the gap divided by the rate");
        RunTests.check(Math.abs(forecast.getConfidence() - 0.4) < 1e-9,
            "confidence grows with readings and reaches 1 at ten readings");

        Forecast afterDrop = prediction.timeToTarget(series(base, 50, 60, 70, 20, 30, 40, 50), 100.0);
        RunTests.check(afterDrop.getMinutesToTarget() != null && Math.abs(afterDrop.getMinutesToTarget() - 5.0) < 1e-9,
            "a forecast starts from the latest rise after a drop");

        Forecast tooFew = prediction.timeToTarget(series(base, 10, 20), 100.0);
        RunTests.check(tooFew.getMinutesToTarget() == null && tooFew.getNote().contains("3 readings"),
            "fewer than three readings give no estimate");
        Forecast flat = prediction.timeToTarget(series(base, 40, 40, 40, 40), 100.0);
        RunTests.check(flat.getMinutesToTarget() == null && flat.getNote().contains("not rising"),
            "a flat series gives no estimate");

        Fit noisy = prediction.fit(series(base, 0, 12, 18, 33));
        RunTests.check(noisy.getRSquared() > 0.9 && noisy.getRSquared() < 1.0,
            "noisy readings lower the fit quality below 1");

        Double projected = prediction.projectValue(linear, 10.0);
        RunTests.check(projected != null && Math.abs(projected - 130.0) < 1e-9,
            "projection continues the fitted line from the last reading");
        RunTests.check(prediction.projectValue(series(base, 1, 2), 5.0) == null,
            "no projection is made without enough readings");

        boolean nan = false;
        try { new Point(base, Double.NaN); } catch (IllegalArgumentException expected) { nan = true; }
        RunTests.check(nan, "a non-finite reading is rejected");
    }

    /** Readings one minute apart starting at base. */
    private static List<Point> series(long base, double... values) {
        List<Point> points = new ArrayList<>();
        for (int i = 0; i < values.length; i++) points.add(new Point(base + i * MINUTE, values[i]));
        return points;
    }
}
