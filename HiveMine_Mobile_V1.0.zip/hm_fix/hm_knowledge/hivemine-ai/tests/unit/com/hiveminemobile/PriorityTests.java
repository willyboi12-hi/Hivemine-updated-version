package com.hiveminemobile;

import com.hiveminemobile.ai.task.AssignmentGate;
import com.hiveminemobile.ai.task.Priority;
import com.hiveminemobile.ai.task.PriorityScorer;
import com.hiveminemobile.ai.task.Task;
import com.hiveminemobile.ai.task.TaskCategory;
import com.hiveminemobile.ai.task.TaskManager;
import com.hiveminemobile.ai.task.TaskManager.Result;
import java.util.Arrays;
import java.util.List;

/** JVM-only tests for Phase 007 priority intelligence. */
public final class PriorityTests {
    private PriorityTests() { }

    private static final long MINUTE = 60_000L;

    public static void run() {
        long base = 1_800_000_000_000L;
        TaskManager tasks = new TaskManager(TaskTests.registry(), AssignmentGate.ALLOW_ALL, 3, 100);
        Task critical = make(tasks, Priority.CRITICAL, TaskCategory.RECOVERY, base);
        Task high = make(tasks, Priority.HIGH, TaskCategory.OBSERVATION, base);
        Task normal = make(tasks, Priority.NORMAL, TaskCategory.MAINTENANCE, base);
        Task low = make(tasks, Priority.LOW, TaskCategory.MAINTENANCE, base);

        RunTests.check(PriorityScorer.score(critical, base) == 440, "phase 007 scores critical recovery at 440");
        RunTests.check(PriorityScorer.score(high, base) == 320, "high observation scores 320");
        RunTests.check(PriorityScorer.score(normal, base) == 200, "normal maintenance scores 200");
        RunTests.check(PriorityScorer.score(low, base) == 100, "low maintenance scores 100 when fresh");

        RunTests.check(PriorityScorer.score(low, base + 60 * MINUTE) == 160,
            "waiting lifts a low task by one point per minute");
        RunTests.check(PriorityScorer.score(low, base + 600 * MINUTE) == 160,
            "waiting bonus is capped so no task climbs without limit");
        RunTests.check(PriorityScorer.score(low, base - 60 * MINUTE) == 100,
            "a task dated in the future gets no negative aging");

        RunTests.check(PriorityScorer.score(normal, base) > PriorityScorer.score(low, base),
            "a higher priority band outranks a lower one at the same age");
        Task failing = make(tasks, Priority.NORMAL, TaskCategory.OBSERVATION, base);
        RunTests.check(PriorityScorer.score(failing, base) == 220, "normal observation scores 220 before any failure");
        String id = failing.getId();
        tasks.assign(id, base);
        Task afterOne = tasks.fail(id, "vision", "blurred", base).getTask();
        RunTests.check(PriorityScorer.score(afterOne, base) == 210,
            "one failed attempt lowers a pending task by 10 points");
        tasks.assign(id, base);
        Task afterTwo = tasks.fail(id, "vision", "blurred", base).getTask();
        RunTests.check(PriorityScorer.score(afterTwo, base) == 200,
            "two failed attempts lower it by 20 points");

        List<Task> ranked = PriorityScorer.rank(Arrays.asList(low, normal, critical, high), base);
        RunTests.check(ranked.get(0).getId().equals(critical.getId()) && ranked.get(1).getId().equals(high.getId())
                && ranked.get(2).getId().equals(normal.getId()) && ranked.get(3).getId().equals(low.getId()),
            "rank orders tasks best first");

        RunTests.check(tasks.nextPending(base, 2).size() == 2
                && tasks.nextPending(base, 2).get(0).getId().equals(critical.getId()),
            "nextPending returns the highest-ranked pending task first");
        tasks.assign(critical.getId(), base);
        RunTests.check(tasks.nextPending(base, 10).stream().noneMatch(t -> t.getId().equals(critical.getId())),
            "assigned tasks leave the pending ranking");
        boolean limitRejected = false;
        try { tasks.nextPending(base, 0); } catch (IllegalArgumentException expected) { limitRejected = true; }
        RunTests.check(limitRejected, "nextPending rejects a non-positive limit");
    }

    private static Task make(TaskManager tasks, Priority priority, TaskCategory category, long at) {
        Result result = tasks.create(priority + " " + category, "observe", priority, category, at);
        return result.getTask();
    }
}
