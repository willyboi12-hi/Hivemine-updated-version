package com.hiveminemobile;

import com.hiveminemobile.ai.modules.QuestAI;
import com.hiveminemobile.ai.modules.QuestAI.Assessment;
import com.hiveminemobile.ai.modules.QuestAI.Status;

/** JVM-only tests for Phase 016 QuestAI. */
public final class QuestAITests {
    private QuestAITests() { }

    public static void run() {
        long t0 = 1_800_000_000_000L;
        long minute = 60_000L;
        QuestAI quest = new QuestAI();
        RunTests.check(quest.getCapabilities().contains("analyze.quest"), "phase 016 exposes analyze.quest");

        Assessment first = quest.observe("Brown Bear: collect pollen 45/100", t0);
        RunTests.check(first.getStatus() == Status.IN_PROGRESS && "Brown Bear: collect pollen".equals(first.getKey())
                && first.getCurrent() == 45 && first.getTarget() == 100,
            "a quest line is parsed into its objective and progress");
        RunTests.check(quest.observe("Brown Bear: collect pollen 60/100", t0 + 5 * minute).getStatus() == Status.IN_PROGRESS,
            "progress that moves keeps the quest in progress");
        Assessment stalled = quest.observe("Brown Bear: collect pollen 60/100", t0 + 20 * minute);
        RunTests.check(stalled.getStatus() == Status.STALLED && stalled.getNote().contains("15 minute"),
            "a quest with no progress past the limit is stalled");
        RunTests.check(quest.observe("Brown Bear: collect pollen 100/100", t0 + 21 * minute).getStatus() == Status.COMPLETE,
            "reaching the target completes the quest");

        RunTests.check(quest.observe("nonsense", t0).getStatus() == Status.UNREADABLE,
            "text that is not a quest line is unreadable");
        RunTests.check(quest.observe("Brown Bear: collect pollen 150/100", t0).getStatus() == Status.UNREADABLE,
            "progress above the target is unreadable");
        RunTests.check(quest.observe("Quest: collect pollen 1234567890/5", t0).getStatus() == Status.UNREADABLE,
            "oversized numbers are unreadable rather than overflowing");

        quest.observe("Pine Tree: collect pollen 60/100", t0);
        RunTests.check(quest.observe("Pine Tree: collect pollen 10/100", t0 + 30 * minute).getStatus() == Status.IN_PROGRESS,
            "a progress reset counts as a change, not a stall");

        boolean badLimit = false;
        try { new QuestAI(0L); } catch (IllegalArgumentException expected) { badLimit = true; }
        RunTests.check(badLimit, "a non-positive stall limit is rejected");
    }
}
