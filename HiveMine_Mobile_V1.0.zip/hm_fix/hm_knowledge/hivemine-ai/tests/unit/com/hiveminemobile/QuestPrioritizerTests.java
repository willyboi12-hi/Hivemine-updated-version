package com.hiveminemobile;

import com.hiveminemobile.ai.farming.QuestPrioritizer;
import com.hiveminemobile.ai.farming.QuestPrioritizer.Objective;
import java.util.Arrays;
import java.util.List;

/** JVM-only tests for Phase 057 QuestPrioritizer. */
public final class QuestPrioritizerTests {
    private QuestPrioritizerTests() { }

    public static void run() {
        List<QuestPrioritizer.Ranked> ranked = new QuestPrioritizer().rank(Arrays.asList(
            new Objective("A", 10, 5.0, null), new Objective("B", 2, 1.0, null),
            new Objective("C", 4, 2.0, 20), new Objective("D", 5, 1.0, 60)));
        RunTests.check(ranked.get(0).getName().equals("C") && Math.abs(ranked.get(0).getScore() - 1.0) < 1e-9,
            "phase 057: an objective due within 30 minutes is doubled and ranks first");
        RunTests.check(ranked.get(1).getName().equals("A") && ranked.get(2).getName().equals("B")
                && ranked.get(3).getName().equals("D"),
            "phase 057: reward per remaining unit orders the rest, with name breaking ties");
        boolean bad = false;
        try { new Objective("x", 0, 1.0, null); } catch (IllegalArgumentException expected) { bad = true; }
        RunTests.check(bad, "phase 057: remaining units must be at least 1");
    }
}
