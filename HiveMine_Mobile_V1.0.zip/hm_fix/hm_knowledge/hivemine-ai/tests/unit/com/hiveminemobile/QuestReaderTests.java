package com.hiveminemobile;

import com.hiveminemobile.ai.modules.QuestAI;
import com.hiveminemobile.ai.observation.QuestReader;
import java.util.Arrays;
import java.util.List;

/** JVM-only tests for Phase 046 QuestReader. */
public final class QuestReaderTests {
    private QuestReaderTests() { }

    public static void run() {
        QuestReader reader = new QuestReader(new QuestAI());
        List<QuestAI.Assessment> found = reader.read(Arrays.asList(
            "Brown Bear: collect pollen 45/100", "random noise", "Brown Bear: collect pollen 60/100"), 1_000L);
        RunTests.check(found.size() == 2 && found.get(1).getCurrent() == 60,
            "phase 046: quest lines are tracked and other OCR lines are skipped");
        RunTests.check(found.get(0).getStatus() == QuestAI.Status.IN_PROGRESS,
            "phase 046: recognized quests carry QuestAI's status");
        boolean nullQuest = false;
        try { new QuestReader(null); } catch (IllegalArgumentException expected) { nullQuest = true; }
        RunTests.check(nullQuest, "phase 046: a quest reader needs a quest tracker");
    }
}
