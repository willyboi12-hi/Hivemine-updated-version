package com.hiveminemobile;

import com.hiveminemobile.ai.modules.RecoveryAI;
import com.hiveminemobile.ai.modules.RecoveryAI.ErrorEvent;
import com.hiveminemobile.ai.modules.RecoveryAI.ErrorKind;
import com.hiveminemobile.ai.modules.RecoveryAI.Plan;
import com.hiveminemobile.ai.modules.RecoveryAI.Severity;
import com.hiveminemobile.ai.modules.RecoveryAI.Step;
import java.util.Arrays;
import java.util.Collections;

/** JVM-only tests for Phase 018 RecoveryAI. */
public final class RecoveryAITests {
    private RecoveryAITests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        long minute = 60_000L;
        RecoveryAI recovery = new RecoveryAI();
        RunTests.check(recovery.getCapabilities().contains("plan.recovery"), "phase 018 exposes plan.recovery");

        Plan none = recovery.plan(Collections.<ErrorEvent>emptyList(), now);
        RunTests.check(none.getSeverity() == Severity.INFO && none.getSteps().isEmpty() && none.isRequiresApproval(),
            "no errors gives an informational plan with no steps");

        Plan scene = recovery.plan(Arrays.asList(new ErrorEvent(ErrorKind.SCENE_UNKNOWN, now - 1_000L)), now);
        RunTests.check(scene.getSeverity() == Severity.WARNING
                && scene.getSteps().equals(Arrays.asList(Step.REOBSERVE_SCREEN, Step.WAIT_AND_OBSERVE)),
            "a single unknown scene asks for a re-check");

        Plan disconnect = recovery.plan(Arrays.asList(new ErrorEvent(ErrorKind.DISCONNECT, now - 1_000L)), now);
        RunTests.check(disconnect.getSteps().equals(Arrays.asList(Step.WAIT_AND_OBSERVE, Step.REJOIN_SERVER)),
            "a disconnect waits and then offers to rejoin");

        Plan refused = recovery.plan(Arrays.asList(new ErrorEvent(ErrorKind.GESTURE_REFUSED, now - 1_000L)), now);
        RunTests.check(refused.getSeverity() == Severity.CRITICAL
                && refused.getSteps().equals(Arrays.asList(Step.SAFE_STOP, Step.ASK_USER)),
            "a refused game input is critical and stops for the user");

        Plan repeated = recovery.plan(Arrays.asList(
            new ErrorEvent(ErrorKind.SCENE_UNKNOWN, now - 3_000L),
            new ErrorEvent(ErrorKind.STATE_STALE, now - 2_000L),
            new ErrorEvent(ErrorKind.DISCONNECT, now - 1_000L)), now);
        RunTests.check(repeated.getSeverity() == Severity.CRITICAL && repeated.getSteps().contains(Step.SAFE_STOP),
            "repeated errors escalate to a safe stop");
        RunTests.check(repeated.isRequiresApproval(), "every plan requires the user's approval");

        Plan stale = recovery.plan(Arrays.asList(new ErrorEvent(ErrorKind.DISCONNECT, now - 11 * minute)), now);
        RunTests.check(stale.getSeverity() == Severity.INFO, "errors outside the window are ignored");
        Plan future = recovery.plan(Arrays.asList(new ErrorEvent(ErrorKind.GESTURE_REFUSED, now + 1_000L)), now);
        RunTests.check(future.getSeverity() == Severity.INFO, "errors dated after now are ignored");

        boolean badKind = false;
        try { new ErrorEvent(null, now); } catch (IllegalArgumentException expected) { badKind = true; }
        RunTests.check(badKind, "an error event needs a kind");
    }
}
