package com.hiveminemobile;

import com.hiveminemobile.ai.shared.ResourceAllocator;
import com.hiveminemobile.ai.shared.ResourceAllocator.Grant;
import com.hiveminemobile.ai.shared.ResourceAllocator.Request;
import java.util.Arrays;
import java.util.List;

/** JVM-only tests for Phase 040 ResourceAllocator. */
public final class ResourceAllocatorTests {
    private ResourceAllocatorTests() { }

    private static int units(List<Grant> grants, String id) {
        for (Grant grant : grants) if (grant.getId().equals(id)) return grant.getUnits();
        return -1;
    }

    public static void run() {
        ResourceAllocator allocator = new ResourceAllocator();
        List<Grant> grants = allocator.allocate(10, Arrays.asList(
            new Request("vision", 3, 5), new Request("farming", 1, 10)));
        RunTests.check(units(grants, "vision") == 5 && units(grants, "farming") == 5,
            "phase 040: capacity is shared by priority and no request gets more than it asked for");
        RunTests.check(units(grants, "vision") + units(grants, "farming") == 10,
            "phase 040: the full capacity is used when requests can take it");

        List<Grant> scarce = allocator.allocate(4, Arrays.asList(
            new Request("high", 8, 100), new Request("low", 2, 100)));
        RunTests.check(units(scarce, "high") > units(scarce, "low") && units(scarce, "low") >= 1,
            "phase 040: higher priority gets more, and low priority is not starved");
        RunTests.check(units(scarce, "high") + units(scarce, "low") == 4,
            "phase 040: a scarce capacity is fully and exactly divided");

        RunTests.check(allocator.allocate(0, Arrays.asList(new Request("a", 5, 5))).get(0).getUnits() == 0,
            "phase 040: zero capacity grants nothing");
        boolean badPriority = false;
        try { new Request("x", 11, 1); } catch (IllegalArgumentException expected) { badPriority = true; }
        RunTests.check(badPriority, "phase 040: priority must be between 1 and 10");
    }
}
