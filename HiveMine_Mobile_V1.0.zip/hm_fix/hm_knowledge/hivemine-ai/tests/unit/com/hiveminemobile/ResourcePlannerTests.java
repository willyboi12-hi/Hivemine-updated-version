package com.hiveminemobile;

import com.hiveminemobile.ai.farming.ResourcePlanner;
import com.hiveminemobile.ai.farming.ResourcePlanner.PlannedRun;
import com.hiveminemobile.ai.farming.ResourcePlanner.Shortfall;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** JVM-only tests for Phase 056 ResourcePlanner. */
public final class ResourcePlannerTests {
    private ResourcePlannerTests() { }

    public static void run() {
        Map<String, Integer> first = new HashMap<>();
        first.put("sprinkler", 2);
        first.put("glue", 1);
        Map<String, Integer> second = Collections.singletonMap("glue", 2);
        Map<String, Integer> inventory = new HashMap<>();
        inventory.put("sprinkler", 4);
        inventory.put("glue", 10);
        List<Shortfall> short1 = new ResourcePlanner().plan(
            Arrays.asList(new PlannedRun("a", first, 3), new PlannedRun("b", second, 2)), inventory);
        RunTests.check(short1.size() == 1 && short1.get(0).getItem().equals("sprinkler") && short1.get(0).getShort() == 2,
            "phase 056: only items below the plan's total need appear, with the amount short");
        RunTests.check(new ResourcePlanner().plan(Collections.singletonList(new PlannedRun("a", first, 1)), inventory).isEmpty(),
            "phase 056: a plan the inventory covers has no shortfall");
        boolean zero = false;
        try { new PlannedRun("x", first, 0); } catch (IllegalArgumentException expected) { zero = true; }
        RunTests.check(zero, "phase 056: a planned run count must be at least 1");
    }
}
