package com.hiveminemobile;

import com.hiveminemobile.ai.observation.ResourceReader;
import com.hiveminemobile.ai.observation.ResourceReader.Reading;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** JVM-only tests for Phase 045 ResourceReader. */
public final class ResourceReaderTests {
    private ResourceReaderTests() { }

    public static void run() {
        Map<String, String> text = new HashMap<>();
        text.put("honey", "1.2K");
        text.put("pollen", "garbage");
        List<Reading> readings = new ResourceReader().read(text);
        RunTests.check(readings.size() == 2 && "honey".equals(readings.get(0).getResource())
                && readings.get(0).getCount() == 1200L,
            "phase 045: readable resource text becomes a count, listed by resource name");
        RunTests.check(readings.get(1).getCount() == null && "garbage".equals(readings.get(1).getRaw()),
            "phase 045: unreadable resource text is kept as raw text with no count, never guessed");
        RunTests.check(new ResourceReader().read(Collections.<String, String>emptyMap()).isEmpty(),
            "phase 045: no text gives no readings");
    }
}
