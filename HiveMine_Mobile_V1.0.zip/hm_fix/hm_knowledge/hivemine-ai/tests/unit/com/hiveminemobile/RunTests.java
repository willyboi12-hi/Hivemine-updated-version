package com.hiveminemobile;

/** Runs the HiveMine AI test suite. Each check prints FAIL with its name when it does not hold. */
public final class RunTests {
    static int passed = 0;
    static int failed = 0;

    static void check(boolean ok, String name) {
        if (ok) passed++;
        else {
            failed++;
            System.out.println("FAIL  " + name);
        }
    }

    public static void main(String[] args) {
        AIArchitectureTests.run();
        ManagerArchitectureTests.run();
        SpecialistRegistryTests.run();
        GlobalStateTests.run();
        MessagingTests.run();
        TaskTests.run();
        PriorityTests.run();
        MemoryTests.run();
        PolicyTests.run();
        HealthTests.run();
        CoordinatorTests.run();
        VisionAITests.run();
        StateAITests.run();
        FarmingAITests.run();
        LearningIntegrationTests.run();
        Phases081To090Tests.run();
        Phases091To100Tests.run();
        NavigationAITests.run();
        InventoryAITests.run();
        QuestAITests.run();
        PredictionAITests.run();
        RecoveryAITests.run();
        LearningAITests.run();
        DiagnosticsAITests.run();
        Stage2IntegrationTests.run();
        PerformanceAITests.run();
        ConfigurationAITests.run();
        SessionAITests.run();
        StrategyAITests.run();
        CompatibilityAITests.run();
        NotificationAITests.run();
        SecurityAITests.run();
        AnalyticsAITests.run();
        SimulationAITests.run();
        DocumentationAITests.run();
        Stage3IntegrationTests.run();
        ControlTests.run();
        ContextEngineTests.run();
        EventBusTests.run();
        MessageRouterTests.run();
        PersistentMemoryTests.run();
        KnowledgeGraphTests.run();
        ContextCompressorTests.run();
        ModelRouterTests.run();
        ConfidenceEngineTests.run();
        DecisionTrackerTests.run();
        ResourceAllocatorTests.run();
        SharedInfrastructureIntegrationTests.run();
        ObservationSourceTests.run();
        InterfaceRegistryTests.run();
        TextReaderTests.run();
        FieldRecognizerTests.run();
        ResourceReaderTests.run();
        QuestReaderTests.run();
        BuffReaderTests.run();
        StateReconstructorTests.run();
        ObservationVerifierTests.run();
        ObservationHistoryTests.run();
        ObservationIntegrationTests.run();
        StrategyComparerTests.run();
        FieldPerformanceTests.run();
        PollenTrackerTests.run();
        HoneyAnalysisTests.run();
        SessionEfficiencyTests.run();
        ResourcePlannerTests.run();
        QuestPrioritizerTests.run();
        FarmingSimulationTests.run();
        AdaptiveAdvisorTests.run();
        FarmingReportTests.run();
        AutomationInfrastructureTests.run();
        ManagerIntelligenceTests.run();
        OptimizationTests.run();
        IntegrationTests.run();
        FarmingIntegrationTests.run();
        V2CompletionTests.run();
        DirectiveCompletionTests.run();
        PhasePowerTests.run();
        SubsystemTests.run();
        UiBssTests.run();
        LootManagerTests.run();
        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
