package com.hiveminemobile;

import com.hiveminemobile.ai.modules.SecurityAI;
import com.hiveminemobile.ai.modules.SecurityAI.Finding;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/** JVM-only tests for Phase 027 SecurityAI. */
public final class SecurityAITests {
    private SecurityAITests() { }

    public static void run() {
        SecurityAI security = new SecurityAI();
        RunTests.check(security.getCapabilities().contains("audit.security"), "phase 027 exposes audit.security");

        List<Finding> clean = security.auditGrants(new HashSet<>(Arrays.asList("observe.frame", "analyze.state")));
        RunTests.check(clean.isEmpty(), "ordinary granted capabilities pass the audit");
        List<Finding> dirty = security.auditGrants(new HashSet<>(Arrays.asList("observe.frame", "input.tap")));
        RunTests.check(dirty.size() == 1 && "HARD_DENIED_GRANTED".equals(dirty.get(0).getCode()),
            "a hard-denied capability in the grant set is a finding");

        String raw = "contact pilot@example.com with token=abc123 card 4111111111111111";
        String cleaned = security.redact(raw);
        RunTests.check(cleaned.contains("[email]") && cleaned.contains("token=[redacted]") && cleaned.contains("[number]"),
            "e-mail, secret and card-like values are replaced");
        RunTests.check(!cleaned.contains("abc123") && !cleaned.contains("pilot@example.com"),
            "the original sensitive values do not survive redaction");
        RunTests.check(security.containsSensitive("password: hunter2") && !security.containsSensitive("field is Pine Tree"),
            "sensitive text is detected and ordinary text is not");
        RunTests.check(security.redact(null).isEmpty() && !security.containsSensitive(null),
            "missing text is handled without errors");
        RunTests.check(security.auditGrants(Collections.<String>emptySet()).isEmpty(), "an empty grant set is clean");
    }
}
