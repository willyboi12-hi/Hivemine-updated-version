package com.hiveminemobile;

import com.hiveminemobile.ai.modules.SessionAI;
import com.hiveminemobile.ai.modules.SessionAI.Outcome;
import com.hiveminemobile.ai.modules.SessionAI.Report;

/** JVM-only tests for Phase 023 SessionAI. */
public final class SessionAITests {
    private SessionAITests() { }

    public static void run() {
        long t0 = 1_800_000_000_000L;
        long minute = 60_000L;
        SessionAI sessions = new SessionAI();
        RunTests.check(sessions.getCapabilities().contains("analyze.session"), "phase 023 exposes analyze.session");

        sessions.start("farm-1", t0);
        boolean secondWhileRunning = false;
        try { sessions.start("farm-2", t0); } catch (IllegalArgumentException expected) { secondWhileRunning = true; }
        RunTests.check(secondWhileRunning, "only one session can run at a time");
        RunTests.check(sessions.end("farm-1", Outcome.COMPLETED, "all fields done", t0 + 10 * minute).getDurationMillis()
            == 10 * minute, "a session records its duration when it ends");

        sessions.start("farm-2", t0 + 20 * minute);
        sessions.end("farm-2", Outcome.ABORTED, "disconnected", t0 + 25 * minute);
        Report report = sessions.report();
        RunTests.check(report.getTotal() == 2 && report.getCompleted() == 1 && report.getAborted() == 1,
            "the report counts completed and aborted sessions");
        RunTests.check(report.getAverageMillis() == 450_000L && report.getRunning() == null,
            "the average covers closed sessions and nothing is reported running");

        boolean duplicate = false;
        try { sessions.start("farm-1", t0 + 40 * minute); } catch (IllegalArgumentException expected) { duplicate = true; }
        RunTests.check(duplicate, "a session id cannot be reused");
        boolean unknownEnd = false;
        try { sessions.end("nope", Outcome.COMPLETED, "", t0); } catch (IllegalArgumentException expected) { unknownEnd = true; }
        RunTests.check(unknownEnd, "ending an unknown session is rejected");

        sessions.start("farm-3", t0 + 60 * minute);
        boolean backwards = false;
        try { sessions.end("farm-3", Outcome.COMPLETED, "", t0 + 59 * minute); }
        catch (IllegalArgumentException expected) { backwards = true; }
        RunTests.check(backwards, "a session cannot end before it started");
        boolean running = sessions.report().getRunning() != null && "farm-3".equals(sessions.report().getRunning());
        RunTests.check(running, "the running session is reported by id");

        SessionAI bounded = new SessionAI(2);
        for (int i = 0; i < 3; i++) {
            bounded.start("run-" + i, t0 + i * 10 * minute);
            bounded.end("run-" + i, Outcome.COMPLETED, "", t0 + i * 10 * minute + minute);
        }
        RunTests.check(bounded.history().size() == 2 && "run-2".equals(bounded.history().get(1).getId()),
            "the history keeps only the newest closed sessions");
    }
}
