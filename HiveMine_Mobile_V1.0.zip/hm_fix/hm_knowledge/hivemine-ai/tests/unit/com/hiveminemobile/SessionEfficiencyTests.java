package com.hiveminemobile;

import com.hiveminemobile.ai.farming.SessionEfficiency;
import com.hiveminemobile.ai.farming.SessionEfficiency.Ranked;
import com.hiveminemobile.ai.farming.SessionEfficiency.Session;
import java.util.Arrays;
import java.util.List;

/** JVM-only tests for Phase 055 SessionEfficiency. */
public final class SessionEfficiencyTests {
    private SessionEfficiencyTests() { }

    public static void run() {
        SessionEfficiency efficiency = new SessionEfficiency();
        List<Ranked> ranked = efficiency.rank(Arrays.asList(
            new Session("steady", 60, 300, 0), new Session("waited", 60, 300, 30)));
        RunTests.check(ranked.get(0).getName().equals("waited") && Math.abs(ranked.get(0).getHoneyPerActiveMinute() - 10.0) < 1e-9,
            "phase 055: idle time is excluded, so a session that waited can still rank first on active time");
        RunTests.check(Math.abs(ranked.get(0).getIdleShare() - 0.5) < 1e-9,
            "phase 055: the idle share of each session is reported");
        RunTests.check(efficiency.rank(Arrays.asList(new Session("all-idle", 10, 0, 10))).get(0).getHoneyPerActiveMinute() == 0.0,
            "phase 055: a session with no active time has zero rate, not a division error");
        boolean bad = false;
        try { new Session("x", 10, 5, 11); } catch (IllegalArgumentException expected) { bad = true; }
        RunTests.check(bad, "phase 055: idle time cannot exceed the session length");
    }
}
