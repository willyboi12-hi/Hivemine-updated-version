package com.hiveminemobile;

import com.hiveminemobile.ai.shared.ConfidenceEngine;
import com.hiveminemobile.ai.shared.ContextEngine;
import com.hiveminemobile.ai.shared.DecisionTracker;
import com.hiveminemobile.ai.shared.EventBus;
import com.hiveminemobile.ai.shared.MessageRouter;
import java.util.Arrays;

/** JVM-only integration of the shared-infrastructure modules, phases 031–040 working together. */
public final class SharedInfrastructureIntegrationTests {
    private SharedInfrastructureIntegrationTests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        ContextEngine context = new ContextEngine();
        EventBus events = new EventBus(10);
        MessageRouter router = new MessageRouter();
        ConfidenceEngine confidence = new ConfidenceEngine(60_000L);
        DecisionTracker decisions = new DecisionTracker(60_000L);

        events.subscribe("observation", event -> context.publish("field.current", event.getPayload(), "vision",
            event.getAtMillis(), 60_000L));
        router.register("decision.", (type, body) -> decisions.open("farm", body, now));

        events.publish("obs-1", "observation", "Pine Tree", now);
        events.dispatch();
        RunTests.check(context.query("field.current", now).getValue().equals("Pine Tree"),
            "shared integration: an event updates the shared context");

        RunTests.check(router.route("decision.farm", "walk to Pine Tree") == MessageRouter.Result.ROUTED,
            "shared integration: a decision message is routed into the tracker");
        double score = confidence.combine(Arrays.asList(
            new ConfidenceEngine.Evidence("vision", 0.6, now), new ConfidenceEngine.Evidence("ocr", 0.6, now)), now);
        RunTests.check(ConfidenceEngine.shouldAct(score, 0.8) && !ConfidenceEngine.shouldAct(score, 0.9),
            "shared integration: two independent readings give confidence that gates the action");
        DecisionTracker.Decision open = decisions.snapshot().values().iterator().next();
        RunTests.check(open.getState() == DecisionTracker.State.PENDING,
            "shared integration: the routed decision waits for verification");
    }
}
