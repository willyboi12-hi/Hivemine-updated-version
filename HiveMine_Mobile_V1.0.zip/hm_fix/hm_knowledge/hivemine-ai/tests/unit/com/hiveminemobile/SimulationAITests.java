package com.hiveminemobile;

import com.hiveminemobile.ai.modules.SimulationAI;
import com.hiveminemobile.ai.modules.SimulationAI.Outcome;
import com.hiveminemobile.ai.modules.SimulationAI.Ranked;
import com.hiveminemobile.ai.modules.SimulationAI.Scenario;
import com.hiveminemobile.ai.modules.SimulationAI.Strategy;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** JVM-only tests for Phase 029 SimulationAI. */
public final class SimulationAITests {
    private SimulationAITests() { }

    public static void run() {
        SimulationAI simulation = new SimulationAI();
        RunTests.check(simulation.getCapabilities().contains("simulate.scenario"), "phase 029 exposes simulate.scenario");

        Strategy pollenFirst = new Strategy("pollen-first", 2.0, 10.0, 5.0);
        Strategy quick = new Strategy("quick", 1.0, 20.0, 0.0);
        Scenario calm = new Scenario("calm", 0.0, 5.0);
        Scenario busy = new Scenario("busy", 3.0, 5.0);

        Outcome calmOutcome = simulation.simulate(pollenFirst, calm);
        RunTests.check(Math.abs(calmOutcome.getUnitsPerHour() - 80.0) < 1e-9,
            "a calm scenario yields rate times cycle output, averaged over cycle plus downtime");
        Outcome busyOutcome = simulation.simulate(pollenFirst, busy);
        RunTests.check(Math.abs(busyOutcome.getUnitsPerHour() - 60.0) < 1e-9,
            "disruptions remove their share of the expected output");

        List<Ranked> ranked = simulation.compare(Arrays.asList(quick, pollenFirst), Arrays.asList(calm, busy));
        RunTests.check("pollen-first".equals(ranked.get(0).getStrategy())
                && Math.abs(ranked.get(0).getAverageUnitsPerHour() - 70.0) < 1e-9
                && Math.abs(ranked.get(1).getAverageUnitsPerHour() - 52.5) < 1e-9,
            "strategies are compared by their average output across scenarios");

        boolean zeroRate = false;
        try { new Strategy("x", 0.0, 10.0, 0.0); } catch (IllegalArgumentException expected) { zeroRate = true; }
        RunTests.check(zeroRate, "a strategy rate must be positive");
        boolean negativeDisruptions = false;
        try { new Scenario("x", -1.0, 1.0); } catch (IllegalArgumentException expected) { negativeDisruptions = true; }
        RunTests.check(negativeDisruptions, "disruptions cannot be negative");
        boolean tooLong = false;
        try { new Scenario("x", 1.0, 61.0); } catch (IllegalArgumentException expected) { tooLong = true; }
        RunTests.check(tooLong, "a disruption cannot lose more than an hour");
        boolean noScenarios = false;
        try { simulation.compare(Collections.singletonList(quick), Collections.<Scenario>emptyList()); }
        catch (IllegalArgumentException expected) { noScenarios = true; }
        RunTests.check(noScenarios, "a comparison needs at least one scenario");
    }
}
