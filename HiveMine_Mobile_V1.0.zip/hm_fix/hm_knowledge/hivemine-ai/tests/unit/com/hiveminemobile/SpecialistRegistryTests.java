package com.hiveminemobile;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIInterface;
import com.hiveminemobile.ai.specialist.RegistrationResult;
import com.hiveminemobile.ai.specialist.SpecialistMetadata;
import com.hiveminemobile.ai.specialist.SpecialistRegistry;
import com.hiveminemobile.ai.specialist.SpecialistStatus;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/** JVM-only validation for Phase 003 specialist registration. */
public final class SpecialistRegistryTests {
    private SpecialistRegistryTests() { }
    public static void run() {
        SpecialistRegistry registry = new SpecialistRegistry();
        Stub vision = new Stub("vision", set("observe.screen", "recognize.interface"));
        SpecialistMetadata visionMeta = metadata(vision, set("observe.screen", "recognize.interface"),
            Collections.<String>emptySet(), "1.0.0", null, SpecialistMetadata.ResourceClass.HEAVY);
        RegistrationResult first = registry.register(vision, visionMeta);
        RunTests.check(first.isAccepted(), "phase 003 accepts valid specialist metadata");
        RunTests.check(registry.size() == 1 && registry.getModule("vision") == vision,
            "registry stores specialist module and identity");
        RunTests.check(registry.getStatus("vision") == SpecialistStatus.REGISTERED,
            "new specialist starts in REGISTERED status");
        RunTests.check(registry.getMetadata("vision").getResourceClass() == SpecialistMetadata.ResourceClass.HEAVY,
            "registry retains declared resource class");
        RunTests.check(registry.findByCapability("observe.screen").contains("vision"),
            "capability lookup finds matching specialist");
        RunTests.check(!registry.findByCapability("farm.collect").contains("vision"),
            "capability lookup excludes non-matching specialist");
        RunTests.check(!registry.register(vision, visionMeta).isAccepted(),
            "registry rejects duplicate specialist IDs");
        RunTests.check(!registry.register(new Stub("bad id", set("observe")),
            metadata(new Stub("bad id", set("observe")), set("observe"), Collections.<String>emptySet(),
                "1.0.0", null, SpecialistMetadata.ResourceClass.LIGHT)).isAccepted(),
            "registry rejects malformed specialist identifiers");
        Stub incompatible = new Stub("future", set("analyze"));
        RunTests.check(!registry.register(incompatible, metadata(incompatible, set("analyze"),
            Collections.<String>emptySet(), "2.0.0", null, SpecialistMetadata.ResourceClass.STANDARD)).isAccepted(),
            "registry rejects specialists requiring a newer manager version");
        Stub self = new Stub("self", set("analyze"));
        RunTests.check(!registry.register(self, metadata(self, set("analyze"), set("self"),
            "1.0.0", null, SpecialistMetadata.ResourceClass.LIGHT)).isAccepted(),
            "registry rejects self-dependencies");
        RunTests.check(registry.updateStatus("vision", SpecialistStatus.AVAILABLE),
            "registry updates known specialist availability");
        RunTests.check(registry.findByCapability("observe.screen").contains("vision"),
            "available specialist remains discoverable by capability");
        registry.updateStatus("vision", SpecialistStatus.UNAVAILABLE);
        RunTests.check(!registry.findByCapability("observe.screen").contains("vision"),
            "unavailable specialist is excluded from capability discovery");
        RunTests.check(!registry.updateStatus("missing", SpecialistStatus.FAILED),
            "status update rejects unknown specialist IDs");
        RunTests.check(registry.getRegisteredAt("vision") > 0L,
            "registry records registration timestamp");
        RunTests.check(registry.unregister("vision") && registry.size() == 0,
            "registry supports specialist deregistration");
        RunTests.check(registry.getModule("vision") == null,
            "deregistered specialist is no longer discoverable");
    }
    private static SpecialistMetadata metadata(Stub stub, Set<String> caps, Set<String> deps,
            String min, String max, SpecialistMetadata.ResourceClass resource) {
        return new SpecialistMetadata(stub.getId(), stub.getVersion(), min, max, caps, deps, resource);
    }
    private static Set<String> set(String... values) {
        return new LinkedHashSet<>(Arrays.asList(values));
    }
    private static final class Stub implements AIInterface {
        private final String id; private final Set<String> capabilities;
        Stub(String id, Set<String> capabilities) { this.id = id; this.capabilities = capabilities; }
        public String getId() { return id; }
        public String getVersion() { return "1.0.0"; }
        public Set<String> getCapabilities() { return capabilities; }
        public void onInitialize(AIConfiguration config) { }
        public void onShutdown() { }
    }
}
