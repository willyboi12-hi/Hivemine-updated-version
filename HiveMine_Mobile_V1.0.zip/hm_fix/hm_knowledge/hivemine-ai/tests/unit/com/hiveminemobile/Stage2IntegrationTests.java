package com.hiveminemobile;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIException;
import com.hiveminemobile.ai.health.HealthMonitor;
import com.hiveminemobile.ai.manager.ManagerCoordinator;
import com.hiveminemobile.ai.memory.DecisionRecord;
import com.hiveminemobile.ai.modules.DiagnosticsAI;
import com.hiveminemobile.ai.modules.FarmingAI;
import com.hiveminemobile.ai.modules.LearningAI;
import com.hiveminemobile.ai.modules.PredictionAI;
import com.hiveminemobile.ai.modules.QuestAI;
import com.hiveminemobile.ai.modules.RecoveryAI;
import com.hiveminemobile.ai.modules.StateAI;
import com.hiveminemobile.ai.modules.VisionAI;
import com.hiveminemobile.ai.modules.InventoryAI;
import com.hiveminemobile.ai.modules.NavigationAI;
import com.hiveminemobile.ai.specialist.SpecialistRegistry;
import com.hiveminemobile.ai.specialist.SpecialistStatus;
import com.hiveminemobile.ai.state.GlobalStateManager;
import com.hiveminemobile.ai.state.StateDomain;
import com.hiveminemobile.ai.state.StateFact;
import com.hiveminemobile.ai.task.Priority;
import com.hiveminemobile.ai.task.Task;
import com.hiveminemobile.ai.task.TaskCategory;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** JVM-only integration: all ten Stage 2 specialists registered and driven through ManagerCoordinator. */
public final class Stage2IntegrationTests {
    private Stage2IntegrationTests() { }

    private static final List<String> IDS = Arrays.asList("vision", "state", "farming", "navigation", "inventory",
        "quest", "prediction", "recovery", "learning", "diagnostics");

    public static void run() {
        long now = 1_800_000_000_000L;
        ManagerCoordinator core = new ManagerCoordinator(AIConfiguration.builder().build());
        core.registerSpecialist(new VisionAI());
        core.registerSpecialist(new StateAI(), deps("vision"));
        core.registerSpecialist(new FarmingAI(), deps("state"));
        core.registerSpecialist(new NavigationAI(), deps("state"));
        core.registerSpecialist(new InventoryAI(), deps("vision"));
        core.registerSpecialist(new QuestAI(), deps("vision"));
        core.registerSpecialist(new PredictionAI(), deps("farming"));
        core.registerSpecialist(new RecoveryAI(), deps("state"));
        core.registerSpecialist(new LearningAI(), deps());
        core.registerSpecialist(new DiagnosticsAI(), deps());

        boolean started = true;
        try { core.start(); } catch (AIException failure) { started = false; }
        RunTests.check(started, "stage 2: all ten specialists start with their dependencies");
        if (!started) return;

        SpecialistRegistry catalog = core.getManager().getSpecialistRegistry();
        boolean allAvailable = true;
        for (String id : IDS) allAvailable &= catalog.getStatus(id) == SpecialistStatus.AVAILABLE;
        RunTests.check(allAvailable, "stage 2: every specialist is AVAILABLE after start");
        RunTests.check(catalog.findByCapability("analyze.farming").equals(Collections.singletonList("farming")),
            "stage 2: capabilities resolve to the module that offers them");

        for (String capability : Arrays.asList("observe.frame", "analyze.state", "analyze.farming", "analyze.location",
                "analyze.inventory", "analyze.quest", "analyze.forecast", "plan.recovery", "analyze.history",
                "analyze.diagnostics")) {
            core.getPolicy().grant(capability, now);
        }
        RunTests.check(core.checkHealth(now).getOverall() == HealthMonitor.Level.HEALTHY,
            "stage 2: a freshly started application reports healthy");

        Task farmingTask = core.createTask("Measure farming run", "analyze.farming", Priority.NORMAL,
            TaskCategory.ANALYSIS, now).getTask();
        RunTests.check(core.assignTask(farmingTask.getId(), now).isOk()
                && "farming".equals(core.getTasks().get(farmingTask.getId()).getAssignee()),
            "an analysis task is routed to the farming module");
        core.startTask(farmingTask.getId(), "farming", now);
        FarmingAI.Report report = new FarmingAI().analyze(Arrays.asList(
            new FarmingAI.Sample(0L, 0, 100L),
            new FarmingAI.Sample(60_000L, 50, 100L),
            new FarmingAI.Sample(120_000L, 100, 120L)));
        RunTests.check(Math.abs(report.getPollenPerMinute() - 50.0) < 1e-9,
            "the farming module measures the rate it is given");
        RunTests.check(core.completeTask(farmingTask.getId(), "farming", "Rate 50 percent per minute", now + 120_000L).isOk()
                && core.getMemory().successRate("analyze.farming").getAsDouble() == 1.0,
            "a completed analysis is recorded in manager memory");

        GlobalStateManager shared = new GlobalStateManager();
        shared.update(new StateFact("field.current", "Pine Tree", StateDomain.FIELD, "vision", now - 1_000L, 0.9), now);
        shared.update(new StateFact("pollen.percent", "72", StateDomain.POLLEN, "vision", now - 500L, 0.95), now);
        RunTests.check(new StateAI().interpret(shared, now).getReliability() == StateAI.Reliability.RELIABLE,
            "the state module reads what the vision module recorded");

        RecoveryAI.Plan plan = new RecoveryAI().plan(Collections.singletonList(
            new RecoveryAI.ErrorEvent(RecoveryAI.ErrorKind.GESTURE_REFUSED, now - 10_000L)), now);
        Task recoveryTask = core.createTask("Recovery plan", "plan.recovery", Priority.CRITICAL,
            TaskCategory.RECOVERY, now).getTask();
        RunTests.check(plan.getSeverity() == RecoveryAI.Severity.CRITICAL && plan.isRequiresApproval()
                && core.assignTask(recoveryTask.getId(), now).isOk(),
            "a critical recovery plan is routed through the manager and still needs approval");
        core.startTask(recoveryTask.getId(), "recovery", now);
        RunTests.check(core.completeTask(recoveryTask.getId(), "recovery", plan.getSummary(), now).isOk(),
            "the recovery module reports its plan back to the manager");

        List<DiagnosticsAI.Diagnostic> diagnosis = new DiagnosticsAI().diagnose(core.checkHealth(now),
            core.getManager().getErrorHandler().getHistory(),
            core.getBus().getAcceptedCount(), core.getBus().getRejectedCount(), 0);
        RunTests.check(diagnosis.size() == 1 && "ALL_CLEAR".equals(diagnosis.get(0).getCode()),
            "diagnostics report all clear for a healthy application");

        List<DecisionRecord> history = core.getMemory().recent(50);
        RunTests.check(new LearningAI().learn(history).isEmpty(),
            "learning waits for enough evidence before it draws conclusions");

        core.shutdown();
        RunTests.check(catalog.getStatus("farming") == SpecialistStatus.UNAVAILABLE,
            "shutdown marks specialists unavailable");
    }

    private static Set<String> deps(String... ids) {
        return new LinkedHashSet<>(Arrays.asList(ids));
    }
}
