package com.hiveminemobile;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIException;
import com.hiveminemobile.ai.AIInterface;
import com.hiveminemobile.ai.manager.ManagerCoordinator;
import com.hiveminemobile.ai.modules.AnalyticsAI;
import com.hiveminemobile.ai.modules.CompatibilityAI;
import com.hiveminemobile.ai.modules.ConfigurationAI;
import com.hiveminemobile.ai.modules.DocumentationAI;
import com.hiveminemobile.ai.modules.NotificationAI;
import com.hiveminemobile.ai.modules.PerformanceAI;
import com.hiveminemobile.ai.modules.SecurityAI;
import com.hiveminemobile.ai.modules.SessionAI;
import com.hiveminemobile.ai.modules.SimulationAI;
import com.hiveminemobile.ai.modules.StrategyAI;
import com.hiveminemobile.ai.specialist.SpecialistRegistry;
import com.hiveminemobile.ai.specialist.SpecialistStatus;
import com.hiveminemobile.ai.task.Priority;
import com.hiveminemobile.ai.task.Task;
import com.hiveminemobile.ai.task.TaskCategory;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** JVM-only integration: the Stage 3 specialists registered and driven through ManagerCoordinator. */
public final class Stage3IntegrationTests {
    private Stage3IntegrationTests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        ManagerCoordinator core = new ManagerCoordinator(AIConfiguration.builder().build());
        AnalyticsAI analytics = new AnalyticsAI();
        StrategyAI strategy = new StrategyAI();
        SimulationAI simulation = new SimulationAI();
        PerformanceAI performance = new PerformanceAI();
        ConfigurationAI configuration = new ConfigurationAI();
        SessionAI sessions = new SessionAI();
        CompatibilityAI compatibility = new CompatibilityAI();
        NotificationAI notifications = new NotificationAI();
        SecurityAI security = new SecurityAI();
        DocumentationAI documentation = new DocumentationAI();
        core.registerSpecialist(analytics);
        core.registerSpecialist(strategy, deps("analytics"));
        core.registerSpecialist(simulation, deps("strategy"));
        core.registerSpecialist(performance);
        core.registerSpecialist(configuration);
        core.registerSpecialist(sessions);
        core.registerSpecialist(compatibility);
        core.registerSpecialist(notifications);
        core.registerSpecialist(security);
        core.registerSpecialist(documentation);

        boolean started = true;
        try { core.start(); } catch (AIException failure) { started = false; }
        RunTests.check(started, "stage 3: all ten specialists start with their dependencies");
        if (!started) return;

        SpecialistRegistry catalog = core.getManager().getSpecialistRegistry();
        boolean allAvailable = true;
        for (String id : Arrays.asList("analytics", "strategy", "simulation", "performance", "configuration",
                "session", "compatibility", "notification", "security", "documentation")) {
            allAvailable &= catalog.getStatus(id) == SpecialistStatus.AVAILABLE;
        }
        RunTests.check(allAvailable, "stage 3: every specialist is AVAILABLE after start");

        for (String capability : Arrays.asList("analyze.statistics", "analyze.strategy", "simulate.scenario",
                "analyze.performance", "analyze.configuration", "analyze.session", "analyze.compatibility",
                "report.notify", "audit.security", "document.report")) {
            core.getPolicy().grant(capability, now);
        }
        RunTests.check(security.auditGrants(core.getPolicy().getGranted()).isEmpty(),
            "stage 3: the security audit of granted capabilities is clean");

        Task rank = core.createTask("Rank farming strategies", "analyze.strategy", Priority.NORMAL,
            TaskCategory.ANALYSIS, now).getTask();
        RunTests.check(core.assignTask(rank.getId(), now).isOk() && "strategy".equals(core.getTasks().get(rank.getId()).getAssignee()),
            "a strategy ranking task is routed to the strategy module");
        core.startTask(rank.getId(), "strategy", now);
        Map<String, Double> yield = new LinkedHashMap<>();
        yield.put("yield", 0.9);
        yield.put("safety", 0.6);
        Map<String, Double> safer = new LinkedHashMap<>();
        safer.put("yield", 0.5);
        safer.put("safety", 0.9);
        List<StrategyAI.Scored> ranked = strategy.rank(
            Arrays.asList(new StrategyAI.Criterion("yield", 2.0), new StrategyAI.Criterion("safety", 1.0)),
            Arrays.asList(new StrategyAI.Option("yield-first", yield), new StrategyAI.Option("safer", safer)));
        RunTests.check("yield-first".equals(ranked.get(0).getName()), "the module ranks options by weighted score");
        RunTests.check(core.completeTask(rank.getId(), "strategy", "Best: " + ranked.get(0).getName(), now + 1_000L).isOk()
                && core.getMemory().successRate("analyze.strategy").getAsDouble() == 1.0,
            "a completed ranking is recorded in manager memory");

        List<SimulationAI.Ranked> compared = simulation.compare(
            Collections.singletonList(new SimulationAI.Strategy("pollen-first", 2.0, 10.0, 5.0)),
            Collections.singletonList(new SimulationAI.Scenario("calm", 0.0, 5.0)));
        RunTests.check(compared.get(0).getAverageUnitsPerHour() > 0.0, "the simulation module compares strategies");

        RunTests.check(notifications.notify(NotificationAI.Level.WARNING, "stuck", "Field not recognised", now)
                == NotificationAI.Decision.DELIVERED
            && notifications.notify(NotificationAI.Level.WARNING, "stuck", "Field not recognised", now + 1_000L)
                == NotificationAI.Decision.DUPLICATE,
            "notifications are delivered once and repeats are suppressed");

        sessions.start("run-1", now);
        RunTests.check(sessions.end("run-1", SessionAI.Outcome.COMPLETED, "done", now + 60_000L).getDurationMillis() == 60_000L,
            "a session is tracked from start to end");

        RunTests.check(configuration.validate(Collections.singletonMap("auto-convert", "true"),
                Collections.singletonList(ConfigurationAI.Rule.bool("auto-convert"))).isEmpty(),
            "configuration validates against its schema");
        RunTests.check(performance.analyze(Collections.singletonList(new PerformanceAI.Sample(now, 40.0, 500L, 3.0)))
                .getFindings().get(0).equals("Within limits"),
            "performance samples inside the limits report no findings");
        RunTests.check(CompatibilityAI.isCompatible(compatibility.check(
                new CompatibilityAI.Device(30, 4096, Collections.<String>emptySet(), Collections.<String>emptySet()),
                new CompatibilityAI.Requirements(26, 2048, Collections.<String>emptySet(), Collections.<String>emptySet()))),
            "a device meeting the requirements is compatible");

        List<AIInterface> modules = Arrays.<AIInterface>asList(analytics, strategy, simulation, performance,
            configuration, sessions, compatibility, notifications, security, documentation);
        String report = documentation.buildReport("HiveMine AI", documentation.describe(modules),
            Collections.singletonMap("030", "done"));
        RunTests.check(report.contains("`strategy`") && report.contains("analyze.strategy") && report.contains("- 030: done"),
            "the documentation module describes the registered modules");

        core.shutdown();
        RunTests.check(catalog.getStatus("strategy") == SpecialistStatus.UNAVAILABLE,
            "shutdown marks the specialists unavailable");
    }

    private static Set<String> deps(String... ids) {
        return new LinkedHashSet<>(Arrays.asList(ids));
    }
}
