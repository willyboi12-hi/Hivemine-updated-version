package com.hiveminemobile;

import com.hiveminemobile.ai.modules.StateAI;
import com.hiveminemobile.ai.state.GlobalStateManager;
import com.hiveminemobile.ai.state.StateDomain;
import com.hiveminemobile.ai.state.StateFact;

/** JVM-only tests for Phase 012 StateAI. */
public final class StateAITests {
    private StateAITests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        StateAI ai = new StateAI();
        RunTests.check(ai.getCapabilities().contains("analyze.state"), "phase 012 exposes analyze.state");

        GlobalStateManager state = new GlobalStateManager();
        state.update(new StateFact("field.current", "Pine Tree", StateDomain.FIELD, "vision", now - 1_000L, 0.9), now);
        state.update(new StateFact("pollen.percent", "72%", StateDomain.POLLEN, "vision", now - 500L, 0.95), now);
        StateAI.View view = ai.interpret(state, now);
        RunTests.check("Pine Tree".equals(view.getField()) && view.getPollenPercent() == 72,
            "fresh, confident values are read and the percent sign is parsed");
        RunTests.check(view.getReliability() == StateAI.Reliability.RELIABLE,
            "field and pollen both usable with no conflicts is reliable");
        RunTests.check(view.getUnusable().size() == 1 && view.getUnusable().get(0).startsWith("quest.active"),
            "a value that was never observed is listed as unusable, not guessed");

        GlobalStateManager lowConfidence = new GlobalStateManager();
        lowConfidence.update(new StateFact("field.current", "Pine Tree", StateDomain.FIELD, "vision", now, 0.3), now);
        StateAI.View guarded = ai.interpret(lowConfidence, now);
        RunTests.check(guarded.getField() == null && guarded.getUnusable().get(0).contains("confidence below"),
            "a low-confidence value is not used");

        StateAI.View stale = ai.interpret(state, now + 200_000L);
        RunTests.check(stale.getReliability() == StateAI.Reliability.UNRELIABLE
                && stale.getUnusable().stream().anyMatch(reason -> reason.contains("stale")),
            "values older than the freshness limit make the view unreliable");

        GlobalStateManager badPollen = new GlobalStateManager();
        badPollen.update(new StateFact("pollen.percent", "lots", StateDomain.POLLEN, "vision", now, 0.9), now);
        StateAI.View rejected = ai.interpret(badPollen, now);
        RunTests.check(rejected.getPollenPercent() == null
                && rejected.getUnusable().stream().anyMatch(reason -> reason.contains("not a percentage")),
            "a pollen value that is not a percentage is rejected");

        GlobalStateManager conflicted = new GlobalStateManager();
        conflicted.update(new StateFact("field.current", "Pine Tree", StateDomain.FIELD, "vision", now - 1_000L, 0.9), now);
        conflicted.update(new StateFact("field.current", "Sunflower Field", StateDomain.FIELD, "vision",
            now + 100L, 0.99), now + 100L);
        StateAI.View contested = ai.interpret(conflicted, now + 100L);
        RunTests.check("Sunflower Field".equals(contested.getField()) && contested.getRecentConflicts() == 1,
            "a conflict is counted and the newer, more confident value is used");
        RunTests.check(contested.getReliability() == StateAI.Reliability.PARTIAL,
            "a recent conflict downgrades reliability");

        boolean badThreshold = false;
        try { new StateAI(1.5, 1_000L); } catch (IllegalArgumentException expected) { badThreshold = true; }
        RunTests.check(badThreshold, "a confidence threshold above 1 is rejected");
    }
}
