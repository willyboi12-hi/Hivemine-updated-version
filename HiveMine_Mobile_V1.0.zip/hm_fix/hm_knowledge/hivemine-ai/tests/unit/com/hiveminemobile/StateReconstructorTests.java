package com.hiveminemobile;

import com.hiveminemobile.ai.observation.Observation;
import com.hiveminemobile.ai.observation.StateReconstructor;
import com.hiveminemobile.ai.shared.ConfidenceEngine;
import java.util.Arrays;
import java.util.Map;

/** JVM-only tests for Phase 048 StateReconstructor. */
public final class StateReconstructorTests {
    private StateReconstructorTests() { }

    public static void run() {
        long now = 1_800_000_000_000L;
        StateReconstructor reconstructor = new StateReconstructor(new ConfidenceEngine(60_000L), 0.7);
        Map<String, StateReconstructor.Estimate> state = reconstructor.reconstruct(Arrays.asList(
            new Observation("field", "Pine Tree", "vision", now, 0.5),
            new Observation("field", "Pine Tree", "ocr", now, 0.5),
            new Observation("field", "Sunflower", "vision", now, 0.3),
            new Observation("pollen", "72", "vision", now, 0.4)), now);

        RunTests.check("Pine Tree".equals(state.get("field").getValue()) && state.get("field").getEvidence() == 2,
            "phase 048: independent agreeing sources reach the threshold and win");
        RunTests.check(Math.abs(state.get("field").getConfidence() - 0.75) < 1e-9,
            "phase 048: the combined confidence is reported");
        RunTests.check(state.get("pollen").getValue() == null && Math.abs(state.get("pollen").getConfidence() - 0.4) < 1e-9,
            "phase 048: a value below the threshold is unknown, with the confidence that was reached");
        boolean badThreshold = false;
        try { new StateReconstructor(new ConfidenceEngine(1L), 2.0); } catch (IllegalArgumentException expected) { badThreshold = true; }
        RunTests.check(badThreshold, "phase 048: the threshold must be between 0 and 1");
    }
}
