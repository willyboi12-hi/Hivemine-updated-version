package com.hiveminemobile;

import com.hiveminemobile.ai.modules.StrategyAI;
import com.hiveminemobile.ai.modules.StrategyAI.Criterion;
import com.hiveminemobile.ai.modules.StrategyAI.Option;
import com.hiveminemobile.ai.modules.StrategyAI.Scored;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** JVM-only tests for Phase 024 StrategyAI. */
public final class StrategyAITests {
    private StrategyAITests() { }

    public static void run() {
        StrategyAI strategy = new StrategyAI();
        RunTests.check(strategy.getCapabilities().contains("analyze.strategy"), "phase 024 exposes analyze.strategy");
        List<Criterion> criteria = Arrays.asList(new Criterion("yield", 2.0), new Criterion("safety", 1.0));

        Map<String, Double> pollen = new HashMap<>();
        pollen.put("yield", 0.9);
        pollen.put("safety", 0.5);
        Map<String, Double> safe = new HashMap<>();
        safe.put("yield", 0.4);
        safe.put("safety", 0.9);
        Map<String, Double> partial = Collections.singletonMap("yield", 0.6);
        List<Scored> ranked = strategy.rank(criteria, Arrays.asList(
            new Option("safe-first", safe), new Option("mixed", partial), new Option("pollen-first", pollen)));

        RunTests.check("pollen-first".equals(ranked.get(0).getName()) && Math.abs(ranked.get(0).getScore() - 2.3 / 3.0) < 1e-9,
            "options are ranked by their weighted score");
        RunTests.check("safe-first".equals(ranked.get(1).getName()) && "mixed".equals(ranked.get(2).getName()),
            "the remaining options follow in score order");
        RunTests.check(ranked.get(2).getMissingCriteria() == 1 && ranked.get(2).getScore() < 0.5,
            "a missing score counts as zero and the gap is reported");

        boolean noCriteria = false;
        try { strategy.rank(Collections.<Criterion>emptyList(), Collections.<Option>emptyList()); }
        catch (IllegalArgumentException expected) { noCriteria = true; }
        RunTests.check(noCriteria, "ranking needs at least one criterion");
        boolean zeroWeight = false;
        try { new Criterion("yield", 0.0); } catch (IllegalArgumentException expected) { zeroWeight = true; }
        RunTests.check(zeroWeight, "a criterion weight must be positive");
        boolean badScore = false;
        try { new Option("x", Collections.singletonMap("yield", 1.5)); } catch (IllegalArgumentException expected) { badScore = true; }
        RunTests.check(badScore, "scores must be between 0 and 1");
    }
}
