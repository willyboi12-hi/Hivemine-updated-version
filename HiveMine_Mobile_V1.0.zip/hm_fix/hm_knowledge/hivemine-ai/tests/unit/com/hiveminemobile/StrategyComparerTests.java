package com.hiveminemobile;

import com.hiveminemobile.ai.farming.StrategyComparer;
import com.hiveminemobile.ai.farming.StrategyComparer.Option;
import java.util.Arrays;

/** JVM-only tests for Phase 051 StrategyComparer. */
public final class StrategyComparerTests {
    private StrategyComparerTests() { }

    public static void run() {
        StrategyComparer comparer = new StrategyComparer();
        RunTests.check(comparer.rank(Arrays.asList(new Option("A", 2.0, 0.5))).get(0).getHoneyPerHour() == 60.0,
            "phase 051: honey per hour is pollen rate times 60 times honey per pollen");
        java.util.List<StrategyComparer.Ranked> ranked = comparer.rank(Arrays.asList(
            new Option("C", 2.0, 0.5), new Option("A", 2.0, 0.5), new Option("B", 1.5, 1.0)));
        RunTests.check(ranked.get(0).getName().equals("B") && ranked.get(1).getName().equals("A")
                && ranked.get(2).getName().equals("C"),
            "phase 051: options are ranked by honey per hour, with name breaking ties");
        boolean bad = false;
        try { new Option("x", -1.0, 1.0); } catch (IllegalArgumentException expected) { bad = true; }
        RunTests.check(bad, "phase 051: a negative pollen rate is rejected");
    }
}
