package com.hiveminemobile;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIInterface;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/** A minimal specialist used by the Stage 1 tests. It only declares identity and capabilities. */
public final class StubAI implements AIInterface {
    private final String id;
    private final Set<String> capabilities;

    public StubAI(String id, String... capabilities) {
        this.id = id;
        this.capabilities = Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(capabilities)));
    }

    @Override public String getId() { return id; }
    @Override public String getVersion() { return "1.0.0"; }
    @Override public Set<String> getCapabilities() { return capabilities; }
    @Override public void onInitialize(AIConfiguration configuration) { }
    @Override public void onShutdown() { }
}
