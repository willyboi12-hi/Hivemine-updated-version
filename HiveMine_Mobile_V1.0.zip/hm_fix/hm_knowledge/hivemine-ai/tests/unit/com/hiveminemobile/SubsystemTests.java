package com.hiveminemobile;

import com.hiveminemobile.ai.subsystems.Subsystem;
import com.hiveminemobile.ai.subsystems.SubsystemRegistry;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public final class SubsystemTests {
    private SubsystemTests() {}
    public static void run() {
        RunTests.check(SubsystemRegistry.count() == 250, "250 subsystems registered");
        HashSet<Integer> phases = new HashSet<Integer>();
        HashSet<String> names = new HashSet<String>();
        for (Subsystem s : SubsystemRegistry.all()) {
            phases.add(s.phaseNumber());
            names.add(s.name());
            Map<String, Double> out = s.evaluate(new HashMap<String, Double>());
            RunTests.check(out != null && !out.isEmpty(), "subsystem " + s.phaseNumber() + " evaluates");
        }
        RunTests.check(phases.size() == 250, "250 unique phase numbers");
        RunTests.check(names.size() == 250, "250 unique subsystem names");
        // Different phases produce different scores for same input
        HashMap<String, Double> in = new HashMap<String, Double>();
        in.put("confidence", 0.5);
        in.put("pollenRate", 0.4);
        in.put("stability", 0.8);
        double a = score(SubsystemRegistry.get(5).evaluate(in));
        double b = score(SubsystemRegistry.get(55).evaluate(in));
        double c = score(SubsystemRegistry.get(200).evaluate(in));
        RunTests.check(a != b || b != c || a != c, "different subsystems differ");
        Map<String, Double> agg = SubsystemRegistry.evaluateAll(in);
        RunTests.check(agg.get("count") == 250.0, "aggregate count 250");
    }
    private static double score(Map<String, Double> m) {
        double s = 0;
        for (Map.Entry<String, Double> e : m.entrySet()) {
            if ("phase".equals(e.getKey())) continue;
            s += e.getValue() == null ? 0 : e.getValue();
        }
        return s;
    }
}
