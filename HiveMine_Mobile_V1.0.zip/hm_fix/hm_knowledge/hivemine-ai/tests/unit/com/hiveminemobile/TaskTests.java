package com.hiveminemobile;

import com.hiveminemobile.ai.specialist.SpecialistMetadata;
import com.hiveminemobile.ai.specialist.SpecialistRegistry;
import com.hiveminemobile.ai.specialist.SpecialistStatus;
import com.hiveminemobile.ai.task.AssignmentGate;
import com.hiveminemobile.ai.task.Priority;
import com.hiveminemobile.ai.task.Task;
import com.hiveminemobile.ai.task.TaskCategory;
import com.hiveminemobile.ai.task.TaskManager;
import com.hiveminemobile.ai.task.TaskManager.Outcome;
import com.hiveminemobile.ai.task.TaskManager.Result;
import com.hiveminemobile.ai.task.TaskStatus;
import java.util.Collections;

/** JVM-only tests for Phase 006 global task management. */
public final class TaskTests {
    private TaskTests() { }

    /** Three specialists: two offer "observe" (vision, vision2), one offers "analyze" (state). */
    static SpecialistRegistry registry() {
        SpecialistRegistry registry = new SpecialistRegistry();
        addSpecialist(registry, new StubAI("vision", "observe"));
        addSpecialist(registry, new StubAI("vision2", "observe"));
        addSpecialist(registry, new StubAI("state", "analyze"));
        return registry;
    }

    static void addSpecialist(SpecialistRegistry registry, StubAI module) {
        registry.register(module, SpecialistMetadata.from(module, Collections.<String>emptySet()));
        registry.updateStatus(module.getId(), SpecialistStatus.AVAILABLE);
    }

    public static void run() {
        long now = 1_800_000_000_000L;
        SpecialistRegistry registry = registry();
        TaskManager tasks = new TaskManager(registry, AssignmentGate.ALLOW_ALL, 2, 4);

        Result created = tasks.create("Read the pollen bag", "observe", Priority.NORMAL, TaskCategory.OBSERVATION, now);
        RunTests.check(created.isOk() && created.getTask().getStatus() == TaskStatus.PENDING,
            "phase 006 creates a pending task");
        String readId = created.getTask().getId();
        RunTests.check(tasks.create("  ", "observe", Priority.NORMAL, TaskCategory.OBSERVATION, now).getOutcome()
            == Outcome.INVALID, "blank title is rejected");
        RunTests.check(tasks.create("Bad", "Bad Cap", Priority.NORMAL, TaskCategory.OBSERVATION, now).getOutcome()
            == Outcome.INVALID, "invalid capability is rejected");
        RunTests.check(tasks.create("No priority", "observe", null, TaskCategory.OBSERVATION, now).getOutcome()
            == Outcome.INVALID, "priority is required");

        Result assigned = tasks.assign(readId, now);
        RunTests.check(assigned.isOk() && "vision".equals(assigned.getTask().getAssignee())
                && assigned.getTask().getStatus() == TaskStatus.ASSIGNED,
            "assigns to the first available specialist that offers the capability");
        String secondId = tasks.create("Read the second bag", "observe", Priority.NORMAL,
            TaskCategory.OBSERVATION, now).getTask().getId();
        RunTests.check("vision2".equals(tasks.assign(secondId, now).getTask().getAssignee()),
            "assignment balances load toward the least busy specialist");
        String navId = tasks.create("Plan a route", "navigate", Priority.LOW,
            TaskCategory.MAINTENANCE, now).getTask().getId();
        RunTests.check(tasks.assign(navId, now).getOutcome() == Outcome.NO_SPECIALIST,
            "no specialist offering the capability is reported");

        registry.updateStatus("vision2", SpecialistStatus.UNAVAILABLE);
        String thirdId = tasks.create("Read the third bag", "observe", Priority.NORMAL,
            TaskCategory.OBSERVATION, now).getTask().getId();
        RunTests.check("vision".equals(tasks.assign(thirdId, now).getTask().getAssignee()),
            "unavailable specialists are not assigned work");
        RunTests.check(tasks.create("One more", "observe", Priority.NORMAL, TaskCategory.OBSERVATION, now)
            .getOutcome() == Outcome.QUEUE_FULL, "the open-task limit refuses new work");
        registry.updateStatus("vision2", SpecialistStatus.AVAILABLE);

        RunTests.check(tasks.start(readId, "vision2", now).getOutcome() == Outcome.NOT_ASSIGNEE,
            "only the assigned specialist can start a task");
        RunTests.check(tasks.start(readId, "vision", now).isOk()
                && tasks.get(readId).getStatus() == TaskStatus.IN_PROGRESS,
            "the assignee starts the task");
        RunTests.check(tasks.complete(readId, "vision", "Pollen read at 72%", now + 500).isOk(),
            "the assignee completes an in-progress task");
        Task done = tasks.get(readId);
        RunTests.check(done.getStatus() == TaskStatus.COMPLETED && "Pollen read at 72%".equals(done.getNote()),
            "a completed task keeps its summary");
        RunTests.check(tasks.complete(readId, "vision", "again", now).getOutcome() == Outcome.WRONG_STATE,
            "completed tasks cannot be completed again");
        RunTests.check(tasks.assign(readId, now).getOutcome() == Outcome.WRONG_STATE,
            "completed tasks cannot be reassigned");

        Result retry = tasks.fail(secondId, "vision2", "camera frame unreadable", now);
        RunTests.check(retry.isOk() && retry.getTask().getStatus() == TaskStatus.PENDING
                && retry.getTask().getAssignee() == null && retry.getTask().getAttempts() == 1,
            "a failed attempt returns the task to the queue while retries remain");
        Result reassigned = tasks.assign(secondId, now);
        RunTests.check(reassigned.isOk() && reassigned.getTask().getAttempts() == 2,
            "a retry is assigned again and counts as another attempt");
        Result exhausted = tasks.fail(secondId, reassigned.getTask().getAssignee(), "still unreadable", now);
        RunTests.check(exhausted.getTask().getStatus() == TaskStatus.FAILED,
            "a task fails permanently after its last attempt");

        TaskManager gated = new TaskManager(registry, new AssignmentGate() {
            @Override public String refuse(Task task, String specialistId) {
                return "state".equals(specialistId) ? "analysis paused" : null;
            }
        }, 2, 10);
        Result refused = gated.assign(gated.create("Check the field", "analyze", Priority.HIGH,
            TaskCategory.ANALYSIS, now).getTask().getId(), now);
        RunTests.check(refused.getOutcome() == Outcome.REFUSED && "analysis paused".equals(refused.getMessage()),
            "a gate refusal blocks assignment and keeps the reason");

        Result cancelled = tasks.cancel(thirdId, now);
        RunTests.check(cancelled.isOk() && cancelled.getTask().getStatus() == TaskStatus.CANCELLED,
            "open tasks can be cancelled");
        RunTests.check(tasks.cancel(thirdId, now).getOutcome() == Outcome.WRONG_STATE,
            "closed tasks cannot be cancelled again");
        RunTests.check(tasks.loadOf("vision") == 0, "cancelled work frees the specialist's load");
        RunTests.check(tasks.list(TaskStatus.COMPLETED).size() == 1 && tasks.list(null).size() == 4,
            "task list filters by status and returns everything when unfiltered");
        RunTests.check(tasks.get("task-999") == null && tasks.get(null) == null,
            "unknown task ids return nothing");
        RunTests.check(tasks.assign("task-999", now).getOutcome() == Outcome.NOT_FOUND,
            "assigning an unknown task reports not found");
    }
}
