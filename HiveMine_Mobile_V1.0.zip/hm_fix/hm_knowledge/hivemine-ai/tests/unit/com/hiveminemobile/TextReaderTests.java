package com.hiveminemobile;

import com.hiveminemobile.ai.modules.VisionAI;
import com.hiveminemobile.ai.observation.TextReader;
import com.hiveminemobile.ai.observation.TextReader.OcrText;

/** JVM-only tests for Phase 043 TextReader. */
public final class TextReaderTests {
    private TextReaderTests() { }

    public static void run() {
        RunTests.check(TextReader.parseCount("1,234") == 1234L && TextReader.parseCount("1.2K") == 1200L
                && TextReader.parseCount("3M") == 3_000_000L && TextReader.parseCount("12b") == 12_000_000_000L,
            "phase 043: counts with separators and K, M, B suffixes are parsed");
        RunTests.check(TextReader.parseCount("abc") == null && TextReader.parseCount("1.2.3") == null && TextReader.parseCount(null) == null,
            "phase 043: text that is not a count is rejected");
        RunTests.check(TextReader.parsePercent("72%") == 72 && TextReader.parsePercent("72") == 72,
            "phase 043: percentages with or without the sign are parsed");
        RunTests.check(TextReader.parsePercent("150") == null, "phase 043: percentages above 100 are rejected");
        int[] fraction = TextReader.parseFraction("45/100");
        RunTests.check(fraction != null && fraction[0] == 45 && fraction[1] == 100,
            "phase 043: fractions are parsed");
        RunTests.check(TextReader.parseFraction("101/100") == null && TextReader.parseFraction("5/0") == null,
            "phase 043: fractions above their denominator or with zero denominators are rejected");
        RunTests.check(TextReader.parseDurationMillis("3:20") == 200_000L && TextReader.parseDurationMillis("1:00:00") == 3_600_000L,
            "phase 043: durations in minutes:seconds and hours:minutes:seconds are parsed");
        RunTests.check(TextReader.parseDurationMillis("3:75") == null && TextReader.parseDurationMillis("1:2") == null,
            "phase 043: durations with seconds of 60 or more, or one-digit seconds, are rejected");

        TextReader confident = new TextReader((frame, region) -> new OcrText("  Pine Tre  ", 0.9), 0.8);
        RunTests.check("Pine Tre".equals(confident.readText(null, null)),
            "phase 043: confident OCR text is returned trimmed");
        TextReader unsure = new TextReader((frame, region) -> new OcrText("Pine Tre", 0.3), 0.8);
        RunTests.check(unsure.readText(null, null) == null,
            "phase 043: OCR text below the confidence bar is withheld");
        TextReader broken = new TextReader((frame, region) -> { throw new IllegalStateException("engine missing"); }, 0.5);
        RunTests.check(broken.readText(null, null) == null,
            "phase 043: a failing OCR engine yields no text rather than an error");
    }
}
