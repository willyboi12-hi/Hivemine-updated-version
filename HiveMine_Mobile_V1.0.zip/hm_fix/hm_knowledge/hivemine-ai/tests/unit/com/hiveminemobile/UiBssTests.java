package com.hiveminemobile;

import com.hiveminemobile.ai.bss.BssFields;
import com.hiveminemobile.ai.bss.BssKnowledgeAssistant;
import com.hiveminemobile.ai.loot.CraftMaterial;
import com.hiveminemobile.ai.loot.MaterialKnowledge;
import com.hiveminemobile.ai.bss.BssIntentParser;
import com.hiveminemobile.ai.bss.BssMacroSettings;
import com.hiveminemobile.ai.bss.BssPlanBuilder;
import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.ui.nav.NavSection;
import com.hiveminemobile.ai.ui.nav.UiController;
import com.hiveminemobile.ai.ui.screens.ScreenContent;

public final class UiBssTests {
    private UiBssTests() {}

    static final class FakePort implements MacroPort {
        boolean running;
        int starts, stops;
        @Override public void start() { starts++; running = true; }
        @Override public void stop() { stops++; running = false; }
        @Override public void recover() { running = false; }
        @Override public MacroStatus readStatus() { return MacroStatus.connected(running, "fake"); }
    }

    public static void run() {
        RunTests.check(BssFields.isKnown("Pine Tree"), "bss pine known");
        RunTests.check("Sunflower".equals(BssFields.canonical("sunflower")), "bss canonical");
        RunTests.check(BssFields.matchesColor("Spider", "white"), "spider is white field");
        RunTests.check(BssFields.matchesColor("Pine Tree", "blue"), "pine tree is blue field");
        RunTests.check(BssFields.matchesColor("Pepper", "red"), "pepper is red field");
        RunTests.check(BssFields.colorOf("Mountain Top") == BssFields.Color.MIXED, "mountain top is mixed");

        BssKnowledgeAssistant knowledge = new BssKnowledgeAssistant();
        RunTests.check(knowledge.answer("What field should I farm for white pollen?").contains("white-family"), "knowledge knows white fields");
        RunTests.check(knowledge.answer("How do I get glue?").contains("50 Gumdrops"), "knowledge knows glue recipe");
        RunTests.check(knowledge.answer("Where do gumdrops come from?").contains("not a single-field material"), "knowledge does not invent gumdrop field");

        MaterialKnowledge materials = new MaterialKnowledge();
        RunTests.check(materials.parseMaterial("I need glue") == CraftMaterial.GLUE, "material parser glue");
        RunTests.check("Stump".equals(materials.planFor(CraftMaterial.GLUE).primaryField), "glue plan uses direct-drop field instead of spider-only claim");
        RunTests.check(materials.planFor(CraftMaterial.GUMDROPS).notes.get(0).contains("many sources"), "gumdrop plan is source-aware");

        BssIntentParser parser = new BssIntentParser();
        BssIntentParser.Intent in = parser.parse("Farm Pine Tree, prioritize quests, convert when bag is full");
        RunTests.check("Pine Tree".equals(in.field), "intent field pine");
        RunTests.check(in.enableQuestSmart && in.convertWhenFull, "intent quest+convert");

        BssIntentParser.Intent negative = parser.parse("Don't farm Pine Tree and don't enable quests");
        RunTests.check(!negative.startMacro && !negative.enableQuestSmart && negative.field == null, "negative instructions do not become positive macro commands");
        BssIntentParser.Intent mixed = parser.parse("Don't farm Pine Tree and farm Sunflower");
        RunTests.check(mixed.startMacro && "Sunflower".equals(mixed.field), "mixed negative and positive clauses select the affirmative field");
        BssIntentParser.Intent negativeMaterial = parser.parse("Don't farm glue");
        RunTests.check(negativeMaterial.materialGoal == null && !negativeMaterial.startMacro, "negative material goals do not start farming");
        BssIntentParser.Intent explicitStop = parser.parse("Don't start farming; stop the macro");
        RunTests.check(explicitStop.stopMacro && !explicitStop.startMacro, "explicit stop still wins over a negated start");

        BssMacroSettings settings = new BssMacroSettings();
        BssPlanBuilder builder = new BssPlanBuilder();
        BssPlanBuilder.Plan plan = builder.build(in, settings);
        builder.applySupported(plan, settings);
        RunTests.check("Pine Tree".equals(settings.get("field")), "plan applied field");
        RunTests.check("true".equals(settings.get("questSmart")), "plan applied quest");

        UiController ui = new UiController();
        FakePort port = new FakePort();
        ui.bindMacro(port);
        for (NavSection sec : NavSection.values()) {
            ScreenContent.Model m = ui.open(sec);
            RunTests.check(m != null && m.title != null && m.body != null, "screen " + sec);
        }
        String blocked = ui.runAction("Start Macro");
        RunTests.check(blocked.contains("AI control"), "start blocked without AI control");
        ui.runAction("Enable AI Control");
        String started = ui.runAction("Start Macro");
        RunTests.check(port.starts >= 1, "start reaches port: " + started);
        ui.runAction("Stop Macro");
        RunTests.check(port.stops >= 1, "stop reaches port");

        String chat = ui.chat("Farm Sunflower and enable quests", true, false);
        RunTests.check(chat.contains("SET_FIELD") || chat.contains("Sunflower") || ui.state().settings.get("field").equals("Sunflower"),
                "chat applies sunflower");
    }
}
