package com.hiveminemobile;

import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.data.DataCatalog;
import com.hiveminemobile.ai.data.MemoryStore;
import com.hiveminemobile.ai.data.SnapshotJournal;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.merge.MacroPortAdapterSpec;
import com.hiveminemobile.ai.merge.SpecialistCatalogFactory;
import com.hiveminemobile.ai.modules.BaseSpecialist;
import com.hiveminemobile.ai.modules.FieldAI;
import com.hiveminemobile.ai.modules.SafetyAI;
import com.hiveminemobile.ai.release.ReleaseChecklist;
import com.hiveminemobile.ai.release.VersionInfo;
import com.hiveminemobile.ai.ui.UiAction;
import com.hiveminemobile.ai.ui.UiModel;
import com.hiveminemobile.ai.ui.UiModelFactory;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/** V2 phases 101–250 coverage tests (specialists, data, UI contract, release, merge spec). */
public final class V2CompletionTests {
    private V2CompletionTests() {}

    public static void run() {
        // Missing specialists present + analyze
        List<BaseSpecialist> all = new SpecialistCatalogFactory().all();
        RunTests.check(all.size() >= 20, "v2 catalog has 20 specialists: " + all.size());
        HashSet<String> ids = new HashSet<String>();
        for (BaseSpecialist s : all) ids.add(s.getId());
        String[] need = {"field", "movement", "bee", "ability", "token", "field-selection",
                "conversion", "equipment", "shop", "boost", "timer", "safety"};
        for (String id : need) {
            RunTests.check(ids.contains(id), "v2 specialist present: " + id);
        }
        HashMap<String, Double> sig = new HashMap<String, Double>();
        sig.put("alpha", 1.5);
        sig.put("beta", 3.0);
        FieldAI field = new FieldAI();
        RunTests.check(field.best(sig).code.equals("beta"), "v2 field best signal");
        SafetyAI safety = new SafetyAI();
        RunTests.check(safety.analyze(sig).size() == 2, "v2 safety analyze");

        // Data layer
        MemoryStore store = new MemoryStore();
        store.put("k", "v");
        RunTests.check("v".equals(store.get("k")) && store.size() == 1, "v2 memory store");
        SnapshotJournal journal = new SnapshotJournal(3);
        journal.append(1, "a", "1");
        journal.append(2, "b", "2");
        RunTests.check(journal.size() == 2, "v2 journal");
        DataCatalog cat = new DataCatalog();
        cat.register("bag");
        RunTests.check(cat.has("bag"), "v2 catalog");

        // UI contract
        UiModel model = new UiModelFactory().from(ManagerGoal.FARM_POLLEN,
                MacroStatus.connected(true, "ok"), true);
        RunTests.check(model.macroRunning && model.aiControlEnabled, "v2 ui model");
        RunTests.check(UiAction.STOP_GOAL != null, "v2 ui actions");

        // Release
        RunTests.check(VersionInfo.VERSION.equals("2.00"), "v2 version constant");
        ReleaseChecklist rc = new ReleaseChecklist();
        rc.add("jvm-tests", true, "green");
        rc.add("macroport-merge", false, "not on device");
        rc.add("apk", false, "not built");
        RunTests.check(rc.allCriticalDone("jvm-tests"), "v2 checklist critical jvm");
        RunTests.check(!rc.allCriticalDone("jvm-tests", "apk"), "v2 checklist apk still open");
        RunTests.check(rc.toMarkdown().contains("jvm-tests"), "v2 checklist md");

        // Merge spec
        MacroPortAdapterSpec spec = new MacroPortAdapterSpec();
        RunTests.check(spec.validates(true, true, true, true, true), "v2 merge spec valid");
        RunTests.check(!spec.validates(true, true, true, true, false), "v2 merge requires user AI control");
        RunTests.check(spec.mergeInstructions().contains("MacroPort"), "v2 merge instructions");
    }
}
