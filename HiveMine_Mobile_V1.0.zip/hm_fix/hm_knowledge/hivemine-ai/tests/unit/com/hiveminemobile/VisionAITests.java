package com.hiveminemobile;

import com.hiveminemobile.ai.modules.VisionAI;
import com.hiveminemobile.ai.modules.VisionAI.Detection;
import com.hiveminemobile.ai.modules.VisionAI.Frame;
import com.hiveminemobile.ai.modules.VisionAI.Region;
import com.hiveminemobile.ai.modules.VisionAI.Signature;
import java.util.Arrays;
import java.util.List;

/** JVM-only tests for Phase 011 VisionAI. */
public final class VisionAITests {
    private VisionAITests() { }

    public static void run() {
        int w = 10;
        int h = 4;
        int[] pixels = new int[w * h];
        paint(pixels, w, 0, 0, 5, 2, 0x00FF00);
        paint(pixels, w, 1, 2, 3, 2, 0xFF0000);
        paint(pixels, w, 6, 2, 2, 2, 0xFE0000);
        Frame frame = new Frame(w, h, pixels);
        VisionAI vision = new VisionAI();
        RunTests.check(vision.getCapabilities().contains("observe.frame"), "phase 011 exposes observe.frame");

        boolean sizeRejected = false;
        try { new Frame(w, h, new int[3]); } catch (IllegalArgumentException expected) { sizeRejected = true; }
        RunTests.check(sizeRejected, "a frame whose pixel count does not match its size is rejected");
        boolean badName = false;
        try { new Signature("Bad Name", new Region(0, 0, 1, 1), 0, 0, 0.5); }
        catch (IllegalArgumentException expected) { badName = true; }
        RunTests.check(badName, "an invalid signature name is rejected");

        List<Detection> found = vision.recognize(frame, Arrays.asList(
            new Signature("make-honey", new Region(1, 2, 3, 2), 0xFF0000, 0, 0.9),
            new Signature("missing-button", new Region(8, 0, 2, 2), 0x123456, 0, 0.9),
            new Signature("off-screen", new Region(9, 3, 4, 4), 0x000000, 0, 0.5)));
        RunTests.check(found.get(0).isPresent() && found.get(0).getConfidence() == 1.0,
            "a matching element is recognised with full confidence");
        RunTests.check(!found.get(1).isPresent(), "an element with the wrong colour is not recognised");
        RunTests.check(!found.get(2).isPresent() && found.get(2).getNote().contains("outside"),
            "a region outside the frame is reported rather than guessed");

        RunTests.check(vision.matchRatio(frame, new Region(6, 2, 2, 2), 0xFF0000, 0) == 0.0,
            "tolerance 0 rejects a near colour");
        RunTests.check(vision.matchRatio(frame, new Region(6, 2, 2, 2), 0xFF0000, 1) == 1.0,
            "tolerance 1 accepts a near colour");

        RunTests.check(vision.readGauge(frame, new Region(0, 0, 10, 2), 0x00FF00, 0).getAsInt() == 50,
            "a gauge filled to the middle reads 50 percent");
        RunTests.check(vision.readGauge(frame, new Region(0, 0, 10, 2), 0x000000, 0).getAsInt() == 0,
            "a gauge with no fill reads 0 percent");
        int[] full = new int[w * h];
        Arrays.fill(full, 0x00FF00);
        RunTests.check(vision.readGauge(new Frame(w, h, full), new Region(0, 0, 10, 2), 0x00FF00, 0).getAsInt() == 100,
            "a full gauge reads 100 percent");
        RunTests.check(!vision.readGauge(frame, new Region(8, 3, 5, 3), 0x00FF00, 0).isPresent(),
            "a gauge outside the frame reads nothing");
    }

    private static void paint(int[] pixels, int frameWidth, int x, int y, int w, int h, int rgb) {
        for (int dy = 0; dy < h; dy++) {
            for (int dx = 0; dx < w; dx++) pixels[(y + dy) * frameWidth + (x + dx)] = rgb;
        }
    }
}
